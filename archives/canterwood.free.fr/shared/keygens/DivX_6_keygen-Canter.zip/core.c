/* Canter Keygen 5 - Core */

/* additional libraries and sources used are referenced below */

/* configuration */

#define ID             "4"      /* keygen identifier, generally a number              */
#define TARGET         "DivX"   /* target's (short) name                              */
#define TARGET_VERSION "6"      /* target version, optional (the line may be deleted) */
#define TYPE           "keygen" /* type of release, ie. keygen, keymaker etc.         */

/* a quick notice/description/... */
#define NOTE "I haven't understood the whole thing, but the keygen seems to work...\r\n\r\nEnjoy!\r\n\r\nCanter"

#define AUTO_UPDATE   TRUE /* update registration information without pushing any button (recommended) */
#define MULTI_SERIALS TRUE /* allow various serials for the same input value (target-related)          */

/* field values (serial/name-serial/name-company-serial in most cases) */
CHAR sOutfield1[21];

/* generator's initialization: initial computations, object creation, etc. */
BOOL Init(HWND hWnd) {

  /* initializes the PRNG */
  srand(GetTickCount());

  SetStatusText(hWnd, TEXT("Keygen ready..."));
  return TRUE;
}

/* generation */
BOOL Gen(HWND hWnd) {
  CHAR pSerial[] = {0, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4};
  CHAR sAlphabet[] = "23456789ABCDEFGHIJKMNPQRSTUVWXYZ";
  CHAR sLicense[] = "2RGJH"; /* full */
  CHAR bAnd1 = 0x33, bAnd2 = 0x55;
  CHAR bLeft, bRight, bXor;
  int i;

  /* encode the license type */
  for(i = 0; i < sizeof(sLicense) - 1; i++)
    pSerial[7 + i] = strchr(sAlphabet, sLicense[i]) - sAlphabet;

  /* add random information elsewhere */

  for(i = 0; i < 6; i++)
    pSerial[1 + i] = rand() % 0x1F;

  for(i = 0; i < 4; i++)
    pSerial[12 + i] = rand() % 0x1F;

  for(i = 0; i < 4; i++)
    pSerial[16 + i] = rand() % 0x1F;

  /* compute the serial's checksum */
  for(i = 1; i < sizeof(pSerial); i++)
    pSerial[0] ^= pSerial[i];

  /* crypt the serial */

  for(i = 0; i < sizeof(pSerial) / 2; i++) {
    bLeft = pSerial[i];
    bRight = pSerial[sizeof(pSerial) - 1 - i];
    bXor = bLeft ^ bRight;

    pSerial[i] = bRight ^ (bXor & bAnd2);
    pSerial[sizeof(pSerial) - 1 - i] = bLeft ^ (bXor & bAnd2);
  }

  for(i = 0; i < sizeof(pSerial) / 4; i++) {
    bLeft = pSerial[i];
    bRight = pSerial[sizeof(pSerial) / 2 - 1 - i];
    bXor = bLeft ^ bRight;

    pSerial[i] = bRight ^ (bXor & bAnd1);
    pSerial[sizeof(pSerial) / 2 - 1 - i] = bLeft ^ (bXor & bAnd1);
  }

  for(i = 0; i < sizeof(pSerial) / 4; i++) {
    bLeft = pSerial[sizeof(pSerial) / 2 + i];
    bRight = pSerial[sizeof(pSerial) - 1 - i];
    bXor = bLeft ^ bRight;

    pSerial[sizeof(pSerial) / 2 + i] = bRight ^ (bXor & bAnd1);
    pSerial[sizeof(pSerial) - 1 - i] = bLeft ^ (bXor & bAnd1);
  }

  /* translate it into text */

  for(i = 0; i < sizeof(pSerial); i++)
    sOutfield1[i] = sAlphabet[pSerial[i]];

  sOutfield1[sizeof(pSerial)] = '\0';

  SetDlgItemText(hWnd, IDC_OUTFIELD1, sOutfield1);

  SetStatusText(hWnd, TEXT("Serial generated successfully."));
  return TRUE;
}

/* copy: in the clipboard, the registry, or directly into a license file... */
BOOL Copy(HWND hWnd) {
  HGLOBAL hOutfield1;

  GetDlgItemText(hWnd, IDC_OUTFIELD1, sOutfield1, sizeof sOutfield1);

  /* copy the serial into a shareable memory block */
  hOutfield1 = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, sizeof sOutfield1);
  lstrcpy(GlobalLock(hOutfield1), sOutfield1);
  GlobalUnlock(hOutfield1);

  /* move it in the clipboard */
  OpenClipboard(hWnd);
  EmptyClipboard();
  SetClipboardData(CF_TEXT, hOutfield1);
  CloseClipboard();

  SetStatusText(hWnd, TEXT("Serial copied into the clipboard."));
  return TRUE;
}

/* termination: may be used to give a message to the user, to delete objects, etc. */
BOOL Exit(HWND hWnd) {
  SetStatusText(hWnd, TEXT("See you later..."));
  return TRUE;
}
