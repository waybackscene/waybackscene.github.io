/* Canter Keygen 5 - Core */

/* additional libraries and sources used are referenced below */
#include "DES.h" /* for DES encryption */

/* configuration */

#define ID             "3"                                /* keygen identifier, generally a number                                    */
#define TARGET         "GoldWave"                         /* target's (short) name                                                    */
#define TARGET_VERSION "5.10"                             /* target version, optional (the line may be deleted)                       */
#define TYPE           "keymaker"                         /* type of release, ie. keygen, keymaker etc.                               */
#define NOTE           "Just press Generate, Copy, and enjoy this fine keymaker!\r\n\r\nCanter" /* a quick notice/description/...                                           */

#define AUTO_UPDATE    TRUE                               /* update registration information without pushing any button (recommended) */
#define MULTI_SERIALS  TRUE                               /* allow various serials for the same input value (target-related)          */

/* field values (serial/name-serial/name-company-serial in most cases) */
CHAR sOutfield1   [10];
CHAR sOutfield2   [10];
CHAR sOutfield2Bis[10]; /* not really a field, but useful to set the reginfo */

/* generator's initialization: initial computations, object creation, etc. */
BOOL Init(HWND hWnd) {
  sOutfield1[sizeof sOutfield1 - 1] = '\0';
  sOutfield2[sizeof sOutfield2 - 1] = '\0';

  return TRUE;
}

/* generation */
BOOL Gen(HWND hWnd) {
  BOOL bBlacklisted;
  int i, j;
  CHAR sAlphabet[] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  CHAR sMagic[] = "\0\0\0";
  BYTE pBinOutfield2[70];
  LPVOID pArg1 = &sOutfield1, pArg2 = &sMagic, pArg3 = &pBinOutfield2;
  BYTE pXorTable[] = {0x0C, 0x1E, 0x05, 0x13, 0x17, 0x1F, 0x0B, 0x09, 0x1A};
  int nOutfield2Char;

  /* blacklisted User IDs */
  LPCSTR pBlacklist[] = {"9C8TN8ABA", "5K3FN8ARU", "UH7FE9EX2", "B2K42ABL6", "XBLRP8A7J",
                         "PJC2W8AFG", "9QGFV8AUE", "UNBHZ8AFW", "C43R58AWA", "HEHUB9AYY",
                         "QCZ8C9A29", "66YHF9AH8", "9VKXE9ABT", "49C2F9AYX", "7T7TF9AVC",
                         "YVV9H9AXN", "XQSTQ9AZF", "EPXSZ9AAA", "EPXSZ9ABA", "EPXSZ9ACA",
                         "EPXSZ9ADA", "M9HVAAB85", "BNKVAAB85", "N87QAAB85", "CXKJCABBA",
                         "CXKJCABCA", "CXKJCABDA", "CXKJCABEA", "XARLJABNU", "CREZLABBA",
                         "33GWVABBA", "33GWVABCA", "33GWVABDA", "33GWVABEA", "VBVKWABBR",
                         "RKLZWABQZ", "UL5KXABBA", "UL5KXABCA", "UL5KXABDA", "UL5KXABEA",
                         "UL5KXABFA", "UL5KXABGA", "UL5KXABHA", "E7UTYAB44", "38LC3ABBA",
                         "38LC3ABCA", "38LC3ABDA", "38LC3ABEA", "QKEU4ABBA", "QKEU4ABCA",
                         "QKEU4ABDA", "QKEU4ABEA", "QKEU4ABFA", "QKEU4ABGA", "QKEU4ABHA",
                         "8CLP6ABME", "RDWY6AB8C", "Q488NAFAA", "TRAPFLAG2", "SPYMTAHFJ",
                         "BLZBLZBLZ", "BW9SS9EQJ", "JJSQLDMW5", "SMXYHLKCT", "XZGHHLGQP",
                         "TBZWUNHGW", "CUCCAHEAD", "RRKA2GKEY", "J3KCQWJBR", "BATABZER9",
                         "68VX8LJW6", "8AX253GQZ", "TXPK65MJX", "MN6FPAEE7", "2D8GT2MC5",
                         "65KQA5LMN", "M66V7AJV2", "HUA24EGMJ", "AXEZH9AQ7", "TNHSB9ADT",
                         "JTHF6QGMQ", "2J77VFEWH", "F3CL4BM47", "FKKYV7FKS", "M2FNA8MJR",
                         "SZETSBMVT", "EVGKEHM2Y", "N8LPABFVA", "EH8TEHHZT", "E3GTEHHV3",
                         "U8E87NF8E", "SR6BSBMZH", "TW3SSCBZU", "RR2WMWME7", "X8XGEKKKX",
                         "SAEAAEHQM", "E5G3E9A4X", "264MKSG8B", "MMXM4GLBW", "K6DSSGF77",
                         "NGUVYQK48", "G5U5DUHWQ", "SXN3SFM9W", "VGETM8ALP", "ZSWXM8A3B",
                         "E6S9N8ABU", "9FUQN8AQU", "PJ62R8AB3", "EK28T8A4M", "MQDUS8AY4",
                         "42JMU8AGU", "TT6F38AAA", "TT6F38ABA", "TT6F38ACA", "TT6F38ADA",
                         "TT6F38AEA", "DPWLV8A6E", "PJRCX8AX3", "WZ43X8ALS", "D6X928A34",
                         "RTLB38AVR", "4N5H78A2D", "KMJ7Y8EEG", "PHVZ38AVS", "QBP448ADS",
                         "AS7Z88A92", "VHMMA9AHG", "2LFYB9AA2", "K859F9AL4", "KUPBF9AZC",
                         "W66PS9AEX", "LJ9RS9A56", "DDQUS9A22", "6PUUS9AA6", "TBGXS9AP9",
                         "A6MXS9AP9", "HHHXS9AP9", "XQ9RS9A56", "GVWZS9AQ3", "W52ZS9AB4",
                         "JT4YR9A9X", "G6SJX9ATM", "YYLY29AVN", "VFYN39AF2", "5B33DABHN",
                         "K54MAAFFP", "ZZK8KABF4", "P6U8SABGS", "DSLMRABKR", "4AY92ABAA"};

  /* initializes the PRNG */
  srand(GetTickCount());

  /* User ID: a nearly random string; beware of blacklisted ones! */

  bBlacklisted = FALSE;

  do {

    for(i = 0; i < sizeof sOutfield1 - 1; i++)

      if(i == 6)
        sOutfield1[6] = sAlphabet[rand() % 12]; /* character 6 must be between A and M */
      else
        sOutfield1[i] = sAlphabet[rand() % (sizeof sAlphabet - 1)];

    /* check if the string is in the blacklist */
    for(i = 0; i < sizeof *pBlacklist - 1; i++)

      if(lstrcmp(sOutfield1, pBlacklist[i]) == 0) {
        bBlacklisted = TRUE;
        break;
      }

  } while(bBlacklisted);

  SetDlgItemText(hWnd, IDC_OUTFIELD1, sOutfield1);

  /* License: its computation is mainly based on DES and... Xor! */

  /* a 2-character string required for DES encryption */

  sMagic[0] = sOutfield1[sizeof sOutfield1 - 2];
  sMagic[1] = sOutfield1[0];

  /* inline ASM + call to an external module, works only with MSVC */

  _asm {
    push pArg3
    push pArg2
    push pArg1
  }

  DES(); /* in fact this procedure was ripped from GoldWave */

  /* Xor encryption */
  for(i = 0; i < sizeof sOutfield2 - 1; i++) {
    nOutfield2Char = 0;

    /* reconstitutes a character index from binary data */
    for(j = 0; j < 5; j++) {
      nOutfield2Char <<= 1;
      nOutfield2Char |= pBinOutfield2[i * 5 + j];
    }

    /* the reginfo contains it */
    sOutfield2Bis[i] = sAlphabet[pXorTable[i] ^ (strchr(sAlphabet, sOutfield1[i]) - sAlphabet) ^ (strchr(sAlphabet, sAlphabet[nOutfield2Char]) - sAlphabet)];

    /* what the user enters in the box */
    sOutfield2   [i] = sAlphabet[pXorTable[i] ^ (strchr(sAlphabet, sOutfield1[i]) - sAlphabet) ^ (strchr(sAlphabet, sOutfield2Bis[i]) - sAlphabet)];
  }

  SetDlgItemText(hWnd, IDC_OUTFIELD2, sOutfield2);

  return TRUE;
}

/* copy: in the clipboard, the registry, or directly into a license file... */
BOOL Copy(HWND hWnd) {
  BOOL bCopied = FALSE;
  CHAR sReginfo[19];
  HKEY hRegkey;

  lstrcpy(sReginfo, sOutfield1);
  lstrcat(sReginfo, sOutfield2Bis);

  /* copy the reginfo in registry */
  if(RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Software\\GoldWave\\GoldWave\\Options"), 0, KEY_WRITE, &hRegkey) == ERROR_SUCCESS)

    if(RegSetValueEx(hRegkey, TEXT("License"), 0, REG_SZ, sReginfo, sizeof sReginfo) == ERROR_SUCCESS)

      if(RegCloseKey(hRegkey) == ERROR_SUCCESS)
        bCopied = TRUE;

  if(bCopied)
    MessageBox(hWnd, "Reginfo successfully copied!\r\nNow run GoldWave... :)", "Information", MB_ICONINFORMATION);
  else
    MessageBox(hWnd, "An error occured.\r\nPlease copy your reginfo by hand. :)", "Information", MB_ICONERROR);

  return bCopied;
}

/* termination: may be used to give a message to the user, to delete objects, etc. */
BOOL Exit(HWND hWnd) {
  return TRUE;
}
