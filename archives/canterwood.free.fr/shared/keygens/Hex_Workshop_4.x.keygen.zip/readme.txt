Keygen template - Read me
================================================================================
Author : Canterwood <canterwood@altern.org>
Website: http://kickme.to/canterwood
IDE    : MASM32 8
================================================================================
03.01.2004

A little MASM32 template to make your own key generators.

If you have any problem (or any question, of course!), use this email address:
canterwood@altern.org.