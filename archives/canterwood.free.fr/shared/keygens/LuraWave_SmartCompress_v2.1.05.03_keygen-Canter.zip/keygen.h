/* Canter Keygen 5 - Resource identifiers */

#define IDI_KEYGEN 100

#define IDD_KEYGEN 200
#define IDD_INFO   201

#define IDB_KEYGEN 300

#define IDC_NAME   400
#define IDC_SERIAL 401
#define IDC_INFO   402
#define IDC_GEN    403
#define IDC_COPY   404
#define IDC_EXIT   405
#define IDC_TITLE  406
#define IDC_NOTE   407
#define IDC_DATE   408
