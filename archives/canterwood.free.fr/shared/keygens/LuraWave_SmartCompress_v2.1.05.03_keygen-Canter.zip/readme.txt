Canter Keygen 5 - How to use
--

You may freely edit this template to create your own keygens.

It's coded in ANSI C; I used lcc-win32 as a compiler but it should work
with others, like Dev C++ or Visual C++. :)

If you want to build the project and compress it by command line, the
only file to be modified is make.bat.
Personally I pack the executable with FSG 2.0 by bart // XT, it offers a
very good ratio but sometimes triggers virus alerts...

Here is a quick description of the files:
- make.bat  : you can define here some parameters like the executable's
name, etc.;
- release.c : it contains all the necessary information to build
quickly a new keygen from the template, that is the only file you should
modify with make.bat when making releases;
- keygen.c  : essentially the WinMain and DialogProc procedures;
- keygen.rc : the dialog boxes which set the appearance of our keygen;
- keygen.h  : the resource identifiers to link our dialog box with the
code;
- keygen.bmp: self explaining I think. You may change this image of
course; :)
- keygen.ico: idem.

Have fun!

--
Canter