void __stdcall DES(void);
