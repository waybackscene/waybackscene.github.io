/* Canter Keygen 5 - Resource identifiers */

#define IDC_STATIC     -1

/* icons */
#define IDI_KEYGEN     100

/* dialogs */
#define IDD_KEYGEN     200
#define IDD_INFO       201

/* bitmaps */
#define IDB_KEYGEN     300

/* controls (40X) */
#define IDC_INFO       400
#define IDC_GEN        401
#define IDC_COPY       402
#define IDC_EXIT       403
#define IDC_TITLE      404
#define IDC_NOTE       405
#define IDC_DATE       406

/* fields */

/* outfields: 41X, intfields: 42X */
#define OUTFIELD_BEGIN 410
#define OUTFIELD_END   OUTFIELD_BEGIN + 9
#define INFIELD_BEGIN  OUTFIELD_END   + 1
#define INFIELD_END    INFIELD_BEGIN  + 1

/* used fields */
#define IDC_OUTFIELD1  OUTFIELD_BEGIN
#define IDC_OUTFIELD2  OUTFIELD_BEGIN + 1
#define IDC_OUTFIELD3  OUTFIELD_BEGIN + 2
