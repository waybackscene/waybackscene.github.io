Keygen - ReadMe
================================================================================
Author : Canterwood <canterwood@altern.org>
Website: http://kickme.to/canterwood
IDE    : MASM32 8
================================================================================
10.31.2003

A little MASM32 template to make your own key generators.

If you have any problem (or any question, of course!), use this email address:
canterwood@altern.org.