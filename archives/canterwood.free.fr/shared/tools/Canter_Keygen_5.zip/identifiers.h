/* Canter Keygen 5 - Resource identifiers */

#define IDC_STATIC     -1

#define IDI_KEYGEN     100

#define IDD_KEYGEN     200
#define IDD_INFO       201

#define IDB_KEYGEN     300

#define IDC_STATUS     400
#define IDC_INFO       401
#define IDC_GEN        402
#define IDC_COPY       403
#define IDC_EXIT       404
#define IDC_TITLE      405
#define IDC_NOTE       406
#define IDC_DATE       407

/* fields */

/* space reserved for fields; outfields: 41X, intfields: 42X */
#define OUTFIELD_BEGIN 410
#define OUTFIELD_END   OUTFIELD_BEGIN + 9
#define INFIELD_BEGIN  OUTFIELD_END   + 1
#define INFIELD_END    INFIELD_BEGIN  + 1

/* declared fields, must use the identifiers specified above */
#define IDC_OUTFIELD1  OUTFIELD_BEGIN
#define IDC_INFIELD1   INFIELD_BEGIN
