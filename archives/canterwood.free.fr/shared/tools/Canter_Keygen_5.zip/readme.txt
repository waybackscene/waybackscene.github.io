Canter Keygen 5 - Readme
--

How to make a keygen from this template?

1) Once you studied a generation algorithm, you have to set the keygen
"fields", namely how many parameters your keygen needs (name,
compagny...), and how many results it will display (license, key...).
So, you must add/remove controls to your dialog.
The right place to do this is resources.rc; but first, let's declare
your fields in identifiers.h.
You may declare ten input fields (IDC_INFIELD1, IDC_INFIELD2...) and ten
output fields, it should be enough...
Then, go in resource.rc and change/move everything you want.
Of course, you can replace icon.ico and picture.bmp with your owns...

2) OK, now type your code in core.c.
You may modify at your ease the Init, Gen, Copy and Exit functions.
Add source files and/or libraries if necessary.

3) It's time to compile your release.
Go in make.bat and set the few parameters (file name, version).
This file is designed for the lcc-win32 compiler and FSG 2 packer, but
you can edit it for GCC, Visual C++, etc.; it should work.

4) Double-click on make.bat and... have fun!

Canter
