Keygen - Readme
================================================================================
Author: Canterwood <charloweb@hotmail.com>
IDE   : MASM32 8
================================================================================
http://kickme.to/charloweb - http://www.iciteam.vze.com

A little MASM32 template to make your own key generators.

If you have any problem (or any question, of course!), use this email address:
charloweb@hotmail.com.