/* Dialog Builder 1.3.1.66 keygen
 * =============================================================================
 * Author   : Dean/Canterwood <charloweb@hotmail.com>
 * Version  : 1.0 (07.25.2003)
 * Greetings: The Analyst, Lise_Grim, RocketSpawn, +Christal...
 * =============================================================================
 * Copyright � 2003 ICIteam */

#include <stdio.h>
#include <stdlib.h> /* For the system function */
#include <string.h>

/* Buffers and related pointers */
char name[32], checkedName[sizeof(name) + 4];

/* int generateNumber(void)
 * -----------------------------------------------------------------------------
 * Description: this function returns a number computed with the value of
 *              checkedName. Next, you can format it to generate a serial.
 * -----------------------------------------------------------------------------
 */
int generateNumber() {
  int i, number = 0, tempVal;

  for(i = 0; i < strlen(checkedName); ++i) {
    number <<= 4;
    number += checkedName[i];

    tempVal = number & 0x0F000000;

    if(tempVal != 0) {
      tempVal >>= 0x18;
      number ^= tempVal;
    }

    number &= ~tempVal;
  }

  return number;
}

int main() {
  printf("Dialog Builder 1.3.1.66 keygen by Canterwood (%s)\n\n", __DATE__);

  /* Get the name */
  printf("Enter your name (without special characters): ");
  fgets(name, sizeof(name), stdin);

  /* Delete the '\n' (new line) character */
  name[strlen(name) - 1] = 0;

  /* Add the suffix and store the result in checkedName */
  strcat(strcpy(checkedName, name), "assa");

  /* Display the name (truncated if necessary),
     and the serial, computed with the generateNumber function */
  printf("\n----\n\nName  : %s\nSerial: DBD - %.8X\n\n----\n\n", name,
         generateNumber());

  system("PAUSE");

  return 0;
}
