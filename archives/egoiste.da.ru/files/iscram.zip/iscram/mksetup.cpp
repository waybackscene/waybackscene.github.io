/*
 *   MIKE Domain parameters creation and Lim-Lee prime generation
 *
 *   Compile on the command line as 
 *   cl /O2  mksetup.cpp big.cpp miracl.lib
 *
 *   where miracl.lib should be built to use the KCM method
 *
 *   See "A Key recovery Attack on Discrete Log-based Schemes using a Prime 
 *   Order Subgroup", Lim & Lee, Crypto '97
 *
 *   When run the program generates a prime p PBITS in length, where 
 *   p-1=2*pa*pb*pc....*q, where q is a prime QBITS in length, and pa,pb,pc 
 *   etc are all primes > QBITS in length. Also generated are g1 and g2,
 *   unrelated generators of the prime-order sub-group, of order q.
 *
 *   Note that g1 = sha512(p,q,0)^[(p-1)/q]
 *             g2 = sha512(p,q,1)^[(p-1)/q] 
 *
 *   Finally p, q, g1 and g2 are output to a file common.mik
 *
 *   Requires: big.cpp
 *
 *   Copyright (c) 2001 Shamus Software Ltd.
 */

#include <iostream.h>
#include <fstream.h>
#include <iomanip.h>
#include <big.h>

#define PBITS 16384
#define QBITS 512
#define OBITS 2048    /* Size of pa, pb, pc etc., >=QBITS */ 
#define POOL_SIZE 16  /* greater than PBITS/OBITS */

Miracl precision=1000;

static int num1bits(long x)
{ /* returns number of '1' bits in x */
    int n=0;
    while (x!=0) 
    {
        if (x&1L) n++;
        x>>=1;
    }
    return n;
}

static long increment(long permutation)
{ /* move onto next permutation with same number of '1' bits */
    int n=num1bits(permutation);
    do
    {
        permutation++;
    } while (num1bits(permutation)!=n);
    return permutation;
}

int main()
{
    ofstream common("common.mik");
    Big q,p,p1,x,h,t,g1,g2,low,high;
    Big pool[POOL_SIZE];
    BOOL fail;
    int i,j,p1bits,np;
    long seed,m,permutation;
    sha512 sh;
    miracl *mip=&precision;
    set_io_buffer_size(8192);
/* randomise */
/*    cout << "Enter 9 digit random number seed  = ";
      cin >> seed;
      irand(seed);
*/
    irand(0L);
    gprime(10000);    
    p1bits=PBITS-QBITS-1;

/* find number of primes pa, pb, pc etc., that will be needed */

    np=1;
    while (p1bits/np >= OBITS) np++;
    np--;

/* find the high/low limits for these primes, so that 
   the generated prime p will be exactly PBITS in length */

    t=pow((Big)2,p1bits-1);
    low=root(t,np)+1;       /* np-th integer root */

    t=2*t-1;
    high=root(t,np);

    low=high-(high-low)/2;  /* raise low limit to half-way... */

/* generate q  */
    forever
    { /* make sure leading two bits of q 11... */
        q=pow((Big)2,QBITS)-rand(QBITS-2,2);
        while (!prime(q)) q+=1;
        if (bits(q)>QBITS) continue;
        break;
    }
    cout << "q= (" << bits(q) << " bits)" << endl;
    cout << q << endl;

/* generate prime pool from which permutations of np 
   primes will be picked until a Lim-Lee prime is found */

    for (i=0;i<POOL_SIZE;i++)
    { /* generate the primes pa, pb, pc etc.. */
        forever
        { 
            p1=rand(high);
            if (p1<low) continue;
            while (!prime(p1)) p1+=1;
            if (p1>high) continue;
            pool[i]=p1;
            break;
        }
    }

/* The '1' bits in the permutation indicate which primes are 
   picked form the pool. If np=5, start at 11111, then 101111 etc */

    permutation=1L;
    for (i=0;i<np;i++) permutation<<=1;
    permutation-=1;     /* permuation = 2^np-1 */

/* generate p   */
    fail=FALSE;
    forever 
    {
        p1=1;
        for (i=j=0,m=1L;j<np;i++,m<<=1)
        {
            if (i>=POOL_SIZE) 
            { /* ran out of primes... */
                fail=TRUE;
                break;
            }
            if (m&permutation) 
            {
                p1*=pool[i];
                j++;
            }
        } 
        if (fail) break;
        cout << "." << flush; 
        p=2*q*p1+1;  
        permutation=increment(permutation);
        if (bits(p)!=PBITS) continue;
        if (prime(p)) break; 
    } 

    if (fail)
    {
        printf("\nFailed - very unlikely! - try increasing POOL_SIZE\n");
        return 0;
    }

    cout << "\np= (" << bits(p) << " bits)\n";
    cout << p << endl;

/* finally find g1 & g2 */

    Big pp,qq;
    char s[64];

    pp=p;
    qq=q;

    shs512_init(&sh);
    while (pp>0)
    {   
        shs512_process(&sh,pp%256);
        pp/=256;
    }
    while (qq>0)
    {
        shs512_process(&sh,qq%256);
        qq/=256;
    }
    shs512_process(&sh,0);
    shs512_hash(&sh,s);
    h=from_binary(64,s);  // h=hash(p,q,0)

    g1=pow(h,(p-1)/q,p);
  

    pp=p;
    qq=q;

    shs512_init(&sh);
    while (pp>0)
    {   
        shs512_process(&sh,pp%256);
        pp/=256;
    }
    while (qq>0)
    {
        shs512_process(&sh,qq%256);
        qq/=256;
    }
    shs512_process(&sh,1);
    shs512_hash(&sh,s);
    h=from_binary(64,s);  // h=hash(p,q,1)

    g2=pow(h,(p-1)/q,p);

    if (g1==1 || g2==1)
    {
        cout << "Failed. Try again with different random input" << endl;
        exit(0);
    }
  
    cout << "g1= (" << bits(g1) << " bits)\n";
    cout << g1 << endl;
    cout << "g2= (" << bits(g2) << " bits)\n";
    cout << g2 << endl;

    common << PBITS << endl;

    common << p << endl;
    common << q << endl;
    common << g1 << endl;
    common << g2 << endl;

    return 0;
}

