// Optimized/Created using liptimer.exe !
#define KARAT	1
#define KAR_MUL_CROV	31
#define KAR_SQU_CROV	31
