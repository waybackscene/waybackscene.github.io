/* 	 Powerstrip v2.70 Keygenerator - by tE!/TMG
     Don't forget to include ws2_32.lib in your project.
	 Shitty freelip uses htonl() function for some conversions.
     You also need freelip bignum library (freelip.lib) to compile
	 this. But guess what ? Yea, it's FREE! Hehehe.
 */

#include <windows.h>
#include <lip.h>
#include "resource.h"

char eulav(long i);

void zhconvert(verylong a, char *dbuff, int CodeLen){
	static	 char *b;
	register long i,j,cnt = 0;

	b = (char *)malloc( (size_t)(a[0] << 3) );

	if (!b) return;

	do	{
		b[cnt] = eulav(a[1] & 15);
		cnt++;
		zrshift(a, (long) 4, &a);
	} 
	while ( (a[1] != 0) || (a[0] != 1) || (cnt < CodeLen) );

	b[cnt]&=0x00;

	j=cnt-1;
	for	(i=0; i<cnt; i++)	{
		dbuff[i]=b[j];
		j--;
	}
	dbuff[i]=0x00;
	free(b);
}

void GenerateCode(HWND hDlg){
	static char modulus_n[]="4E7296FB311E7CA831F5C59923E06917FA8B230D";
	static char private_d[]="9109ABBBA0850D54AB87F2412A71CB327AADC0D";
	static char hextab[]="0123456789ABCDEF";
	char		szName[31];
	char		Regcode[42];
	int			i,j,nLen;
	BYTE		t, u;
	verylong	d = 0;
	verylong	m = 0;
	verylong	n = 0;

	nLen=GetDlgItemTextA(hDlg, EDIT_NAME, szName, 31);
	if	(nLen < 4) {
		SetDlgItemTextA(hDlg, EDIT_CODE, "Name must contain at least 4 chars.");
		return;
	}
	j=0;
	for	(i=0; i<nLen; i++){
		u=t=szName[i];
		Regcode[j]=hextab[((t & 0xF0) >> 4)];
		Regcode[j+1]=hextab[(u & 0x0F)];
		j+=2;
	}
	Regcode[j]&=0x00;

	/* Read in Bignums */
	zstrtozbas(modulus_n, (long) 16, &n);
	zstrtozbas(private_d, (long) 16, &d);
	zstrtozbas(Regcode, (long) 16, &m);
	/* m = m^d % n */
	zexpmod(m,d,n,&m);
	/* Convert m to Hex String, 40 Chars long */
	zhconvert(m, Regcode, 40);
	/* Clean up */
	zfree(&d);
	zfree(&m);
	zfree(&n);
	/* Show Regcode */
	SetDlgItemTextA(hDlg, EDIT_CODE, Regcode);
}

BOOL CALLBACK DlgP (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG :
			SendDlgItemMessageA(hDlg, EDIT_NAME, EM_SETLIMITTEXT, (WPARAM) 30, 0);
			SetWindowTextA(hDlg, "Powerstrip v2.70 - Keygen by tE!/TMG");
			SetDlgItemTextA(hDlg, EDIT_CODE, "Enter your name and press Generate.");
			return TRUE;
		case WM_COMMAND :
			switch (LOWORD (wParam))
			{
				case BT_GENERATE :
					GenerateCode(hDlg);			
					SetFocus(GetDlgItem(hDlg, EDIT_NAME));
					break;
				case IDCANCEL :
					EndDialog (hDlg, 0);
					break;
			}
			break;
     }
     return FALSE;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	DialogBoxA(hInstance, MAKEINTRESOURCE(DLG_MAIN), 0, DlgP);
	return 0;
}
