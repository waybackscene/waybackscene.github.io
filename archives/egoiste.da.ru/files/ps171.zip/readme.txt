	A note for users of Password Safe Version 1.1:

We hope that you enjoy this new version of Password Safe.  Many new features have been added,
and we believe that you will find them very useful. The new features are listed below:

- Usernames
	    As well as the title, password, and notes fields, each entry now also contains a
	username field.  It can be left blank if desired.  The username will be displayed along
	with the title in the main dialog (with the two fields separated by a slash).
	    Also, you can set a default username if you want. The default name will be 
	automatically placed in the username field of the Add dialog box (though you can change
	it) and will not be displayed in the main dialog.
	    A command was added to copy the username to the clipboard (in addition to the
	command that copies the password).

- Multiple Databases
	    It is now far simpler to maintain multiple databases. The usual Open/Save/New
	menu commands are used.  The handling of backups has been changed as well. Instead of 
	having a list of backups stored in a proprietary format in the registry file, they can 
	be saved in any location (just like the databases).  Backups are identified by a .bak
	extension.  A backup restore is done by copying the data into a new (blank) database,
	so a new name will have to be selected and the original backup will be unchanged.
	    Password Safe will remember the name/location of the file that was open when it
	was last exited and will reopen that file when it is next launched. The current file
	is named on the title bar.

- New User Interface
	   You will notice that Password Safe's user interface has changed greatly. The buttons
	have been replaced by a menu (with all functionality) and a toolbar (for common 
	commands). Right-clicking on an entry will bring up a list of options.  Hotkeys have
	been added for most commands.


Every effort has been made to retain compatability between the versions. Two main points should
be mentioned:

Password Databases:
Your old password files will work with the new version.  When you open an old version database,
the program will present dialogs allowing you to add a username to all of your old entries, and 
to make that username the default if you wish.  

Backups:
When you start up the new version of the program, it will read the data left in the registry 
file by the previous version and update your backups by adding the .bak extension to them (if 
necessary).  It will then output a list of the locations of your old backups to the screen,
and will allow you to save this list to disk as well. Password Safe will note that it has
asked you these questions and not do so again, though you can get it to perform the same
operations by choosing the "Update V1.1 Backups..." menu item. 