This folder contains the source code to solve the DLP
for the program AbsoluteFTP 1.8. 

Run dlp.bat to check the precompiled executable.

With that and my Keygen source for SecureCRC v3.1 you
should be able to create a keygen by yourself.
Believe me, it's easy!

Good luck,

tE! // TMG
