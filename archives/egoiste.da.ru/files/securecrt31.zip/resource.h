//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by keygen.rc
//
#define DLG_MAIN                        111
#define KEYGEN_ICON                     113
#define DLG_ABOUT                       114
#define TMG_BMP                         115
#define BT_GENERATE                     1008
#define EDIT_NAME                       1009
#define EDIT_CODE                       1010
#define EDIT_COMPANY                    1011
#define EDIT_SERIAL                     1012
#define EDIT_DATE                       1013
#define BT_ABOUT                        1014
#define STATIC_ABOUT                    1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
