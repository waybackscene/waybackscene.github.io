//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by keygen.rc
//
#define TMG_ICON                        110
#define DLG_MAIN                        111
#define DLG_ABOUT                       112
#define TMG_LOGO                        113
#define BT_GENERATE                     1008
#define EDIT_NAME                       1009
#define EDIT_CODE                       1010
#define BT_ABOUT                        1011
#define STATIC_ABOUT                    1012
#define EDIT_COMPANY                    1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           120
#endif
#endif
