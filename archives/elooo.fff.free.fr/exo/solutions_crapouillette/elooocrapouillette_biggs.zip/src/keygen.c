/* 
 *	Keygen pour keygenme 1 de elooo
 *	keygen.c
 *
 *	biggs
 *	16/07/2004
 *
 */
 
#include <stdio.h>
#include <windows.h>
#include "md5.h"

long table_40714D[] =
	{
		0x3CE7F39C, 0x9EF39EE7, 0x0B977CEF3, 0x0EFB9F79E, 0x9EF3FE39, 0x0B84BF87F,
		0x120DED29, 0x20DDA35E, 0x9CD120A, 0x63C26867, 0x9FA788B5,
		0x0C4C6A876, 0x3C58D1D4, 0x0A27BDE21, 0x0FFCCEE7, 0x60C1D283,
		0x0F923EBA, 0x0F074C3A6, 0x96A47E98, 0x3795AA23, 0x0E702577B,
		0x4C59B467, 0x785C5CD9, 0x86391327, 0x9D2B33B7, 0x0D05C51C2,
		0x0D5C5E5A3, 0x0E3FEB2EA, 0x37D855B9, 0x0D53A2636, 0x4AC8B86E,
		0x44F2523A, 0x644EBC4F, 0x0D67E7BFB, 0x69966449, 0x0AA77CA4E,
		0x0CBE7E53, 0x0AC85F9C2, 0x4BF3350D, 0x9125AEF9, 0x9F9E598B,
		0x0DABB662E, 0x0F9CF53D7, 0x77048AA7, 0x4B7F073C, 0x50054431,
		0x0E3686D9F, 0x0EBE08DF2, 0x0D4BC91E, 0x80743558, 0x9A6120A2,
		0x0F40EE6E8, 0x53C94ACC, 0x0FB6DA94E, 0x0B0C56B6B, 0x0A007CAF3,
		0x0F8431FF6, 0x8440780, 0x14821082, 0x4A908843, 0x30B878DA,
		0x0B6900116, 0x34000317, 0x0D270860D, 0x7070831A, 0x77E0800E,
		0x3DE4010F, 0x1FFAB007, 0x5EB94CC1, 0x9D162DEA, 0x6517DB16,
		0x0D822E08B, 0x0CF42FE2D, 0x5D2CA41D, 0x2252E6E0, 0x94E19A2D,
		0x0BAB445BD, 0x725C0CE5, 0x4E6B118E, 0x0F2BD43D9, 0x0DD96EDDC,
		0x0C2398B82, 0x2CF72EE5, 0x56C3BFA1, 0x33639D06, 0x0BEFD5FF8,
		0x1424CF7A, 0x58D982CA, 0x2DEACA17, 0x8718BDFD, 0x0C6206BDA,
		0x0AD7C313E, 0x3CE7F39C, 0x9EF39EE7, 0x0B977CEF3, 0x0EFB9F79E,
		0x9EF3FE39, 0x0B84BF87F, 0x120DED29, 0x20DDA35E, 0x9CD120A,
		0x63C26867, 0x9FA788B5, 0x0C4C6A876, 0x3C58D1D4, 0x0A27BDE21,
		0x0FFCCEE7, 0x60C1D283, 0x0F923EBA, 0x0F074C3A6, 0x96A47E98,
		0x3795AA23, 0x0E702577B, 0x4C59B467, 0x785C5CD9, 0x86391327,
		0x9D2B33B7, 0x0D05C51C2, 0x0D5C5E5A3, 0x0E3FEB2EA, 0x37D855B9,
		0x0D53A2636, 0x4AC8B86E, 0x44F2523A, 0x644EBC4F, 0x0D67E7BFB,
		0x69966449, 0x0AA77CA4E, 0x0CBE7E53, 0x0AC85F9C2, 0x4BF3350D,
		0x9125AEF9, 0x9F9E598B, 0x0DABB662E, 0x0F9CF53D7, 0x77048AA7,
		0x4B7F073C, 0x50054431, 0x0E3686D9F, 0x0EBE08DF2, 0x0D4BC91E,
		0x80743558, 0x9A6120A2, 0x0F40EE6E8, 0x53C94ACC, 0x0FB6DA94E,
		0x0B0C56B6B, 0x0A007CAF3, 0x0F8431FF6, 0x8440780, 0x14821082,
		0x4A908843, 0x30B878DA, 0x0B6900116, 0x34000317, 0x0D270860D,
		0x7070831A, 0x77E0800E, 0x3DE4010F, 0x1FFAB007, 0x5EB94CC1,
		0x9D162DEA, 0x6517DB16, 0x0D822E08B, 0x0CF42FE2D, 0x5D2CA41D,
		0x2252E6E0, 0x94E19A2D, 0x0BAB445BD, 0x725C0CE5, 0x4E6B118E,
		0x0F2BD43D9, 0x0DD96EDDC, 0x0C2398B82, 0x2CF72EE5, 0x56C3BFA1,
		0x33639D06, 0x0BEFD5FF8, 0x1424CF7A, 0x58D982CA, 0x2DEACA17,
		0x8718BDFD, 0x0C6206BDA, 0x0AD7C313E, 0x756F6241, 0x2E2E2E74
	};
long table_407643[500] = {0};
long table_407B3D[500] = {0};
long dword_407631 = 0x31000, dword_407635 = 0x777;

int main()
{
	DWORD vm, vs, len = 255;
	MD5_CTX context;	
	long y,x,z;
	char buffer[255], *pbuffer=buffer;
	char username[255];
	unsigned char digest[16];

	// donn�es personnelles
	GetComputerName(buffer, &len);
	GetVolumeInformation(NULL, NULL, 0, &z, &vm, &vs, NULL, 0);
	_asm
	{
		mov		edx, z
		mov		eax, edx
		shr		eax, 0x10
		and		eax, 0x0FFFF
		xor		al, dh
		xor		ah, dl
		ror		edx, 3
		and		edx, 0xFFFF0000
		add		eax, edx
		mov		y, eax
	}

	printf("[o] Crapouillette keygen by biggs\n\nusername: ");
	gets(username);
	
	wsprintf(username, "%s%d%s", username, y, buffer);
	len = lstrlen(username);

	// md5 du nom mais avec magic numbers modifi�s
	MD5Init(&context);
	MD5Update(&context, (unsigned char *)username, len);
	MD5Final(&context);

	// on ajuste le digest car les bytes ne sont pas dans le bon ordre
	digest[0] = context.digest[3];
	digest[1] = context.digest[2];
	digest[2] = context.digest[1];
	digest[3] = context.digest[0];
	digest[4] = context.digest[7];
	digest[5] = context.digest[6];
	digest[6] = context.digest[5];
	digest[7] = context.digest[4];
	digest[8] = context.digest[11];
	digest[9] = context.digest[10];
	digest[10] = context.digest[9];
	digest[11] = context.digest[8];
	digest[12] = context.digest[15];
	digest[13] = context.digest[14];
	digest[14] = context.digest[13];
	digest[15] = context.digest[12];

	// pour les tables on fait le d�calage manuellement 
	// (pour �a il suffit de d'additioner la taille des variables voir listing)
	_asm
	{
		push	esi
		push	edi
		mov		eax, len
		xor		esi, esi
		mov		ecx, 0x0b8
	loc_402076:
		ror		eax, 2
		mov		edx, dword ptr[esi*4+table_40714D];
		xor		edx, eax
		mov		dword ptr[esi*4+table_407643], edx
		inc		esi
		loop	loc_402076;
		mov		ecx, 5
		xor		esi, esi
		mov		eax, 0x20
	loc_4020AB:
		cdq
		idiv	ecx
		mov		edi, edx
		mov		al, byte ptr[esi+digest]
		cmp		al, 0
		jz      short loc_402109
		cmp     esi, 4
		jge     short loc_4020C8
		xor 	al, byte ptr[edi*4+10+table_407643]
		jmp     short loc_402100
	loc_4020C8:                       
		cmp     esi, 8
		jge     short loc_4020DF
		mov     dl, byte ptr[edi*4+101+table_407643]
		ror     dl, 43h
		mov     bl, 4Dh
		xor		dl, bl
		xor		al, dl
		jmp     short loc_402100
	loc_4020DF:                
		cmp     esi, 0Ch
		jge     short loc_4020F3
		mov     dl, byte ptr [edi*4+46+table_407643]
		mov     bl, 0Dh
		sub     dl, bl
		xor		al, dl
		jmp     short loc_402100
	loc_4020F3:                   
		mov     dl, byte ptr [edi*4+68+table_407643]
		mov     bl, 50h
		add     dl, bl
		xor		al, dl
	loc_402100:              
		mov     byte ptr [esi+table_407B3D], al
		inc     esi
		jmp     short loc_4020AB
	loc_402109:              
		xor		edi, edi
		xor		edx, edx
	loc_40210D:                  
		add     edx, dword ptr[edi*4+table_407B3D]
		inc     edi
		cmp     edi, 4
		jl      short loc_40210D
		mov		eax, edx
		mov		x, edx
		wait
		fclex
		finit
		push	edx
		fild	dword ptr[esp]
		fisub	dword ptr[dword_407631]
		fldpi
		fmulp	st(1), st
		fidiv	dword ptr[dword_407635]
		fabs
		frndint
		fist	dword ptr[esp]
		pop		edx
		mov		x, edx
		pop		esi
		pop		edi
	}

	// VolumeSerialNumber + SerialDWORD ^ 0x1CAFE doit �tre �gal � "SerialId" 
	y = -(z - (x ^ 0x1CAFE));	
	
	// conversion en string (Dword2DecStr by lilith)
	RtlZeroMemory(buffer, sizeof(buffer));
	_asm
	{
		push	edi
		mov		eax, y
		mov		edi, dword ptr[pbuffer]
		mov		ebx, 0Ah
		mov		ecx, ebx
		add		edi, 09h
	_convert:
		xor		edx, edx
		div		ebx
		add		dl, 030h
		mov		byte ptr [edi], dl
		dec		edi
		loop	_convert
		pop		edi
	}
		
	printf("Serial: 100000000000000000000000000%s\n", buffer);

	getchar();
	
	return(0);
}