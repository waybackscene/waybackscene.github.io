**************************************
AddSect 1.2 by elooo
Ajouteur de section � un fichier PE
-------------------------------------
<elooo@dune2.info>
**************************************

Petit prog sans pr�tention, mais qui peut s'av�rer pratique.
Permet de rajouter une section � un fichier PE, de la taille 
minimale que l'on souhaite.
Le tool aligne le business et nous rend un binaire avec une
nouvelle section vierge pr�te � �tre remplie.

++

elooo