******************************
Un-Kassandra 1.0 par elooo...
<elooo@dune2.info>
******************************

Je m'ennuyais un peu et je suis retomb�e sur le crypteur de fichier de virtualabs, ou 
plut�t sur la 1ere version de son crypteur de binaires, il �tait toujours sur mon disque
dur.
J'ai d�cid� de faire un unpacker...
Tous les fichiers crypt�s avec cette 1ere version du crypteur ne sont pas forc�ment valides
d'ailleurs on doit modifier la SizeOfImage � la main pour rendre le binaire crypt� valide
(dans le moindre des cas), mais n'ayant pas trouv� le moyen de t�l�charger une version plus
r�cente, je me suis content�e de travailler � partir de cette version.

virtualabs ayant enlever son crypteur de son site (n'est plus accessible en t�l�chargement),
je n'ai pas voulu le fournir avec mon unpacker (� part s'il m'autorise :>), par contre j'ai
joint � l'archive un executable crypt� avec, pour ceux qui veulent s'amuser � regarder si �a
marche.

Bref j'ai encore cod� un truc inutile, mais �a m'a occup�e un peu :P
Merci virtualabs :)
Tiens-moi au courant si tu mets en t�l�chargement une nouvelle version, j'y jetterai un oeil :)

++

elooo