/*
bLaCk-eye/K23 presents
[cRYPTO-kEYGENME 3]
- based on the fact that any prime number of the form p=3k+1
can be writen in a single way as p=v^2+3*w^2
-p is obtained from the wirlpool hash of the name
-Dificulty: 2-3/10
*/
#include <iostream.h>
#include <stdio.h>
#include "mpi.h"
#include "whirlpool.c"
void main()
{
	mp_int big[4];
	mp_digit r;
	unsigned int i,j;
	char ch,name[32],activation_key[256],serial[256],name_hash[64];
	struct NESSIEstruct hash;
	for (i=0;i<4;i++)
	{
		mp_init(&big[i]);
	}
	printf("\t==========================================\n");
	printf("\t[cRYPTO-kEYGENME 3] - by bLaCk-eye/KANAL23\n");
	printf("\t==========================================\n\n");
	//get name
	printf("User-Name:");
	scanf("%32s",name);
	//get activation key
	printf("Activation-Key:");
	scanf("%512s",activation_key);
	//get serial number
	printf("Serial-Number:");
	scanf("%512s",serial);
	//check that activation key and serial is in base16 uppercase
	j=strlen(activation_key);
	
	for (i=0;i<j;i++)
	{
		ch=activation_key[i];
		if(!(((activation_key[i] >= 'A') && (activation_key[i] <= 'F')) || ((activation_key[i] >= '0') && (activation_key[i] <= '9'))))
			goto bad_serial;
	}
	j=strlen(serial);
	for (i=0;i<strlen(serial);i++)
	{
		if(!(((serial[i] >= 'A') && (serial[i] <= 'F')) || ((serial[i] >= '0') && (serial[i] <= '9'))))
			goto bad_serial;
	}
	//hash user name with wirlpool to get a 512 bit hash
	NESSIEinit(&hash);
	NESSIEadd(name,8*(strlen(name)),&hash);
	NESSIEfinalize(&hash,name_hash);
	//read two 256 bit bignums from name hash
	for (i=0;i<2;i++)
	{
		mp_read_unsigned_bin(&big[i],&name_hash[32*i],32);
	}
	//xor them
	mp_xor(&big[0],&big[1],&big[0]);
	//find next prime after first big
	//it is known that a prime of the form p=3k+1 can be writen in a unique way in the form
	// p=v^2+3*w^2
	// so the authorisation key must be v and the serial w
	// compute a prime p = 1 mod 3
	do
	{
		mp_prime_next_prime(&big[0],16,0);
		mp_mod_d(&big[0],3,&r);
	}
	while (r!=1);

	//read activation key and serial as bignums
	mp_read_radix(&big[1],activation_key,16);
	mp_read_radix(&big[2],serial,16);
	//check them
	for (i=1;i<3;i++)
	{
		mp_sqr(&big[i],&big[i]);
	}
	mp_set_int(&big[3],3);
	mp_mul(&big[2],&big[3],&big[2]);
	mp_add(&big[1],&big[2],&big[3]);
	if (mp_cmp(&big[0],&big[3])==0)
		printf("Your registration is valid.Good work cracker");
	else
bad_serial:
	printf("Your registration data is not valid!");
	for (i=0;i<4;i++)
		mp_clear(&big[i]);

}