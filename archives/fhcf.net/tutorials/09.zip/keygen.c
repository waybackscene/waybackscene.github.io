#include <string.h>
#include <stdio.h>
#include <iostream.h>

void main()
{
	unsigned long serial;
	int len;
	char name[50];

	printf("Enter your name : ");
	scanf("%s", name);

	len=strlen(name);

	__asm
	{

xor eax, eax
xor ecx, ecx
xor ebx, ebx


mu:		movsx eax, byte ptr[name+ecx]
		inc ecx
		xor eax, ecx
		add ebx, eax
		cmp ecx, [len]
		je algo
		jmp mu

algo:	shl ebx,07
		imul eax,eax,06
		add ebx, eax
		mov [serial], ebx
		
		
	}

	printf("Your serial is  : %lX", serial);

	getch();

}
                  