
Potsmoke/FHCF (potsmoke@runbox.com)
Flying Horse Cracking Force - www.fhcf.net
#Cracking.no on IRC EFNet

This is my newbie pack (to keygenning at least) for people who want to learn the "art" of keygenning.
The package contains 9 Crackme's and 9 Keygen's (8+serial that is)
These crackme's and keygen's was something i once wrote for a friend of a friend of mine who wanted to learn
how to make keygenerators.
The package contains no solution/tutorials nor source code :(
It's Potta's training kit kinda ;)
I've added two assembly instruction manuals in case you find any new/strange asm instructions that you're unsure of.
Assembly2.hlp is only needed for crackme 09.

If you're not able to do crackme 05, then it's very possible you can handle 06, 07 and so on.
Good luck!


index:

readme.txt
assembly1.hlp
assembly2.hlp
crackme 01.exe
crackme 02.exe
crackme 03.exe
crackme 04.exe
crackme 05.exe
crackme 06.exe
crackme 07.exe
crackme 08.exe
crackme 09.exe
keygen 01.exe
keygen 02.exe
keygen 03.exe
keygen 04.exe
keygen 05.exe
keygen 06.exe
keygen 07.exe
keygen 08.txt
keygen 09.exe

Lots of greets to all the FHCF members that's still in the group.
No doubt, we're here to stay ;) Love you all, thanks for everything.
Everyone who's hanging in #Cracking.no on EFNet deserve some hello's