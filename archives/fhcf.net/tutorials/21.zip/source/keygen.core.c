#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include "global.h"
#include <miracl.h>

/* MD5 context. */
typedef struct 
{
  UINT4 state[4];
  UINT4 count[2];
  unsigned char buffer[64];
} MD5_CTX;


//extern void __stdcall sub_HASHINIT(MD5_CTX*);
//extern void __stdcall sub_HASHUPDATE(MD5_CTX*, unsigned char*, unsigned int);
//extern void __stdcall sub_HASHFINAL(unsigned char [16], MD5_CTX*);
extern void sub_HASHINIT(MD5_CTX*);
extern void sub_HASHUPDATE(MD5_CTX*, unsigned char*, unsigned int);
extern void sub_HASHFINAL(unsigned char [16], MD5_CTX*);


/*
hash mod = AB6853BDD1100F57

#ecc data
a = -3
b = ADF85458A2BB4A9AAFDC5620273D3CF1D8B9C841
p = C90FDAA22168C234C4C6628B80DC1CD129024E1F
q = C90FDAA22168C234C4C5D89F4F2DD72349EE61F7

#point1
x = 1C341C34E32D5EC8F3DC83E7DA1A9DAC84E26624
y = 902166CCF366300FAF8B1CCA939C1280E5450F40

#point2
x = 5A3884AF3E676F49470F441CBEEBE7C0B1D9DF66
y = 12C34484F6C34BB886EEE052ACC6247098BEDC3C

point3 = the serial key
x = serial
y = serial + LSB (V-CODE)

*/

//#define unsigned long DWORD



char name[100];
char serial[100];
unsigned char szHash[16];
MD5_CTX HASHcontext;
HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	int i, len;

	epoint *point1, *point2, *serial_key_point3, *hash_point4;
	big a,b,p,q,x,y,hmod, big_name_hash;
	
	miracl *mip=mirsys(100,0);

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:

			len=GetDlgItemText(hWnd, IDC_EDITNAME, name, 100);
			if (len < 5)
			{
				MessageBox(hWnd, "You have to type in 5 or more chars!", "input error", MB_OK);
				break;
			}
			a=mirvar(-3);
			b=mirvar(0);
			p=mirvar(0);
			q=mirvar(0);
			x=mirvar(0);
			y=mirvar(0);
			hmod=mirvar(0);
			big_name_hash=mirvar(0);

			mip->IOBASE=16;

			cinstr(b,"ADF85458A2BB4A9AAFDC5620273D3CF1D8B9C841");
			cinstr(p,"C90FDAA22168C234C4C6628B80DC1CD129024E1F"); //prime p
			cinstr(q,"C90FDAA22168C234C4C5D89F4F2DD72349EE61F7"); //order of point

			// point1 x and y
			cinstr(x,"1C341C34E32D5EC8F3DC83E7DA1A9DAC84E26624"); 
			cinstr(y,"902166CCF366300FAF8B1CCA939C1280E5450F40"); 
			
			//HASH mod
			cinstr(hmod, "AB6853BDD1100F57");
			
			//initialise curve
			ecurve_init(a,b,p,MR_AFFINE);  
			
			// init 4 point
			point1=epoint_init();
			point2=epoint_init();
			serial_key_point3=epoint_init();
			hash_point4=epoint_init();

			//init point1
			if (!epoint_set(x,y,0,point1)) 
			{
				MessageBox(hWnd, "Problem - point1 (x,y) is not on the curve", "error", MB_OK);
				break;
			}
			
			//point2 x and y
			cinstr(x,"5A3884AF3E676F49470F441CBEEBE7C0B1D9DF66");
			cinstr(y,"12C34484F6C34BB886EEE052ACC6247098BEDC3C");

			//init point2
			if (!epoint_set(x,y,0,point2)) 
			{
				MessageBox(hWnd, "Problem - point2 (x,y) is not on the curve", "error", MB_OK);
				break;
			}

			sub_HASHINIT(&HASHcontext);
			sub_HASHUPDATE(&HASHcontext, name, len);
			sub_HASHFINAL(szHash,&HASHcontext);

			bytes_to_big(16,szHash,big_name_hash);
			//cinstr(big_name_hash, "97FCB982C7B512207986E6DC470DFBBD"); //hash value for name=Stanley

			//big_name_hash = big_name_hash ^ 3 mod hmod
			power(big_name_hash, 3, hmod, big_name_hash);
			ecurve_mult(big_name_hash,point1,hash_point4);
			ecurve_sub(point2, hash_point4);
			ecurve_add(point1, point1);
			epoint_copy(hash_point4, serial_key_point3);
			ecurve_sub(point1, serial_key_point3);
			
			//convert to compressed point. i = y's LSB
			i=epoint_get(serial_key_point3,x,x); 
			cotstr(x, serial);
			SetDlgItemInt(hWnd, IDC_EDITVCODE, i, FALSE);
			SetDlgItemText(hWnd, IDC_EDITSERIAL, serial);


			epoint_free(hash_point4);
			epoint_free(serial_key_point3);
			epoint_free(point2);
			epoint_free(point1);
			mirkill(big_name_hash);
			mirkill(hmod);
			mirkill(y);
			mirkill(x);
			mirkill(q);
			mirkill(p);
			mirkill(b);
			mirkill(a);
			mirexit();


			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "Keymaker for TMG's trial Keygenme nr.4\nProtection Elliptic Curve Point addition over GF(p) 160\nFHCF pDriLl.", "about", MB_OK);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
