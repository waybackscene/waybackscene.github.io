//   Solution pour le "KeygenMe 2" de jB
//   ...................................
//   Protec:  base32 + SHA + Xor + Math
//
//   .....par Deletere pour Infoshackers


#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <miracl.h>

	// Tableau de convertion
	char base32_i[] = "-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char base32_o[]= "-ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";	

	int position( char lettre )
	{
		int i;
		for(i=0;i<strlen(base32_i);i++)
		{
			if( base32_i[i] == lettre) { return i;}
		}
		
		return(0);
	}

	
	int main()
	{
		miracl *mip=mirsys(500,0);  /* base 0, 50 digits par big  */
	
		// variables generales
		char name[20];
		int i,j,res;	
		char char_tmp;
	
		// variables Hash
		char hash[32];
		sha256 sh;
		
		//Variables generation Serial
		big serialp;
		char xorClef[] =     {0x76, 0x7B, 0x0E6, 0x20, 0x21, 0x0C4, 0x73, 0x22, 
					     0x42, 0x0ED, 0x0F, 0x0F9, 0x97, 0x0AE, 0x66, 0x80, 0x11, 0x9C,
					     0x0B3, 0x27, 0x53, 0x34, 0x0A7, 0x0BE, 0x0D8, 0x7A, 0x0D5, 0x2F, 
					     0x5E, 0x0B6, 0x8E, 0x0CD, 0x0B0, 0x8F, 0x6E, 0x00};	
		char serial_str[90];
		char str_tmp[8];				     
		char serial[4*9];				     
		serialp = mirvar(0);

		//Variables pour la generation aleatoire
		big modulo, generateur, w, coeff_alea;	

		generateur = mirvar(0);
		coeff_alea = mirvar(0);						     
		modulo = mirvar(0);
		w = mirvar(0);
					     
		//variables routines
		big order, coeff;
		big result1;
		big hash_big;
	
	
		result1=mirvar(0);
		hash_big=mirvar(0);
		coeff=mirvar(0);
		order=mirvar(0);
	
		//Initialisation
		mip->IOBASE=16;	
		cinstr(order, "6AB353F03E1");
		cinstr(coeff, "2007C33C3B0");
		cinstr(modulo, "357A3C9D0457404AE1A83BA9DF6BD3CB7DF92C0BAD68FB3A5E9ACB9CF54E7D7A07E3");
		cinstr(generateur, "276BEBF74A8157614CBF6B2A5FD51C2B7CF3B652DCC1EB0D34FDD38BB9934D9203E2");
	
	
		/* --------------------- Start ---------------------------- */		
		printf("<<<----------- jB's KeygenMe  #2 ------------->>>\n");
		printf("+Name:    ");
		scanf("%20s",&name);
	    
		/* -----------------------[ SHA-256(Name) + bswap ]----------------------- */
		shs256_init(&sh);
		for (i=0;name[i]!=0;i++) shs256_process(&sh,name[i]);
		shs256_hash(&sh,hash);    
		for (i=0; i<8;i++)
		{
			char_tmp = hash[i*4];
			hash[i*4] = hash[i*4+3];
			hash[i*4+3] = char_tmp;
			char_tmp = hash[i*4+1];
			hash[i*4+1] = hash[i*4+2];
			hash[i*4+2] = char_tmp;		
		}
		hash[4*8]=0;
		hash[4*8+1]=0;
		hash[4*8+2]=0;
		hash[4*8+3]=0;

		bytes_to_big(4*8,hash,hash_big);   	
		/* --------------------[ Calcule le resultat � obtenir ]--------------------- */

		irand(GetTickCount());	
		bigrand(order, coeff_alea);
		xgcd(generateur,modulo,generateur,generateur,generateur);		
		powmod(generateur,coeff_alea,modulo,w);		
		multiply(hash_big, w, hash_big);
		divide(hash_big,modulo,modulo);

		multiply(hash_big,coeff,result1);
		divide(result1,order,order);			
		subtract(order,result1,result1);
		add(result1,coeff_alea,result1);
		divide(result1,order,order);		
				
		/* -----------------------------[ Calcule le Serial ]------------------------- */
		big_to_bytes(4*9,hash_big,hash,FALSE);  
		
		for(i=0; i<(4*9);i++)
		{
			serial[i] = xorClef[i] ^ hash[i];	
		}
		
		for(i=0; i<(9);i++)
		{
			char_tmp = serial[i*4] ;
			serial[i*4] = serial[i*4+3];
			serial[i*4+3] = char_tmp;
			char_tmp = serial[i*4+1] ;
			serial[i*4+1] = serial[i*4+2];
			serial[i*4+2] = char_tmp;		
		}		
		
		
		/* --------------------- Mise en forme du serial ---------------------------- */		
		strcpy(serial_str ,"");
		
		
		for(i=0;i<9;i++)
		{
			mip->IOBASE=16;	
			bytes_to_big(4,&(serial[i*4]),serialp);
			mip->IOBASE=32;
			cotstr(serialp,str_tmp);	
			strcat(serial_str,str_tmp);
			if(i<8) { strcat(serial_str,"-"); }
		}
	
		res = strlen(serial_str);	
		for( i=0; i<res;i++)
		{
			j = position(serial_str[i]);
			serial_str[i] = base32_o[j];
		}		
		
		/* --------------------- Affichage resultat ---------------------------- */

		printf("+ID:      ");
		mip->IOBASE=10;
		cotnum(result1,stdout);	
		printf("+Serial:  ");
		printf(serial_str);	
		printf("\n<<------------ Solved by Deletere ------------>>");
		printf("\n<<  a.k.a  [6A683678B9636CD5119580E2054A2B52] >>");				
		getch();	                  
		/* ---------------------------------------------------------------------------- */
	
		
		return 0;
	}
