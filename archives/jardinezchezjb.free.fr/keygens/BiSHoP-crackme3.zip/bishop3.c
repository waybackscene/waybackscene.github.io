/************************************
  BiSHoP's Crackme #3
  Keygen by jB

  Date: 27/12/2003
  Protection: RSA-32
************************************/

#include "stdafx.h"
#include <string.h>

__int64 pow(
			__int64 x,
			__int64 e,
			unsigned __int64 m)
{
  __int64 t ;
  if(e==0) return 1;
  if(e==1) return x % m;
  else {
	  t=pow(x,e/2,m);
	  if(e%2==0) return t*t%m;
	  else return t*t%m*x%m;
  }
}

int main(int argc, char* argv[])
{
	char nom[50];
	unsigned int hash;

	printf("BiSHoP's Crackme #3\nKeygen by jB\n\nName:\t");
	gets(nom);
	if(!strlen(nom))
		printf("Please enter a name\n");
	else {		

		__asm{
				xor		eax, eax
				xor		ecx, ecx
				xor		ebx, ebx
				lea		esi, nom
				cld
		_HN1:	
				inc		ecx
				lodsb
				test	al, al
				je		_HN2
				mul		eax
				rol		eax, cl
				add		ebx, eax
				jmp		_HN1
		_HN2:	imul	ebx, ebx
				mov		eax, ebx
				shr		eax, 2
				imul	ebx, eax
				mov		hash, ebx
		}

	printf("Serial:\t%010lu\n",pow(hash,0xe6caf5c5,0xead2c511));
	}
	return 0;
}

