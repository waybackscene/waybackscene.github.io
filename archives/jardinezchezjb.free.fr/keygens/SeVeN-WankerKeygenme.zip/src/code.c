/*
WankerKeygenme by SeVeN
Keygen by jB

Protection: Rijndael, modified MD4
Compiled with lcc
*/

#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include <windowsx.h> 
#include <time.h>
#include "resource.h" 
#include "md4.h"

void gentables(void);
void gkey(int nb,int nk,char *key);
void encrypt(char *buff);
void decrypt(char *buff);

HINSTANCE hInst;
BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam);  
void GenererSerial(HWND hwnd);

unsigned char initname[] = "jB / FFF";
unsigned char serial[300];


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;  
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			srand(time(NULL));
			SetDlgItemText(hwnd, IDC_NAME, initname);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));	
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_GENERER: 
				GenererSerial(hwnd);
				break;
			case IDC_ABOUT:
				MessageBox(hwnd, "WankerKeygenme by SeVeN\nKeygen by jB\n\nProtection: Rijndael, Modified MD4","About...",MB_ICONINFORMATION | MB_OK | MB_APPLMODAL);
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}

void GenererSerial(HWND hwnd){
	int i;
    MD4_CTX context;
    unsigned char digest[16];
    
    char key[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7};
    char userid[10];
    
    unsigned char name[100];
	int id;
	unsigned char hash[90];
	unsigned char block[300];
	
	memset(name, 0, sizeof(name));
	GetDlgItemText(hwnd,IDC_NAME,name,100);
	
	if(!strlen(name)){
    	SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a name");
    	return;
	}
		
		
	/* On cherche un id tel que le hash MD4 du nom concat�n� � l'id commence par 77 */
	id=rand();
	while(digest[0]!=0x77){
		id++;
		sprintf(block, "%s%X",name,id);
		MD4Init (&context); /* Modified (see MD4.C, a constant has been changed) */
		MD4Update (&context, block, strlen(block));
		MD4Final (digest, &context);
	}
		
	for(i=0;i<16;i++) sprintf(hash+2*i,"%02X",digest[i]);

	/* Initialisation des tables pour Rijndael */
    gentables();
    
    for(i=0;i<300;i++) block[i]=0;
	strcpy(block, name);
	sprintf(block+100,"%X",id);
	strcpy(block+150,hash);
	block[0x4C]='X';
	
	/* Initialisation de la cl� */
    gkey(4,4,key);
	
	/* Chiffrement par blocs de 128 bits du buffer contenant le nom, l'ID et le hash MD4 */
	for(int j=0;j<16;j++){
    	encrypt(block+16*j);
    	for (i=0;i<4*4;i++) sprintf(serial+2*i+32*j,"%02X",(unsigned char)block[i+16*j]);	
	}
	sprintf(userid,"%X",id);
	SetDlgItemText(hwnd, IDC_USERID, userid);
	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	
}