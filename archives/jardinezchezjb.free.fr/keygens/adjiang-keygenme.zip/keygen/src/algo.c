/*
* Adjiang - Keygenme
* Keygen par jB
* Feb. 12th 2005
* Protection: MD5, Base64
*/

#include <windows.h>
#include <openssl/md5.h>
#include "resource.h"

void to64frombits(unsigned char *out, const unsigned char *in, int inlen);

#define MIN_NAME 1
#define MAX_NAME 100
#define MAX_SERIAL 100

void GenererSerial(HWND hwnd){
	char name[MAX_NAME];
	char serial[MAX_SERIAL];
	char buffer[300];
	char buffer2[10];
	char b64stuff[100];
	unsigned char digest[16];
	char prodid[20];
	int i, len;
	unsigned int delta, tmp;

	len=GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);
	if(len < MIN_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a longer name");
		return;
	}

	GetDlgItemText(hwnd,IDC_ID,prodid,20);

	to64frombits(buffer, prodid, strlen(prodid));
	strcpy(b64stuff, buffer);
	to64frombits(buffer, name, strlen(name));
	strcat(b64stuff, buffer);

	MD5(b64stuff, strlen(b64stuff), digest);
	for(i=0; i<16; i++)
		wsprintf(buffer+2*i, "%02x", digest[i]);
	MD5(buffer, strlen(buffer), digest);
	for(i=0; i<16; i++)
		wsprintf(serial+2*i, "%02x", digest[i]);

	memset(buffer, 0, sizeof(buffer));
	for(i=1; i <= 32; i++)
	{
		delta = 0x3F340 * i;
		tmp = delta + i * (i+1) * (i+1);
		tmp += serial[i-1] ^ (i+1);
		tmp ^= i * (i+1);

		/* sin, cos, and ... not needed */

		tmp += 32 | i;
		wsprintf(buffer2, "%d", tmp);
		strcat(buffer, buffer2);
	}

	MD5(buffer, strlen(buffer), digest);
	for(i=0; i < 16; i++)
		wsprintf(buffer+2*i, "%02x", digest[i]);

	_strrev(buffer);
	for(i=1; i <= 32; i++)
	{
		if(((delta+i*2) % i) %2 ==0)
			buffer[i-1]=tolower(buffer[i-1]);
		else buffer[i-1]=toupper(buffer[i-1]);
	}
	MD5(buffer, 32, digest);
	for(i=0; i < 16; i++)
		wsprintf(serial+2*i, "%02X", digest[i]);

	SetDlgItemText(hwnd, IDC_SERIAL,serial);
}