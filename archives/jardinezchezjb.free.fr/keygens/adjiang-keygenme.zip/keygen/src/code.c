#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include "resource.h"

void GenererSerial(HWND hwnd);

HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"Keygenme by Adjiang - Keygen");
			SetDlgItemText(hwnd,IDC_NAME,"jB / FFF");
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_NAME:
			case IDC_ID:
   				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}
