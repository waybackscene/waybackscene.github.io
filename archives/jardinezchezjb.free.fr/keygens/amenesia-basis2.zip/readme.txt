Amenesia's Basis#2 Keygenme
RSA-1024

R�solution en utilisant l'attaque de Wiener
Script Maple dans Wiener.mws