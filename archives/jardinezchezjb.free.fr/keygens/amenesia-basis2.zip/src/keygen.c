#include <stdio.h>
#include <string.h>
#include "miracl.h"
#include "global.h"
#include "md5.h"

int main()
{
    unsigned char szHash[41] = {0};
    unsigned char lpName[50];

    MD5_CTX context;
    
    miracl *mip=mirsys(500,16);
    big Hash_M   =mirvar(0);    
    big N        =mirvar(0);
    big D        =mirvar(0);

    mip->IOBASE=16;
    cinstr(N,"7D4C538A3766CA67C73534105AB812817E0E3C5F1CC3853136AAC8279D501EB51572226C060D420A70331348B6E0F1974DFB969B7BE30E31F8128EAF3A0CBE4D5C134528AD61E707AC3E6233BF5755DA4FDB63E48AC053A00D227C3A9B031FC282157CB3071ECA94013140ABC1F886DE9EBF6ED1C39965ECF46846BF74BFC681");
    cinstr(D,"EB192BBCF26A8C61E7B8BEBB7D7A3C6B");

    printf("Name: ");
    gets(lpName);
      
    MD5Init(&context);
    MD5Update(&context, lpName, strlen(lpName));
    MD5Final(szHash, &context);
    bytes_to_big(16,szHash,Hash_M);
     
    powmod(Hash_M,D,N,Hash_M);
    cotnum(Hash_M,stdout);

    mirkill(Hash_M);
    mirkill(N);
    mirkill(D);
    mirexit();
    return 0;
}


