////////////////////////////////////////////////////////////
// Bigbang - Citron Keygenme
// Keygen by jB
// Jul. 22th, 2005
//
// SHA-1, RIPEMD-160, CRT
////////////////////////////////////////////////////////////


#define WIN32_LEAN_AND_MEAN

#include <windows.h> 	
#include "resource.h"
#include "miracl.h"
#include "mhash_ripemd.h"

#define MIN_NAME 2
#define MAX_NAME 32

DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"Citron Keygenme by Bigbang");
			SetDlgItemText(hwnd,IDC_NAME,"jB");			
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

DWORD WINAPI GenererSerial(HWND hwnd){
	miracl *mip=mirsys(200,0);
    char name[35];
	char serial[1000];
	unsigned char s[20];
	
	int i,len;

	big bigserial;

	big *hash;
	big *leet;
	big *primes;
	big_chinese bc;

	sha sh;
	RIPEMD_CTX rmd;

	GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);
	len=strlen(name);
	if(len<MIN_NAME || len>MAX_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a valid name...");
		return 0;
	}

	hash=malloc(len*sizeof(big));
	leet=malloc(len*sizeof(big));
	primes=malloc(len*sizeof(big));

	bigserial=mirvar(0);
	for(i=0;i<len;i++){
		hash[i]=mirvar(0);
		leet[i]=mirvar(0);
		primes[i]=mirvar(0);
	}

	mip->IOBASE=16;
	
	cinstr(leet[0],"13333333333333333333333333333333337");
	for(i=1;i<len;i++)
		premult(leet[0],i,leet[i]);

	cinstr(primes[0],"8A8335C1EBA9406AE57DCC8BDAD59D2B");
	for(i=1;i<len;i++)
		nxprime(primes[i-1],primes[i]);

	for(i=0;i<len;i++){
		if(i%2==0){
			ripemd160_init(&rmd);
			ripemd_update(&rmd,name+i,1);
			ripemd_final(&rmd);
			ripemd_digest(&rmd,s);
		}
		else{
			shs_init(&sh);	
			shs_process(&sh,name[i]);
			shs_hash(&sh,s);
		}
		bytes_to_big(20,s,hash[i]);
	}

	for(i=0;i<len;i++)
		multiply(leet[i],hash[i],leet[i]);

    crt_init(&bc,len,primes);
	crt(&bc,leet,bigserial);
	crt_end(&bc);
	mip->IOBASE=32;
	cotstr(bigserial,serial);
	SetDlgItemText(hwnd,IDC_SERIAL,serial);

	for(i=0;i<len;i++){
		mirkill(hash[i]);
		mirkill(leet[i]);
		mirkill(primes[i]);
	}
	mirkill(bigserial);
	mirexit();
    return 0;
}