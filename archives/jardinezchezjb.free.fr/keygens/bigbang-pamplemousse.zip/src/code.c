////////////////////////////////////////////////////////////
// Bigbang - Pamplemousse Keygenme
// Keygen by jB
// Jul. 17th, 2005
//
// Modified SHA-1, RSA-222, Runtime DLP Solving (221 bits)
////////////////////////////////////////////////////////////


#define WIN32_LEAN_AND_MEAN

#include <windows.h> 	
#include "resource.h"
#include "miracl.h"

#define MAX_NAME 40

DWORD WINAPI GenererSerial(LPDWORD lpParam);
BOOL working=0;
HINSTANCE hInst;
HWND hsb;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
	HANDLE hThread;
	DWORD dwThreadId;

   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			hsb = CreateStatusWindow(WS_CHILD | WS_VISIBLE | WS_DISABLED, NULL, hwnd, -1);
			SetWindowText(hwnd,"Pamplemousse Keygenme by Bigbang");
			SetDlgItemText(hwnd,IDC_NAME,"jB");			
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_GENERATE:
				if(working==0){
					hThread=CreateThread(NULL,0,GenererSerial,hwnd,0,&dwThreadId);
					CloseHandle(hThread);
				}
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}


static big p,p1,order,lim1,lim2;

void iterate(big x,big q,big r,big a,big b)
{ /* apply Pollards random mapping */
    if (compare(x,lim1)<0)
    {
        mad(x,q,q,p,p,x);
        incr(a,1,a);
        if (compare(a,order)==0) zero(a);
        return;
    }
    if (compare(x,lim2)<0)
    {
        mad(x,x,x,p,p,x);
        premult(a,2,a);
        if (compare(a,order)>=0) subtract(a,order,a);
        premult(b,2,b);
        if (compare(b,order)>=0) subtract(b,order,b);
        return;
    }
    mad(x,r,r,p,p,x);
    incr(b,1,b);
    if (compare(b,order)==0) zero(b);
}

long rho(big q,big r,big m,big n)
{ /* find q^m = r^n */
    long iter,rr,i;
    big ax,bx,ay,by,x,y;
    ax=mirvar(0);
    bx=mirvar(0);
    ay=mirvar(0);
    by=mirvar(0);
    x=mirvar(1);
    y=mirvar(1);
    iter=0L;
    rr=1L;
    do
    { /* Brent's Cycle finder */
        copy(y,x);
        copy(ay,ax);
        copy(by,bx);
        rr*=2;
        for (i=1;i<=rr;i++)
        {
            iter++;
            iterate(y,q,r,ay,by);
            if (compare(x,y)==0) break;
        }
    } while (compare(x,y)!=0);

    subtract(ax,ay,m);
    if (size(m)<0) add(m,order,m);
    subtract(by,bx,n);
    if (size(n)<0) add(n,order,n);
    mirkill(y);
    mirkill(x);
    mirkill(by);
    mirkill(ay);
    mirkill(bx);
    mirkill(ax);
    return iter;
}

void dlog(big q,big x){
    int i,id,np=8;
    long iter;
    big pp[8],rem[8];
    big m,n,Q,R,w,proot;
    big_chinese bc;

    for (i=0;i<8;i++) 
    {
        pp[i]=mirvar(0);
        rem[i]=mirvar(0);
    }

	cinstr(pp[0],"2");
	cinstr(pp[1],"5751247");
	cinstr(pp[2],"81514567");
	cinstr(pp[3],"273749507");
	cinstr(pp[4],"85717369999");
	cinstr(pp[5],"254289209159");
	cinstr(pp[6],"254289208463");
	cinstr(pp[7],"2255442769");

    proot=mirvar(0);
    cinstr(proot,"1248310966923498661164204883260437277137373139593887776277032788073");
    Q=mirvar(0);
    R=mirvar(0);
    w=mirvar(0);
    m=mirvar(0);
    n=mirvar(0);
    order=mirvar(0);
    lim1=mirvar(0);
    lim2=mirvar(0);

    subdiv(p,3,lim1);
    premult(lim1,2,lim2);

    crt_init(&bc,np,pp);
    for (i=0;i<np;i++)
    { /* accumulate solutions for each pp */
        copy(p1,w);
        divide(w,pp[i],w);
        powmod(q,w,p,Q);
        powmod(proot,w,p,R);
        copy(pp[i],order);
        iter=rho(Q,R,m,n);
        xgcd(m,order,w,w,w);
        mad(w,n,n,order,order,rem[i]);
    }
    crt(&bc,rem,x);   /* apply Chinese remainder thereom */
	crt_end(&bc);
}

void shs_mod_init(sha *sh){
    int i;
    for (i=0;i<80;i++) sh->w[i]=0L;
    sh->length[0]=sh->length[1]=0L;
    sh->h[0]=0xD76AA478;
    sh->h[1]=0xE8C7B756;
    sh->h[2]=0x242070DB;
    sh->h[3]=0xC1BDCEEE;
    sh->h[4]=0xF57C0FAF;
}


DWORD WINAPI GenererSerial(LPDWORD lParam){
	working=1;

	int timing=GetTickCount();
	char status[30];
	miracl *mip=mirsys(100,0);
    char name[MAX_NAME];
	unsigned char s[20];
	char serial[160];
	char serial2[150];
	int i,len;
	big d,n,h,k1,k2,k3,y,x,prod;
	sha sh;	
	HWND hwnd=lParam;

	d=mirvar(0);
	n=mirvar(0);	
    h=mirvar(0);
	k1=mirvar(0);
	k2=mirvar(0);
	k3=mirvar(0);
	y=mirvar(0);
	x=mirvar(0);
	p=mirvar(0);
	p1=mirvar(0);
	prod=mirvar(1);

	GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);
	len=strlen(name);
	if(len<3)
		
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");

	else{
		SetWindowText(hsb,"Computing...");
		
		/* Hashes the name (mod. sha1) */
		shs_mod_init(&sh);
		for(i=0;i<len;i++)
			shs_process(&sh,name[i]);
		shs_hash(&sh,s);
		bytes_to_big(20,s,h);
		
		/* Compute the product of the letters of the name */
		for(i=0;i<len;i++)
			premult(prod,name[i],prod);

		/* y=(h^2 + k2*h - k1) * k3 */
		cinstr(p,"3208758980294089871636889325639601519765013105042818745876534106523");
		decr(p,1,p1);
		
		cinstr(k1,"1773271064686560587820667929507643844698995393927369207197395876199");
		cinstr(k2,"3095686110978534270449564634302156571221848807021125734173606119798");
		cinstr(k3,"3000012301762800807161335896594829130123128277845811946826175383306");
		multiply(h,h,y);

		multiply(k2,h,k2);

		add(y,k2,y);
		subtract(y,k1,y);
		mad(k3,y,y,p,p,y);

		/* Computes the discrete logarithm using Rho */
		dlog(y,x);

		/* RSA stuff. Computes x^d mod n */
		cinstr(d,"3993456530636491400257067550541140435675559271072172667651748646157");
		cinstr(n,"4109509431769244994089516623957980949881759417131294476885470163057");
		powmod(x,d,n,x);

		printf("Serial:\t");
		cotstr(x,serial);
		strcat(serial,"-");

		mip->IOBASE=9;
		cotstr(prod,serial2);
		strcat(serial,serial2);
		SetDlgItemText(hwnd, IDC_SERIAL,serial);

		timing=GetTickCount()-timing;
		sprintf(status,"Serial generated in %lu.%lus",timing/1000,timing%1000);
		SetWindowText(hsb,status);
    }
	mirkill(d);
	mirkill(n);
	mirkill(h);
	mirkill(k1);
	mirkill(k2);
	mirkill(k3);
	mirkill(y);
	mirkill(x);
	mirkill(prod);
	mirexit();

	working=0;
	return 0;
}