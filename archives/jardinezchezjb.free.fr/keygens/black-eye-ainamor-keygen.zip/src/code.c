/*	AiNAMOR cRYPTO cRACKME by bLaCk-eye
	Keygen by jB
	Jun. 2nd, 2005

	Protection: modular maths (RSA-512)

	res1 = (s+2*e*crc^3-h^3)*h
	res2 = (s-e*crc^3+2*h^3)*crc
	  and we must have:
	m = res1*res2^(-1) mod n,
	  where
	s is the serial
	h is the MD5 hash of the name
	crc is a home-made 32 bit hash of the name
	e,n,m are constants

	So:
	res1 = m*res2 mod n
	ie: (s+2*e*crc^3-h^3)*h = (s-e*crc^3+2*h^3)*crc*m
	ie: s*h + (2*e*crc^3-h^3)*h = s*crc*m + (-e*crc^3+2*h^3)*crc*m
	ie: s*(h-crc*m) = (-e*crc^3+2*h^3)*crc*m - (2*e*crc^3-h^3)*h
	ie: s = ((-e*crc^3+2*h^3)*crc*m - (2*e*crc^3-h^3)*h) * (h-crc*m)^(-1) mod n

	Then you convert the serial into base 60, and it's ok.
*/

#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include <windowsx.h>
#include "resource.h"
#include "miracl.h"
#include "global.h"
#include "md5.h"

void GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"AiNAMOR cRYPTO cRACKME");
			SetDlgItemText(hwnd,IDC_NAME,"jB");

			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_NAME:
   				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}


DWORD CRC(unsigned int param, unsigned char *name, int len){
	unsigned int a;
	unsigned int b;
	int i;

	a = param&0xFFFF;
	b = param >> 0x10;
	for(i=0;i<len;i++){
		a = (name[i]+a) % 0xFFF1;
		b = (b+a) % 0xFFF1;
	}
	return (b<<0x10)+a;
}


#define MAX_NAME 100

void GenererSerial(HWND hwnd){
	char name[MAX_NAME];
	char serial[MAX_NAME];
	big m,e,n,h,h3,crc_big,res1,res2;
	int i,crc;
	MD5_CTX context;
	unsigned char szHash[41] = {0};

    miracl *mip;
    mip =mirsys(100,0);
    
	memset(&name,0,MAX_NAME);
	memset(&serial,0,MAX_NAME);

	GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);

	n=mirvar(0);
    m=mirvar(0);
    e=mirvar(0);
	h=mirvar(0);
	h3=mirvar(0);
	crc_big=mirvar(0);
	res1=mirvar(0);
	res2=mirvar(0);

	mip->IOBASE=60;

	// constants taken from the crackme
	bytes_to_big(40,"RSA = R. Rivest + A. Shamir + L. Adleman",m);
	cinstr(e,"d1WJGnkJiFAJReBRRmEBlNYJs6AK5p82TZFbUX8lnL1IbLoHpfWx9G0jetjscI3tGQ5Bf3PwI6x6HJcTi4sGVu");
	cinstr(n,"8xl1BRa4boktp7B5v3mw7xXQpITKXDnfUng7KqY3nUHGgAQCOVqLNj4b0IulVfaRadA0iQgalrLsXJa6orf8flb");

	MD5Init(&context);
	MD5Update(&context, name, strlen(name));
	MD5Final(szHash, &context);

	bytes_to_big(16,szHash,h);
	crc=CRC(0xFFFFFFFF,name,strlen(name));

	premult(m,crc,m);
	power(h,3,n,h);
	premult(h,2,h);
	lgconv(crc,crc_big);
	power(crc_big,3,n,crc_big);
	multiply(crc_big,e,crc_big);
	subtract(h,crc_big,h);
	multiply(m,h,res1);			// res1 = m*crc*(2h^3-e*crc^3)


	bytes_to_big(16,szHash,h);
	power(h,3,n,h3);
	lgconv(crc,crc_big);
	power(crc_big,3,n,crc_big);
	multiply(e,crc_big,e);
	premult(e,2,e);
	subtract(e,h3,e);
	multiply(h,e,res2);			// res2 = h*(2*e*crc^3-h^3)

	subtract(res1,res2,res1);	// res1 = res1-res2

	subtract(h,m,h);
	xgcd(h,n,h,h,h);
	multiply(res1,h,res1);
	divide(res1,n,n);			// res1 = res1 * (h-m*crc)^(-1) mod n

	while(exsign(res1)==-1)
		add(res1,n,res1);
	cotstr(res1,serial);
	
	SetDlgItemText(hwnd, IDC_SERIAL,serial);

	mirkill(res2);
	mirkill(res1);
	mirkill(crc_big);
	mirkill(h3);
	mirkill(h);
	mirkill(m);
	mirkill(e);
	mirkill(n);

	mirexit();
}