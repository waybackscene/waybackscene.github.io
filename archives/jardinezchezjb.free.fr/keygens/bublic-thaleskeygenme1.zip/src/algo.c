/**********************************************************************
The name entered is hashed using a (slightly modified) CRC32. From the
two words of the hash are generated two values, let's call them h1, h2.

The serial is composed of 4 32 bits parts. Each part is divided by 1e6
and converted into a float. The 4 parts (s1, s2, s3, s4) must satisfy:

s1 ^ 2 + s3 ^ 2 = 65536
s2 ^ 2 + s4 ^ 2 = 65536
s3 / s1 * (h1 - s3) / (h1 - s1) = -1
s4 / s2 * (h2 - s4) / (h1 - s2) = -1

It is a system of four equations with 4 variables, that can be solved
rather easily using any decent math tool. But we can consider these
equations from a geometrical point of view:
 - If A(s1, s3), B(s2, s4) and H(h1, h2) are points, the two first
 equations verify that A and B are on the circle (C) of center O and of
 radius 256.
 - s4 / s2 is the coefficient of (OA); (h1 - s3) / (h1 - s1) the
 coefficient of (HA). Their product is equal to -1 if and only if they
 are perpendicular. It is the same for (OB) and (HB) in  the 4th equation.

We have to find the points A and B such as A and B are on (C), and such as
(OA) _|_ (HA) and (OB) _|_ (HB), ie the contact point of the two tangents
of (C) passing by H.

I guess there are several solutions to find them. I considered the circle
(C') of center H'(h1 / 2, h2 / 2) and of diameter d = sqrt(h1 ^ 2 + h2 ^ 2).
This circle passes by O, H and cuts (C) in two points F, G such as OFH and
OGH are rectangle triangle (Thales Theorem). So F, G are the points A, B
we are searching for.

Let Phi the angle between (OH') and (H'A). OH'A is an isocele triangle.
Using the mediane passing by H, you find :
Phi / 2 = (r / 2) / (d / 2) so : Phi = 2 * asin(r / d).

From now you can compute the coordinates of the points A and B, which are
the point of (C') such as (H'O, H'A) = Phi and (H'O, H'B) = - Phi.

You obtain :
s1 = -h1 / 2 * cos(theta) + h2 / 2 * sin(theta) + h1/2;
s3 = -h1 / 2 * sin(theta) - h2 / 2 * cos(theta) + h2/2;
s2 = -h1 / 2 * cos(theta) - h2 / 2 * sin(theta) + h1/2;
s4 =  h1 / 2 * sin(theta) - h2 / 2 * cos(theta) + h2/2;

I modified a bit the equations if my keygen, but the result is exactly
the same. I use acos instead of asin, because of a previous error I did
before, but the explanation is easier using asin.

I hope you understood something, my English is not that good for that kind
of stuff. And take a pen and a paper, it will really be easier.

/*********************************************************************/

#include <windows.h>
#include <stdio.h>
#include <math.h>

unsigned int crc32(const void *buf, int size);

void process_serial(char *name, char *serial)
{
	DWORD s1, s2, s3, s4;
	unsigned int crc = crc32(name, strlen(name));
	double h1 = (float)(HIWORD(crc) % 0x2006 + 0x100);
	double h2 = (float)(LOWORD(crc) % 0x2006 + 0x100);
	
	double d = _hypot(h1, h2);
	double theta = 2 * acos(256 / d);
	
	double x1 = h1 / 2 * (1 + cos(theta)) - h2 / 2 * sin(theta);
	double y1 = h2 / 2 * (1 + cos(theta)) + h1 / 2 * sin(theta);
	double x2 = h1 / 2 * (1 + cos(theta)) + h2 / 2 * sin(theta);
	double y2 = h2 / 2 * (1 + cos(theta)) - h1 / 2 * sin(theta);

	s1 = x1 * 1e6;
	s2 = x2 * 1e6;
	s3 = y1 * 1e6;
	s4 = y2 * 1e6;

	sprintf(serial, "%08X-%08X-%08X-%08X", s1, s2, s3, s4);
}

