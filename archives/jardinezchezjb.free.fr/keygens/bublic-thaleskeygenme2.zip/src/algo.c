/**********************************************************************
The serial check is almost the same as the one in the first keygenme.
The name entered is hashed using a (slightly modified) CRC32. From the
two words of the hash are generated two values, let's call them h1, h2.

The serial is composed of 4 32 bits parts. Each part is divided by 1e5
and converted into a float. The 4 parts (s1, s2, s3, s4) must satisfy:

s2 ^ 2 + s4 ^ 2 = 65536
(s3 - h2) ^ 2 + (s1 - h1) ^ 2 = 112896
s4 / s2 * (s4 - s3) / (s2 - s1) = -1
(s4 - s3) / (s2 - s1) * (s3 - h2) / (s1 - h1) = -1

From a geometric point of view that means that the serial must verify:
 - If A(s2, s4), B(s1, s3) and H(h1, h2) are viewed as points, the two
 first equations verify that A is on the circle (C) of center O and of
 radius 256, and that B is on the circle (C') of center O' and of
 radius 336.
 - (OB) _|_ (AB) and (AB) _|_ (AH) (See Keygenme 1 for more details).

We have to find the points A and B such as (AB) is a tangent of the two
circles (C) and (C'). Take a paper to understand.

We can find the intersection point P between (AB) and (OH). As (AB) passes
through this point we can apply the result found in the first keygenme to
find A and B coordinates.
PO / PH = OA / HB so PO / (PO + OH) = 256 / 336
Finally PO = 256 / (336 - 256) OH
So Px = -256 / (336 - 256) * h1;
   Py = -256 / (336 - 256) * h2;

We can find B using exactly the same method as in the first keygenme. As you
can notice the method is the same for A, but the calculus are a bit more
complicated (because H != (0, 0)). You shouldn't have any problem to solve
them if you have understood the first solution.

/*********************************************************************/

#include <windows.h>
#include <stdio.h>
#include <math.h>

unsigned int crc32(const void *buf, int size);

void process_serial(char *name, char *serial)
{
	DWORD s1, s2, s3, s4;
	double d, theta, x1, x2, y1, y2;
	unsigned int crc = crc32(name, strlen(name));
	double h1 = (double)(HIWORD(crc) % 0x2006 + 0x100);
	double h2 = (double)(LOWORD(crc) % 0x2006 + 0x100);	
	
	/* Find P */
	double xp = -256. / (336. - 256.) * h1;
	double yp = -256. / (336. - 256.) * h2;

	/* Get B coordinates */
	d = _hypot(xp, yp);
	theta = 2 * asin(256 / d);
	x1 = -xp / 2 * cos(theta) + yp / 2 * sin(theta) + xp / 2;
	y1 = -yp / 2 * cos(theta) - xp / 2 * sin(theta) + yp / 2;

	/* Get A coordinates */
	d = _hypot(h1 - xp, h2 - yp);
	theta = 2 * asin (336 / d);
	x2 = (h1 - xp) / 2 * cos(theta) - (h2 - yp) / 2 * sin(theta) + (h1 + xp) / 2;
	y2 = (h2 - yp) / 2 * cos(theta) + (h1 - xp) / 2 * sin(theta) + (h2 + yp) / 2;

	s1 = (DWORD)(x2 * 1e5);
	s2 = (DWORD)(x1 * 1e5);
	s3 = (DWORD)(y2 * 1e5);
	s4 = (DWORD)(y1 * 1e5);
	sprintf(serial, "%08X-%08X-%08X-%08X", s1, s2, s3, s4);
}

