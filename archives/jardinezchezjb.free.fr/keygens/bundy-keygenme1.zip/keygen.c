/*************************************************
   bundy's keygenme #1 - Keygen by jB

   Date: 30 dec. 2003
   Protection: Modular math (and not RSA-512 :))
*************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "miracl.h"
#include <windows.h>
#include <time.h>

int main()
{
	miracl *mip=mirsys(50,0);

	big n=mirvar(0);
	big e=mirvar(0);
	big M=mirvar(0);

	char nom[50];
	mip->IOBASE=16;

	cinstr(n,"8FD312A230FE4096F59566AAC6D6229FBBCAA08B23835F78A77B7DF4C9FA723A15E5FB6D5B555670313B2AE346402217FEF2C60896460804999516B1502AEF51");
	cinstr(e,"9F2F8283");

	printf("bundy's keygenme #1\n");
	printf("Keygen by jB\n\n");
	printf("Name:\t");
	gets(nom);
	bytes_to_big(strlen(nom),nom,M);

	powmod(M,e,n,M);
	xgcd(M,n,M,M,M);

	printf("Serial:\t61BA19A2-");
	cotnum(M,stdout);

	mirkill(n);
	mirkill(M);
	mirkill(e);

	getchar();
	return(0);
}
