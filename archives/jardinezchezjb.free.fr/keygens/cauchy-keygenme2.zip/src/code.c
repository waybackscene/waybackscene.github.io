/*
KeygenMe#2 by Cauchy
Keygen by jB

Protection: Taylor expansion
Compiled with lcc

Some short explanations:
The sum of the chars of the name is computed (except the first letter), then is divided by 10.
The "-" of the serial is replaced by a ".", then the serial is converted from ASCII to a float s.
Then there's this calculus:
 res = 1 + s/1 + s/1*s/2 + s/1*s/2*s/3 + ... + s/1*s/2*...*s/8190*s/8191
     = 1 + s/1 + s^2/2! + s^3/3! + s^8191/8191!
which is the Talor expansion of order 0x2000 of the exp function.
res is then divided by 10, and compared to the sum of the letters

So to obtain a valid serial, compute the sum of the letters, then its logarithm and it is ok.
*/

#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include <windowsx.h>
#include <math.h>
#include "resource.h"

void GenererSerial(HWND hwnd);
HINSTANCE hInst;
BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam);  

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;  
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"KeygenMe#2 by Cauchy - Keygen");
			SetFocus(GetDlgItem(hwnd,IDC_NAME));	
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_NAME: 
				GenererSerial(hwnd);
				break;
			case IDC_ABOUT:
				MessageBox(hwnd, "KeygenMe#2 by Cauchy\nKeygen by jB\n\nProtection: Taylor expansion","About...",MB_ICONINFORMATION | MB_OK | MB_APPLMODAL);
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}

#define MIN_NAME 5
#define MAX_NAME 100

void GenererSerial(HWND hwnd){	
	char serial[40];
	char *pos;
	char name[MAX_NAME];
	int len,i;
	double sum=0;
	
	memset(&name,0,MAX_NAME);
	len=GetDlgItemText(hwnd,IDC_NAME,name,100);
	
	if(strlen(name)<MIN_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a longer name");
		return;
	}
	
	for(i=1;i<len;i++)
		sum+=name[i];					/* Computes the sum of the letters of the name */

	if(sum<=0){
		SetDlgItemText(hwnd, IDC_SERIAL, "No serial for this name");
		return;
	}
	
	sum/=10;
	sum=floor(sum);
	sum*=10;
	sum+=0.5;							/* To avoid precision errors due to floor (check by yourself) */
	sprintf(serial,"%.10f",log(sum));
	pos=strchr(serial,'.'); 			/* Replaces the "." with a "-" */
	if(pos!=0) *pos='-';

	SetDlgItemText(hwnd, IDC_SERIAL, serial);
}