/**********************************************************************
RSA-640

The public key uses the RSA-640 challenge modulus:
31074182404900437213507500358885679300373460228427
27545720161948823206440518081504556346829671723286
78243791627283803341547107310850191954852900733772
4822783525742386454014691736602477652346609

Factors are public, as the contest has been solved. Here they are:

16347336458092538484431338838650908598417836700330
92312181110852389333100104508151212118167511579
and
1900871281664822113126851573935413975471896789968
515493666638539088027103802104498957191261465571

The effort took approximately 30 2.2GHz-Opteron-CPU years according to
the submitters, over five months of calendar time. (This is about half
the effort for RSA-200, the 663-bit number that the team factored in 2004.)

(Source : RSALabs website)

Knowing this it is really easy to code a keygen.
d = e ^ (-1) mod (p - 1) * (q - 1)
2464047959500535454951489660269116654533786992311
0741275307898768091977402206945638156191471135378
7981129533942791516321361871539233328003649556875
9211274464407731279798672759722961973941926913
/*********************************************************************/

#include <windows.h>
#include "miracl.h"

void process_serial(char *name, char *serial)
{
	miracl *mip=mirsys(200, 16);

	big m = mirvar(0);
	big d = mirvar(0);
	big n = mirvar(0);

	mip->IOBASE = 16;

	cinstr(n, "AE5BB4F266003259CF9A6F521C3C03410176CF16DF53953476EAE3B21EDE6C3C7B03BDCA20B31C0067FFA797E4E910597873EEF113A60FECCD95DEB5B2BF10066BE2224ACE29D532DC0B5A74D2D006F1");
	cinstr(d, "8A422E3A08A81F45185A5DEBBE77D81CB40C822AA0ECA663F3E84EA5EFD46FFF858C71F2D5FB3137D13B93532570F36D772356C23FEA51D39A1E7EEB0BB7E208A614526EDCB094B9CF6E260ADE687C01");
	bytes_to_big(strlen(name), name, m);
	powmod(m, d, n, m);
	cotstr(m, serial);

	mirkill(n);
	mirkill(d);
	mirkill(m);
	mirexit();
}

