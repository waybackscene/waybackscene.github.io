	A short solution for cyclops - CHAKRAVYUHA
	jB  - May 1, 2007


The name is padded with itself until it reaches 16 chars. Then the name array
is copied to an array of big endian dwords n0-n4. The name must be at least 5
chars long. The serial is composed of 4 hex digits s1, s2, s3 and s4, separated
by "-".

The main protection is a virtual machine, which contains 8 registers (r0-r7)and
an instruction pointer, plus a state flag for comparisons. The routine is called
via a SEH to trick the debugger.

Initialization:
r1 = s1
r2 = s2
r3 = s3
r6 = s4

Here is the disassembly of the virtual machine. Instructions are equivalent to
x86 instruction set, except ror and rol:
rol <-> rol r0, r5
ror <-> ror r0, r5
Numbers are written in big endian.

-------------- Disassembly --------------
05 01 12 34 12 34 mov r4, 0x12341234
06 01 00 00 00 07 mov r5, 7

loc_0c:
01 00 06          mov r0, r6
5A                rol
07 00 00          mov r6, r0
01 00 01          mov r0, r1
2A 00 04          xor r1, r4
2A 00 06          xor r1, r6
07 00 00          mov r6, r0
01 00 02          mov r0, r2 
5B                ror
03 00 00          mov r2, r0
01 00 03          mov r0, r3
2C 00 04          xor r3, r4
2C 00 02          xor r3, r2
03 00 00          mov r2, r0
01 00 02          mov r0, r2
5B                ror
03 00 00          mov r2, r0
01 00 01          mov r0, r1
2A 00 04          xor r1, r4
2A 00 02          xor r1, r2
03 00 00          mov r2, r0
01 00 06          mov r0, r6
5A                rol
07 00 00          mov r6, r0
01 00 03          mov r0, r3
2C 00 04          xor r3, r4 
2C 00 06          xor r3, r6
07 00 00          mov r6, r0
55 01 00 00 00 00 cmp r5, 0
58 63             jz loc_63
16 01 00 00 00 01 sub r5, 01
57 0C             jmp loc_0c

loc_63:
00                exit_vm
-------------- Disassembly --------------

At the end the registers must verify:

r1 = n0
r2 = n1
r3 = n2
r6 = n3

The VM operations can be rewritten in C:

	#define DELTA 0x12341234
	
	for(i = 7; i >= 0; i--)
	{
		r[4] = _lrotl(r[4], i);
		r[0] = r[1];
		r[1] = r[1]^DELTA^r[4];
		r[4] = r[0];
		
		r[2] = _lrotr(r[2], i);
		r[0] = r[3];
		r[3] = r[3]^DELTA^r[2];
		r[2] = r[0];
		
		r[2] = _lrotr(r[2], i);
		r[0] = r[1];
		r[1] = r[1]^DELTA^r[2];
		r[2] = r[0];
		
		r[4] = _lrotl(r[4], i);
		r[0] = r[3];
		r[3] = r[3]^DELTA^r[4];
		r[4] = r[0];		
	}

It is a short routine, easy to reverse. Coding a keygen is trivial.
I didn't explained the VM at all. It is a good start for everybody who are
interested in this kind of protection. Try to understand it, and feel free
to send me a mail if you have problems with it.

Best regards, and big thanks to cyclops for this keygenme.