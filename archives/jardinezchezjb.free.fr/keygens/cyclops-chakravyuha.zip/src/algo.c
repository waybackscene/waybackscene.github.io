////////////////////////////////////////////////////////////
// cyclops - CHAKRAVYUHA
// Keygen by jB
// May 1, 2007
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#include "resource.h"
#include <stdio.h>

void InitStuff(HWND hWnd)
{
}

#define DELTA 0x12341234

void GenererSerial(HWND hWnd)
{
	TCHAR szName[MAX_NAME];
	TCHAR aName[16];
	TCHAR szSerial[MAX_SERIAL];
	DWORD cbName, tmp, i;
	DWORD r[4];

	cbName = GetDlgItemText(hWnd, IDC_NAME, szName, MAX_NAME);
	if(cbName < MIN_NAME)
	{
		SetDlgItemText(hWnd, IDC_SERIAL, _T("Please enter a longer name..."));
		return;
	}
	for(i = 0; i < _countof(aName); i++)
		aName[i] = szName[i % cbName];
	for(i = 0; i < 4; i++)
	{
		r[i] = aName[i*4+3]
			| (aName[i*4+2] << 8)
			| (aName[i*4+1] << 16)
			| (aName[i*4] << 24);
	}
	for(i = 0; i < 8; i++)
	{
		tmp = r[3];
		r[3] = r[3]^DELTA^r[2];
		r[2] = tmp;
		r[3] = _lrotr(r[3], i);

		tmp = r[1];
		r[1] = r[1]^DELTA^r[0];
		r[0] = tmp;
		r[1] = _lrotl(r[1], i);

		tmp = r[1];
		r[1] = r[1]^DELTA^r[2];
		r[2] = tmp;
		r[1] = _lrotl(r[1], i);

		tmp = r[3];
		r[3] = r[3]^DELTA^r[0];
		r[0] = tmp;
		r[3] = _lrotr(r[3], i);
	}
	_stprintf_s(szSerial, _countof(szSerial), _T("%08X-%08X-%08X-%08X"), r[0], r[1], r[2], r[3]);
	SetDlgItemText(hWnd, IDC_SERIAL, szSerial);
}
