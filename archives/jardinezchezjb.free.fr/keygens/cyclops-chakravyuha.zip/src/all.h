#include <Windows.h>
#include <tchar.h>

#define PROGNAME "cyclops - CHAKRAVYUHA"
#define MAX_SERIAL 40
#define MIN_NAME 5
#define MAX_NAME 50
