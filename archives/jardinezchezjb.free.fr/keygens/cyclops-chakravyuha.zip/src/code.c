#include "all.h"
#include "resource.h"

void GenererSerial(HWND hwnd);
void InitStuff(HWND hwnd);

HINSTANCE hInst;

BOOL CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hWnd, 0); 
   			break;

		case WM_INITDIALOG:
			InitStuff(hWnd);
			SendDlgItemMessage(hWnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME, 0);
			SetWindowText(hWnd, _T(PROGNAME)_T(" - Keygen"));
			SetDlgItemText(hWnd, IDC_NAME, _T("jB"));
			SetFocus(GetDlgItem(hWnd, IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
			case IDC_NAME:
				if(HIWORD(wParam) == EN_CHANGE)
					GenererSerial(hWnd);
				break;
			case IDC_GENERATE:
				GenererSerial(hWnd);
				break;
			case IDC_EXIT:
				EndDialog(hWnd, 0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_KEYGEN), NULL, DlgProc, (LPARAM)NULL);
 	return 0;
}
