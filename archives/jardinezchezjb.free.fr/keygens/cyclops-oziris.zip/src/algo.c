////////////////////////////////////////////////////////////
// Cyclops - OZiRiS
// Keygen by jB
// Dec. 16, 2006
//
// Custom block cipher using RC4
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#include "rc4.h"

#define CIPHER_BLOCKSIZE 8

void to64frombits(unsigned char *out, const unsigned char *in, int inlen);
unsigned int cipher_context[8];

/* Get some values from the RC4 context */
void cipher_get_context(RC4_KEY *key)
{
	cipher_context[0] = key->state[0] << 24 | key->state[12] << 16
		| key->state[22] << 8 | key->state[33];
	cipher_context[1] = key->state[10] << 24 | key->state[41] << 16
		| key->state[33] << 8 | key->state[148];
	cipher_context[2] = key->state[20] << 24 | key->state[15] << 16
		| key->state[17] << 8 | key->state[190];
	cipher_context[3] = key->state[30] << 24 | key->state[61] << 16
		| key->state[55] << 8 | key->state[188];
	cipher_context[4] = key->state[40] << 24 | key->state[88] << 16
		| key->state[29] << 8 | key->state[230];
	cipher_context[5] = key->state[50] << 24 | key->state[10] << 16
		| key->state[63] << 8 | key->state[250];
	cipher_context[6] = key->state[60] << 24 | key->state[91] << 16
		| key->state[73] << 8 | key->state[202];
	cipher_context[7] = key->state[70] << 24 | key->state[10] << 16
		| key->state[124] << 8 | key->state[255];
}

/* Small procedures used by the encrption and decryption routines */
unsigned int A(unsigned int k, int i)
{
	return k ^ cipher_context[i];
}

unsigned char B(RC4_KEY *key, unsigned char c)
{
	int i = 0;
	while(i < 256)
	{
		if(key->state[i] == c)
			return i;
		i++;
	}
	return 0;
}

/* Encryption routine. Here for learning purposes. Used during serial
verification, and not during serial verification */
void encrypt(unsigned char *data_in, unsigned char *data_out, RC4_KEY *key)
{
	unsigned int k1, k2;
	int i;

	k1 = data_in[0] << 24 | data_in[1] << 16 | data_in[2] << 8 | data_in[3];
	k2 = data_in[4] << 24 | data_in[5] << 16 | data_in[6] << 8 | data_in[7];

	for(i = 8 - 1; i >= 0; i--)
	{
		unsigned int k;
		k = k2;
		k2 ^= A(k1, i);
		k1 = k;
	}

	for(i = 0; i < 4; i++)
	{
		data_out[(CIPHER_BLOCKSIZE / 2) - i - 1] = k2 & 0xFF;
		data_out[CIPHER_BLOCKSIZE - i - 1] = k1 & 0xFF;
		k2 >>= 8;
		k1 >>= 8;
	}

	for(i = 0; i < CIPHER_BLOCKSIZE; i++)
	{
		data_out[i] = B(key, data_out[i]);
	}
}

/* Decryption routine. Custom block cipher */
void decrypt(unsigned char *data_in, unsigned char *data_out, RC4_KEY *key)
{
	unsigned int k1, k2;
	int i;

	for(i = 0; i < CIPHER_BLOCKSIZE; i++)
		data_out[i] = key->state[data_in[i]];

	k2 = data_out[0] << 24 | data_out[1] << 16 | data_out[2] << 8 | data_out[3];
	k1 = data_out[4] << 24 | data_out[5] << 16 | data_out[6] << 8 | data_out[7];

	for(i = 0; i < 8; i++)
	{
		unsigned int k;
		k = k1;
		k1 ^= A(k2, i);
		k2 = k;
	}

	for(i = 0; i < 4; i++)
	{
		data_out[CIPHER_BLOCKSIZE - i - 1] = k2 & 0xFF;
		data_out[(CIPHER_BLOCKSIZE / 2) - i - 1] = k1 & 0xFF;
		k2 >>= 8;
		k1 >>= 8;
	}
}

/* Caesar cipher */
void caesar(unsigned char *lpData, int cbData)
{
	int i;
	for(i = 0; i < 16; i++)
		lpData[i] = lpData[i % cbData] + cbData;
}

/* Create a serial from a name */
void makeserial(char *name, char *serial)
{
	RC4_KEY key;
	unsigned char key_data[17];
	unsigned char plain[16];

	prepare_key(name, (int)strlen(name), &key);	
	strncpy_s(key_data, sizeof(key_data), name, 16);
	key_data[16] = 0;	
	caesar(key_data, (int)strlen(key_data));
	cipher_get_context(&key);

	decrypt(key_data, plain, &key);
	decrypt(key_data + CIPHER_BLOCKSIZE, plain + CIPHER_BLOCKSIZE, &key);	

	to64frombits(serial, plain, 16);	
}

DWORD WINAPI GenererSerial(HWND hwnd)
{
	TCHAR name[MAX_NAME];
	TCHAR serial[MAX_SERIAL];

	if(GetDlgItemText(hwnd, IDC_NAME, name, MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return 0;
	}
	makeserial(name, serial);
	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	return 0;
}
