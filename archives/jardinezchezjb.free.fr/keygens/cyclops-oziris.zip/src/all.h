#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "rsrc/resource.h"

#define PROGNAME "cyclops - OZiRiS Keygenme"
#define MIN_NAME 7
#define MAX_NAME 40
#define MAX_SERIAL 40

