#include <windows.h>
char * lookandsay(char *s);

void process_serial(char *name, char *serial)
{
	int i,j;
	short wlns;
	int len=strlen(name), len2;
	char *hexname=malloc(2*len+1);
	unsigned char *plop, *hexserial=malloc(len+1);

	for(i=0;i<len;i++)
	{
		wsprintf(hexname+2*i,"%02X",*(name+i));
	}
	plop=lookandsay(hexname);
	len2=strlen(plop);
	memset(hexserial,0,len+1);

	/* Ugly conversion from asm to C... */
	j=1;
	for(i=1;i<=len;i++)	
	{
		unsigned int r,c;
		memcpy(&wlns,plop+j-1,2);
		c=name[i-1]+wlns;
		c-=i;
		r=c%i;
		c/=i;
		c-=len2;
		wlns+=i;
		c+=r;
		c^=wlns;
		hexserial[i-1]=(unsigned char)c;
		if(j>=len) j=0;
		j++;
	}
	for(i=0;i<len;i++)
	{
		wsprintf(serial+2*i,"%02X",hexserial[i]);
	}
	
	free(plop);
	free(hexname);
	free(hexserial);
}

/*	Look and say sequence
	Computes the next term of the sequence */

char * lookandsay(char *s){
	int len=strlen(s);
	char *res=malloc(2*len+1);
	char c,nb;
	int i=0;

	res[0]=0;
	while(*s){
		c=*s;
		nb=0;
		while(c==*s)
		{
			nb++;
			s++;
		}
		res[i]=nb;
		res[i+1]=c;				
		i+=2;
	}
	res[i]=0;
	return res;
}