/*************************************************
   dihux - keygenme 1 - Keygen by jB

   Date: 1 jan. 2004
   Protection: RSA-200

   Public Key
     n=8ACFB4D27CBC8C2024A30C9417BBCA41AF3FC3BD9BDFF97F89
     e=10001

   Private Key
     p=970E1A438A10E069571BDCCBB
     q=EB3FFE9F5C761995147C7A28B
     d=32593252229255151794D86C1A09C7AFCC2CCE42D440F55A2D
*************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "miracl.h"
#include <windows.h>
#include <time.h>

int main()
{
	miracl *mip=mirsys(50,0);

	big n=mirvar(0);
	big d=mirvar(0);
	big M=mirvar(0);
	big mul=mirvar(0x1337);
	char nom[50];
	int len;
	mip->IOBASE=16;

	cinstr(n,"8ACFB4D27CBC8C2024A30C9417BBCA41AF3FC3BD9BDFF97F89");
	cinstr(d,"32593252229255151794D86C1A09C7AFCC2CCE42D440F55A2D");

	printf("dihux keygenme 1\nKeygen by jB\n\nName:\t");
	gets(nom);
	len=strlen(nom);
	if(len<5 || len>20)
		printf("Invalid name\n");
	else {
		bytes_to_big(strlen(nom),nom,M);

		multiply(M,mul,M);
		powmod(M,d,n,M);

		printf("Serial:\t");
		cotnum(M,stdout);
	}

	mirkill(n);
	mirkill(M);
	mirkill(d);

	getchar();
	return(0);
}
