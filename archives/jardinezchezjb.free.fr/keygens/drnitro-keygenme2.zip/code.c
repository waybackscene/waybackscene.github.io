////////////////////////////////////////////////////////////
// Keygenme iN Morocco n~2
// Keygen by jB
// Jul. 24th, 2005
//
// Simple arithmetic
////////////////////////////////////////////////////////////


#define WIN32_LEAN_AND_MEAN

#include <windows.h> 	
#include "resource.h"
#include "miracl.h"

#define MIN_NAME 1
#define MAX_NAME 100

DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"Keygenme iN Morocco n~2");
			SetDlgItemText(hwnd,IDC_NAME,"jB");			
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

DWORD WINAPI GenererSerial(HWND hwnd){
	miracl *mip=mirsys(200,0);
    char name[100];
	char hexname[210];
	char serial[250];
	char c;
	int i,len,sum=0;

	big cim,chk,e,invnom;
	memset(hexname,0,80);

	GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);
	len=strlen(name);
	if(len<MIN_NAME || len>MAX_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a valid name...");
		return 0;
	}

	for(i=0;i<len;i++){		// Conversion en hexa avec inversion des chars ('j'=0x6A ->"A6")
		c=name[i]&0xf;
		if(c<10)
			c+='0';
		else c+='7';
		hexname[2*i]=c;
		c=name[i]>>4;
		if(c<10)
			c+='0';
		else c+='7';		
		hexname[2*i+1]=c;
	}

	cim=mirvar(0);
	chk=mirvar(0);
	e=mirvar(0);
	invnom=mirvar(0);

	lgconv(0x020C38,chk);	// Checksum
	for(i=0;i<len;i++)		// Somme des chars du nom
		sum+=name[i];
	lgconv(sum,e);

	mip->IOBASE=16;
	
	cinstr(cim,"34271636B60296E402D4F627F63636F600");	// "Crack iN Morocco" hexa invers�
	cinstr(invnom,hexname);

	multiply(invnom,e,invnom);	// serial = nom invers� * somme des chars du nom * cim - checksum
	multiply(invnom,cim,invnom);
	subtract(invnom,chk,invnom);
	cotstr(invnom,serial);

	SetDlgItemText(hwnd, IDC_SERIAL,serial);

	mirkill(cim);
	mirkill(chk);
	mirkill(e);
	mirkill(invnom);
	mirexit();
    return 0;
}