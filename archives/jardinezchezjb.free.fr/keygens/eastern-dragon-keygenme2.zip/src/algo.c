#include <windows.h>

unsigned int crc32(const void *buf, int size);
void bwt_encode(byte *buf_in, byte *buf_out, int *primary_index);

void process_serial(char *name, char *serial)
{
	char buf[10];
	int s1;
	char s2[10];
	int len=strlen(name);
	int hash=crc32(name,len);
	memset(buf,0,10);
	wsprintf(buf,"%08X",hash);
	bwt_encode(buf, s2, &s1);

	wsprintf(serial,"%u-%s",s1,s2);
}

