/*
Burrows-Wheeler Transformation
Taken from Wikipedia PL
http://pl.wikipedia.org/wiki/Transformata_Burrowsa-Wheelera
Source slightly modified for the keygen
*/

#include <stdlib.h>

#define BLOCK_SIZE 8

typedef unsigned char byte;

byte *rotlexcmp_buf = NULL;
int rottexcmp_bufsize = 0;

int rotlexcmp(const void *l, const void *r)
{
	int li = *(const int*)l, ri = *(const int*)r, ac=rottexcmp_bufsize;
	while (rotlexcmp_buf[li] == rotlexcmp_buf[ri])
	{
		if (++li == rottexcmp_bufsize)
			li = 0;
		if (++ri == rottexcmp_bufsize)
			ri = 0;
		if (!--ac)
			return 0;
	}
	if (rotlexcmp_buf[li] > rotlexcmp_buf[ri])
		return 1;
	else
		return -1;
}

void bwt_encode(byte *buf_in, byte *buf_out, int *primary_index)
{
	int indices[BLOCK_SIZE];
	int i;

	for(i=0; i<BLOCK_SIZE; i++)
		indices[i] = i;
	rotlexcmp_buf = buf_in;
	rottexcmp_bufsize = BLOCK_SIZE;
	qsort (indices, BLOCK_SIZE, sizeof(int), rotlexcmp);

	for (i=0; i<BLOCK_SIZE; i++)
		buf_out[i] = buf_in[(indices[i]+BLOCK_SIZE-1)%BLOCK_SIZE];
	buf_out[BLOCK_SIZE]=0;
	for (i=0; i<BLOCK_SIZE; i++)
	{
		if (indices[i] == 0) {
			*primary_index = i;
			return;
		}
	}
}
