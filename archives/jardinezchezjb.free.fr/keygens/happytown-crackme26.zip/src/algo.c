/*
ECDSA-56
Parameters are, according to The Elliptic Curve Digital Signature Algorithm
(D. Johnson and A. Menezes, Univ. of Waterloo, 1999):

a = 0x2982
b = 0x3408
p = 0xAEBF94CEE3E707
xG = 0x7A3E808599A525
xQ = 0x9F70A02013BC9B
Q = d * G, d being the private key.
n = 0xAEBF94D5C6AA71 not prime.
n = 0x11 * 0x35 * 0xDD0F5 * 0x397FAE9

Discrete logarithm can be computed fastly using Pohlig-Hellman:
d = 0x9D3F1E3CDDA5E5
*/

#include "all.h"
#include "miracl.h"

DWORD WINAPI GenererSerial(HWND hwnd)
{
	miracl *mip;
	big a, b, p, n, x, d, k, r, s, h;
	epoint *G;
	TCHAR name[MAX_NAME];
	TCHAR serial[MAX_SERIAL];
	TCHAR temp[60];
	BYTE digest[20];
	sha sh;

	if(GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME)<MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
	}
	else
	{
		int i;
		mip = mirsys(50, 0);
		
		G = epoint_init();
		memset(serial,0,MAX_SERIAL);
		mip->IOBASE = 16;
		a = mirvar(0x2982);
		b = mirvar(0x3408);
		p = mirvar(0);
		n = mirvar(0);
		x = mirvar(0);
		d = mirvar(0);
		k = mirvar(0);
		r = mirvar(0);
		s = mirvar(0);
		h = mirvar(0);

		cinstr(x, "7A3E808599A525");
		cinstr(p, "AEBF94CEE3E707");
		cinstr(n, "AEBF94D5C6AA71");
		cinstr(d, "9D3F1E3CDDA5E5");
		ecurve_init(a, b, p, MR_AFFINE);

		epoint_set(x, x, 0, G);

		irand(GetTickCount());
		do 
		{
			bigrand(n, k);
		} while(egcd(k, n, s) != 1);
		
		ecurve_mult(k, G, G);
		epoint_get(G, r, r);

		xgcd(k, n, k, k, k);
        
		shs_init(&sh);
		i = 0;
		while (name[i] != 0)
		{
			shs_process(&sh, name[i]);
			i++;
		}
		shs_hash(&sh, digest);

        bytes_to_big(20, digest, h);
		mad(d, r, h, n, n, s);
		mad(k, s, s, n, n, s);

		cotstr(r, serial);
		strcat(serial, "-");
		cotstr(s, temp);
		strcat(serial, temp);
        
		SetDlgItemText(hwnd, IDC_SERIAL,serial);
		epoint_free(G);
		mirkill(a);
		mirkill(b);
		mirkill(p);
		mirkill(n);
		mirkill(x);
		mirkill(d);
		mirkill(k);
		mirkill(r);
		mirkill(s);
		mirkill(h);
		mirexit();
	}
	return 0;
}
