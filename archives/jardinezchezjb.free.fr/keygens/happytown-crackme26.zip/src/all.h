#define WIN32_LEAN_AND_MEAN

#include <windows.h> 	
#include "rsrc/resource.h"

#define PROGNAME "HappyTown - CrackMe_0026"
#define MIN_NAME 3
#define MAX_NAME 24
#define MAX_SERIAL 40
