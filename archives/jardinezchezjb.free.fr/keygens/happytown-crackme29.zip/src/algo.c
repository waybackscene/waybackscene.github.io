/*
Modular arithmetic, custom hash.

Name is hashed using a 128 bit custom hash.
The ten first bytes of the resulting digest are converted into a bignum h.
c = (serial^n mod n) mod p, with:
n = 53AA4A5D47684616BD856ED3DB0F3899CDE3A052CE2B3011
p = A5DA242D7DD4EACD19819D83
p is prime divides n. n = p * q, with q = 812411AFA0A70241909EFBDB prime.
We must have: c = h

c = (serial^n mod n) mod p
  = serial^n mod p, as p divides n.
So to generate a valid serial,
Hash the name, and convert the 10 first bytes of the digest into a bignum h
Compute d = 1/n mod p-1
Compute serial = h^d mod p
*/

#include "all.h"
#include "miracl.h"

typedef struct {
	DWORD state[4];
	DWORD count[2];
	unsigned char buffer[64];
} HASH_CTX;

#define HASH_DIGEST_SIZE 16

void HashInit(HASH_CTX *ctx);
void HashUpdate(HASH_CTX *ctx, unsigned char *str, unsigned int len);
void HashProcess(unsigned char *str, HASH_CTX *ctx);

DWORD WINAPI GenererSerial(HWND hwnd)
{
	miracl *mip;
	big h, d, p;
	TCHAR name[MAX_NAME];
	TCHAR serial[MAX_SERIAL];
	BYTE digest[HASH_DIGEST_SIZE];
	HASH_CTX ctx;

	if(GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
	}
	else
	{
		mip = mirsys(50, 0);
		h = mirvar(0);
		d = mirvar(0);
		p = mirvar(0);
        
		HashInit(&ctx);
		HashUpdate(&ctx, name, (unsigned int)strlen(name));
		HashProcess(digest, &ctx);

		bytes_to_big(10, digest, h);
		mip->IOBASE = 16;
		cinstr(d, "167E725333DE5002B3D50A1D");
		cinstr(p, "A5DA242D7DD4EACD19819D83");
		powmod(h, d, p, h);
		cotstr(h, serial);

		SetDlgItemText(hwnd, IDC_SERIAL,serial);
		mirkill(p);
		mirkill(d);
		mirkill(h);
		mirexit();
	}
	return 0;
}
