////////////////////////////////////////////////////////////
// HappyTown - CrackMe_0029
// Keygen by jB
// Nov. 3, 2006
//
// Modular arithmetic, custom hash
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"

DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,PROGNAME " - Keygen");
			SetDlgItemText(hwnd,IDC_NAME,"jB");
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
			case IDC_NAME:
   				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
   			case IDC_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_KEYGEN),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}
