////////////////////////////////////////////////////////////
// HappyTown - CrackMe_0030
// Keygen by jB
// Nov. 3, 2006
//
// Digital signature scheme with message recovery.
// Quadratic residuosity problem.
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

/*
The name concatenated with a constant string is hashed using SHA.
The 10 first bytes of the resulting digest are converted into a bignum h.
The serial is composed of 2 parts s1 ans s2, separated by a "-".

h, s1 and s2 must verify:
h = s1^2 - d * s2^2 mod n, with:
n = E97E36F9426708D10516A001FC358367B8ECBB7210388B971C886AA4A44845F1
d = D9BC54B68E7F0CC76BD6BEB333AA09CCE9162FA9DF22989EC049D5BCD34981FE

n is a composite modulus: n = p * q
p = EB8D197C10BA775BA2A785085C44A0C3
q = FDC35FF9D4A7BBCAD7577E99D8C8533B

To generate a valid serial, we can compute:
s1^2 = h + d * s2^2 mod n
So: s1 = sqrt(h + d * s2^2) mod n if h + d * s2^2 is a quadratic residue.
About n / 4 (exactly (p-1)*(q-1)/4) elements of Zn* are quadratic residues mod n.
So s2 can be chosen as a random number, and after a few iterations h + d * s2^2
will be a quaratic residue, and we can compute s1 using the chinese remainder theorem.

To generate a valid serial:
1. Concatenate the name with the string "&PEdiy", and hash the result using SHA
2. Convert the 10 first bytes into a bignum h
3. Generate a random number s2
4. Compute c = h * d * s2^2 mod n
5. If c is not a quadratic residue goto step 4.
6. Compute s1, a square root of c
7. Return (s1, s2)
*/

#include "all.h"
#include "miracl.h"
#include <stdlib.h>

DWORD WINAPI GenererSerial(HWND hwnd)
{
	TCHAR name[MAX_NAME];

	if(GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
	}
	else
	{
		const TCHAR msg_append[] = "&PEdiy";
		miracl *mip;
		big h, d, p, q, n, s1, s2, r1, r2, k;
		sha sh;
		BYTE digest[20];
		int i = 0;
		big_chinese bc;
		big *m = (big *)malloc(2 * sizeof(big));
		big *r = (big *)malloc(2 * sizeof(big));
		TCHAR *serial, *serial1, *serial2;

		mip = mirsys(50, 0);
		h = mirvar(0);
		d = mirvar(0);
		p = mirvar(0);
		q = mirvar(0);
		n = mirvar(0);
		k = mirvar(0);
		s1 = mirvar(0);
		s2 = mirvar(0);
		r1 = mirvar(0);
		r2 = mirvar(0);
        
		/* Hashes the name */
		shs_init(&sh);
		while(name[i] != 0) shs_process(&sh, name[i++]);
		i = 0;
		while(msg_append[i] != 0) shs_process(&sh, msg_append[i++]);
		shs_hash(&sh, digest);
		bytes_to_big(10, digest, h);

		mip->IOBASE = 16;
		cinstr(p, "EB8D197C10BA775BA2A785085C44A0C3");
		cinstr(q, "FDC35FF9D4A7BBCAD7577E99D8C8533B");
		cinstr(d, "D9BC54B68E7F0CC76BD6BEB333AA09CCE9162FA9DF22989EC049D5BCD34981FE");
		multiply(p, q, n);

		/* Find s2 such as h + d * s2 is a quadratic residue over Zn* */
		irand(GetTickCount());
		do 
		{
			bigrand(n, s2);
			copy(s2, k);
			power(k, 2, k, k);
			mad(k, d, h, n, n, s1);

		} while((sqroot(s1, p, r1) == FALSE) || (sqroot(s1, q, r2) == FALSE));

		/* Compute a square root of s1:
		Compute sqrt(s1) mod p, sqrt(s1) mod q, and use the CRT to compute sqrt(s1) mod n.
		*/
		m[0] = p;
		m[1] = q;
		r[0] = r1;
		r[1] = r2;
		crt_init(&bc, 2, m);
		crt(&bc, r, s1);
		crt_end(&bc);

		free(m);
		free(r);

		/* Formats the serial */
		serial1 = malloc(numdig(s1) * 8 + 1);
		serial2 = malloc(numdig(s2) * 8 + 1);
		cotstr(s1, serial1);
		cotstr(s2, serial2);
		serial = malloc(strlen(serial1) + strlen(serial2) + 2);
		strcpy(serial, serial1);
		strcat(serial, "-");
		strcat(serial, serial2);
		free(serial1);
		free(serial2);
		
		SetDlgItemText(hwnd, IDC_SERIAL, serial);
		free(serial);

		mirkill(r2);
		mirkill(r1);
		mirkill(s2);
		mirkill(s1);
		mirkill(k);
		mirkill(n);
		mirkill(q);
		mirkill(p);
		mirkill(d);
		mirkill(h);
		mirexit();
	}
	return 0;
}
