#define WIN32_LEAN_AND_MEAN

#include <windows.h> 	
#include "rsrc/resource.h"

#define PROGNAME "HappyTown - CrackMe_0030"
#define MIN_NAME 2
#define MAX_NAME 500
