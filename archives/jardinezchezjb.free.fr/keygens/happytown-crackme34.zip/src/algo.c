////////////////////////////////////////////////////////////
// HappyTown - CrackMe_0034
// Keygen by jB
// Dec. 16, 2006
//
// MD4 + SHA256 + HAVAL3-256 + Tiger + RIPEMD160 + MD5 + RSA
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#include <openssl/md4.h>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <openssl/md5.h>
#include <openssl/rsa.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include "haval.h"
#include "tiger.h"

DWORD WINAPI GenererSerial(HWND hwnd)
{
	TCHAR name[MAX_NAME];
	TCHAR company[MAX_COMPANY];

	const char rsa_e[]="10001";
	const char rsa_n[]="886A71F603197C430E9C473BB6991BE95B45AB519F57ADB9";	
	const char rsa_d[]="7C3E3E86EAB1C67C288D6B4E01CD7C11196B29622F848985";
	const TCHAR c1[] = "MzQ1MzQ1MjM0JkBTREFGYXNkZjIzMTMyMTMX124=";
	const TCHAR c2[] = "c2RmcXdlcjQxNTE1MTUxamwzMjE1QCQhMzQyZmE=";
	BYTE md4digest[MD4_DIGEST_LENGTH + 1];
	BYTE sha256digest[SHA256_DIGEST_LENGTH + 1];
	BYTE haval256digest[32];
	BYTE ripemd160digest[RIPEMD160_DIGEST_LENGTH];
	BYTE md5digest[MD5_DIGEST_LENGTH];
	unsigned int nbLoops;

	TCHAR *serial;
	TCHAR *rsaserial;
	int i, j;
	SHA256_CTX sha256_ctx;
	haval_state haval3_ctx;
	TIGER_CTX tiger_ctx;
	RSA *rsa;
	int cbRsaCipher;
	BIO *bio, *mbio, *b64bio;


	if(GetDlgItemText(hwnd, IDC_NAME, name, MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return 0;
	}
	if(GetDlgItemText(hwnd, IDC_COMPANY, company, MAX_COMPANY) < MIN_COMPANY)
	{
		SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a longer group name...");
		return 0;
	}

	/* Hash the name using MD4 */
	memset(md4digest, 0, sizeof(md4digest));
	MD4(name, strlen(name), md4digest);

	/* SHA-256 hash (MD4 digest + c1 or c2, depends on the digest length */
	memset(sha256digest, 0, sizeof(sha256digest));
	SHA256_Init(&sha256_ctx);
	SHA256_Update(&sha256_ctx, md4digest, strlen(md4digest));
	if(md4digest[MD4_DIGEST_LENGTH - 1] == 0)
		SHA256_Update(&sha256_ctx, c2, strlen(c2));
	else
		SHA256_Update(&sha256_ctx, c1, strlen(c1));
	SHA256_Final(sha256digest, &sha256_ctx);

	/* Hash the previous digest + the company name + c2 using a crappy version of
	Haval3-256 */
	haval_start(&haval3_ctx);
	haval_hash(&haval3_ctx, sha256digest, (int)strlen(sha256digest));
	haval_hash(&haval3_ctx, company, strlen(company));
	haval_hash(&haval3_ctx, (unsigned char *)c2, (int)strlen(c2));
    haval_end(&haval3_ctx, haval256digest);

	/* Hash the previous digest with Tiger. Number of loops depend on the
	first byte of the previous hash */
	nbLoops = haval256digest[0] | 1;
    for(i = 0; i < nbLoops; i++)
	{
		TIGER_Init(&tiger_ctx);
		TIGER_Update(&tiger_ctx, haval256digest, 24);
		TIGER_End(&tiger_ctx, haval256digest);
	}

	/* Hash the previous digest using RIPEMD160 and modifies one byte */
	RIPEMD160(haval256digest, 24, ripemd160digest);
	ripemd160digest[7] = 0x7A;

	/* Hash the previous digest using MD5 */
	MD5(ripemd160digest, 16, md5digest);

	/* Encrpts the digest obtained previously using RSA */
	rsa = RSA_new();
	BN_hex2bn(&rsa->e,rsa_e);
	BN_hex2bn(&rsa->n,rsa_n);
	BN_hex2bn(&rsa->d,rsa_d);
	cbRsaCipher = RSA_private_decrypt(16, md5digest, haval256digest, rsa,
		RSA_NO_PADDING);
	RSA_free(rsa);

	/* Print the serial, and encode it with the company name into base64 */
	rsaserial = OPENSSL_malloc(2 * cbRsaCipher + 1);
	for(i = 0; i < cbRsaCipher; i++)
		sprintf(rsaserial + 2 * i, "%02X", haval256digest[i]);
    
	mbio = BIO_new(BIO_s_mem());
	b64bio = BIO_new(BIO_f_base64());
	bio = BIO_push(b64bio, mbio);
	BIO_write(bio, company, (int)strlen(company));
	BIO_write(bio, rsaserial, 2 * cbRsaCipher + 1);
	BIO_flush(bio);
	serial = OPENSSL_malloc(BIO_pending(bio) + 1);
	memset(serial, 0, 2 * cbRsaCipher + 1);
	cbRsaCipher = BIO_ctrl(mbio, BIO_CTRL_INFO, 0, (char *)&serial);
	OPENSSL_free(rsaserial);

	/* Remove unwanted chars put by OpenSSL during the conversion */
	for(i = 0, j = 0; i < cbRsaCipher; i++)
	{
		if(serial[i] != 0xA)
		{
			serial[j] = serial[i];
			j++;
		}
	}
	serial[j] = 0;

	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	OPENSSL_free(serial);
	return 0;
}
