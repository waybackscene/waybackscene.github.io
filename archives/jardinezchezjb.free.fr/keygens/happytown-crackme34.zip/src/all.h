#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include "rsrc/resource.h"

#define PROGNAME "HappyTown - CrackMe_0034"
#define MIN_NAME 2
#define MAX_NAME 500
#define MIN_COMPANY 1
#define MAX_COMPANY 500
