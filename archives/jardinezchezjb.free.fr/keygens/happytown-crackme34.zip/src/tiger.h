/**************************************************************
 *                                                            *
 *   Fichier : tiger.h                                        *
 *   Header de tiger.c                                        *
 *                                                            *
 **************************************************************/


#ifndef ___TIGER_H___
#define ___TIGER_H___

#ifndef ulong64
typedef unsigned long long ulong64;
#endif

typedef struct _tiger_hash_state
{
    ulong64 state[3], length;
    unsigned long curlen;
    unsigned char buf[64];
} TIGER_CTX;

void TIGER_Init(TIGER_CTX *md);
void TIGER_Update(TIGER_CTX * md, const unsigned char *buf, unsigned long len);
void TIGER_End(TIGER_CTX * md, unsigned char *hash);

static void _tiger_compress(TIGER_CTX *md);

static void _tiger_round(ulong64 *a, ulong64 *b, ulong64 *c, ulong64 x, ulong64 mul);
static void _tiger_pass(ulong64 *a, ulong64 *b, ulong64 *c, ulong64 *x, ulong64 mul);
static void _tiger_key_schedule(ulong64 *x);

#endif // ___TIGER_H___
