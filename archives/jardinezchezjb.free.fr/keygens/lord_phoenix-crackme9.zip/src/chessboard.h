#ifndef __CHESSBOARD_H__
#define __CHESSBOARD_H__

#include "all.h"
#include "wansdorff.h"

void DrawChessboard(HWND hWnd, BOOL bDrawMoves);

#endif