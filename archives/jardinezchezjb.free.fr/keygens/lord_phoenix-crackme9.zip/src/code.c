#include "all.h"
#include "chessboard.h"

DWORD WINAPI GenererSerial(HWND hWnd);
HINSTANCE hInst;

INT_PTR CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static BOOL bDrawGraph = FALSE;

	switch (uMsg)
	{
	case WM_CLOSE:
		EndDialog(hWnd, 0);
		break;

	case WM_INITDIALOG:
		SetWindowText(hWnd, PROGNAME " - Keygen");
		SetDlgItemText(hWnd, IDC_NAME, "jB");
		SendDlgItemMessage(hWnd, IDC_NAME, EM_LIMITTEXT, MAX_NAME, 0);
		SetFocus(GetDlgItem(hWnd, IDC_NAME));
		SetTimer(hWnd, 1, 50, NULL); 
		return FALSE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDC_NAME:
			if(HIWORD(wParam) == EN_CHANGE)
				bDrawGraph = GenererSerial(hWnd);
			break;
		case IDC_GENERATE:
			bDrawGraph = GenererSerial(hWnd);
			break;

		case IDC_EXIT:
			EndDialog(hWnd, 0);
			break;
		}
	case WM_TIMER:
		DrawChessboard(hWnd, bDrawGraph);
		return FALSE;
	default:
		return FALSE;
	}
	return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_KEYGEN), NULL, (DLGPROC)DlgProc, (LPARAM)NULL);
 	return 0;
}
