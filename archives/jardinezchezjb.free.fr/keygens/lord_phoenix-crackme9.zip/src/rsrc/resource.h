//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rsrc.rc
//
#define IDD_KEYGEN                      101
#define IDI_SNORKLE                     101
#define IDC_NAME                        1000
#define IDC_GRAPH                       1001
#define IDC_SERIAL                      1003
#define IDC_EXIT                        1005
#define IDC_GENERATE                    1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
