#include <stdio.h>
#include <assert.h>

#define MESSAGE_WORDS 1024

typedef struct {
	unsigned long v[384];
	unsigned char i;
	unsigned char j;
	unsigned char t3;
} st_key;

typedef struct {
	unsigned char coef[8][4];
	unsigned long x[4];
} st_gp8;

st_key kt;
st_gp8 int_state;
unsigned long buf[MESSAGE_WORDS];

void init_key (unsigned char *in, unsigned in_size);
static void gp8 (unsigned long *out);
void encrypt (unsigned long *buf, int buflen, st_key *skey);
void decrypt (unsigned long *buf, int buflen, st_key *skey);
