#include "all.h"
#include "wansdorff.h"

// The eight allowed moves
const int moves_x[] = {-2, -2, -1,  1,  2,  2,  1, -1};
const int moves_y[] = {-1,  1,  2,  2,  1, -1, -2, -2};

int position[BOARD_SIZE * BOARD_SIZE] = {0};

int getPlace(int pos)
{
	int i = 0;
	while(position[i] != pos)
	{
		if(i >= BOARD_SIZE * BOARD_SIZE) return 0;
		i++;
	}
	return i;
}

int num_possibilities(int x, int y)
{
	int i, j = 0;

	for(i = 0; i < 8; i++)
	{
		int new_x = x + moves_x[i];
		int new_y = y + moves_y[i];

		if((new_x >= 0) && (new_x < BOARD_SIZE))
			if((new_y >= 0) && (new_y < BOARD_SIZE))
				if(position[BOARD_SIZE * new_x + new_y] == 0)
					j++;
	}
	return j;
}

int next_move(x, y)
{
	int i;
	int min_moves = 9;
	int next_pos[8];
	int nbpos = 0;

	for(i = 0; i < 8; i++)
	{
		int new_x = x + moves_x[i];
		int new_y = y + moves_y[i];

		if((new_x >= 0) && (new_x < BOARD_SIZE) && (new_y >= 0) && (new_y < BOARD_SIZE))
		{
			if(position[BOARD_SIZE * new_x + new_y] == 0)
			{
				int n = num_possibilities(new_x, new_y);
				if(n == min_moves)
				{
					next_pos[nbpos] = i;
					nbpos++;
				}
				else if(n < min_moves)
				{
					next_pos[0] = i;
					nbpos = 1;
					min_moves = n;
				}
			}
		}
	}		
	return next_pos[rand() % nbpos]; // I assumed it always finds a solution
}

void wansdorff(int *moves)
{
	int pos_x = START_X;
	int pos_y = START_Y;
	int i;

	for(i = 0; i < BOARD_SIZE * BOARD_SIZE; i++)
		position[i] = 0;
	position[BOARD_SIZE * START_X + START_Y] = 1;

	for(i = 1; i < BOARD_SIZE * BOARD_SIZE; i++)
	{
		int n = next_move(pos_x, pos_y);
		pos_x += moves_x[n];
		pos_y += moves_y[n];
		moves[i - 1] = n + 1;
		position[BOARD_SIZE * pos_x + pos_y] = i + 1;
	}
}
