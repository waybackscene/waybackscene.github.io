#include <Windows.h>

#define PROGNAME "MR.HAANDI - SolveIt #1"
#define MAX_SERIAL 40
#define MIN_NAME 3
#define MAX_NAME 50
