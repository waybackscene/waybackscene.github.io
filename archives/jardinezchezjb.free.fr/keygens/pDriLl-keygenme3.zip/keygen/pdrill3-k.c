/* pDriLl keygenme 3 - Keygen par jB
ElGamal Signature scheme

On choisit k tel que: 1<=k<p-1 avec pgcd(k,p-1)=1
Puis on calcule r=alpha^k mod p. --> r est le premier serial
On calcule h(M)=M^2 mod n
Et on cacule s=k^(-1)*(h(m)-x*r) mod (p-1) qui est le 2e serial

voir Handbook of Applied Cryptography pour plus d'infos
*/

#include <stdio.h>
#include <stdlib.h>
#include <miracl.h>
#include <windows.h>
#include <time.h>

int main()
{
	miracl *mip=mirsys(50,0);

	big x=mirvar(0);
	big M=mirvar(0);
	big p=mirvar(0);
	big p1=mirvar(0);	// p-1
	big n=mirvar(0);
	big alpha=mirvar(0);
	big k=mirvar(0);
	big k1=mirvar(0);	// k^(-1) mod (p-1)
	big r=mirvar(0);
	big pgcd=mirvar(0);

	char nom[30];
	mip->IOBASE=16;

	irand(time(NULL));	// initialisation du RNG

	cinstr(alpha,"2E0C2DB4FEC8C6299A0C");
	cinstr(x,"3F6536A02CD18F3B67D3");
	cinstr(p,"B54F430648C6B2A10FFB");
	cinstr(p1,"B54F430648C6B2A10FFA");
	cinstr(n,"AC2DB4FEC8C62992DB4F");

	while(egcd(p1,k,pgcd)!=1)
		bigrand(p1,k);	// On g�n�re k<p-1 avec k et p-1 premiers entre eux.
				// On aura toujours k!=0 �tant donn� les conditions sur PGCD(k,p-1)
	copy(k,k1);
	xgcd(k1,p1,k1,k1,k1);	// Calcul de k^(-1) mod (p-1)

	powmod(alpha,k,p,r);	// r=alpha^k mod p
	multiply(r,x,x);
	divide(x,p1,p1);
	if(exsign(x)==-1)
		add(x,p1,x);

	printf("FHCF - pDriLl's Crypto Keygenme 3\n");
	printf("Keygen par jB\n\n");
	printf("Name:\t\t");
	gets(nom);

	while(strlen(nom)<30)
		strcat(nom,"*");
	bytes_to_big(30,nom,M);

	power(M,2,n,M);		// M=M^2 mod n
	subtract(M,x,x);
	multiply(k1,x,x);
	divide(x,p1,p1);
	if(exsign(x)==-1)
		add(x,p1,x);	// x=k^(-1)*(M-r*x) mod (p-1)

	mip->IOBASE=60;
	printf("Serial 1:\t");
	cotnum(r,stdout);
	printf("Serial 2:\t");
	cotnum(x,stdout);

	mirkill(x);
	mirkill(M);
	mirkill(p);
	mirkill(p1);
	mirkill(n);
	mirkill(alpha);
	mirkill(k);
	mirkill(k1);
	mirkill(r);
	mirkill(pgcd);

	getchar();
	return(0);
}
