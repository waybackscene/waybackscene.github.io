#include <stdio.h>
#include <miracl.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

#define H0 0x67452301L
#define H1 0xefcdab89L
#define H2 0x98badcfeL
#define H3 0x10325476L
#define H4 0xc3d2e1f0L

#define K0 0x5a827999L
#define K1 0x6ed9eba1L
#define K2 0x8f1bbcdcL
#define K3 0xca62c1d6L

#define PAD  0x80
#define ZERO 0

#define S(n,x) (((x)<<n) | ((x)>>(32-n)))

#define F0(x,y,z) (z^(x&(y^z)))
#define F1(x,y,z) (x^y^z)
#define F2(x,y,z) ((x&y) | (z&(x|y))) 
#define F3(x,y,z) (x^y^z)

static void shs_transform(sha *sh)
{ /* basic transformation step */
    mr_unsign32 a,b,c,d,e,temp;
    int t;
    for (t=16;t<80;t++) sh->w[t]=sh->w[t-3]^sh->w[t-8]^sh->w[t-14]^sh->w[t-16];
    a=sh->h[0]; b=sh->h[1]; c=sh->h[2]; d=sh->h[3]; e=sh->h[4];
    for (t=0;t<20;t++)
    { /* 20 times - mush it up */
        temp=K0+F0(b,c,d)+S(5,a)+e+sh->w[t];
        e=d; d=c;
        c=S(30,b);
        b=a; a=temp;
    }
    for (t=20;t<40;t++)
    { /* 20 more times - mush it up */
        temp=K1+F1(b,c,d)+S(5,a)+e+sh->w[t];
        e=d; d=c;
        c=S(30,b);
        b=a; a=temp;
    }
    for (t=40;t<60;t++)
    { /* 20 more times - mush it up */
        temp=K2+F2(b,c,d)+S(5,a)+e+sh->w[t];
        e=d; d=c;
        c=S(30,b);
        b=a; a=temp;
    }
    for (t=60;t<80;t++)
    { /* 20 more times - mush it up */
        temp=K3+F3(b,c,d)+S(5,a)+e+sh->w[t];
        e=d; d=c;
        c=S(30,b);
        b=a; a=temp;
    }
    sh->h[0]+=a; sh->h[1]+=b; sh->h[2]+=c;
    sh->h[3]+=d; sh->h[4]+=e;
} 

void shs_init(sha *sh)
{ /* re-initialise */
    int i;
    for (i=0;i<80;i++) sh->w[i]=0L;
    sh->length[0]=sh->length[1]=0L;
    sh->h[0]=H0;
    sh->h[1]=H1;
    sh->h[2]=H2;
    sh->h[3]=H3;
    sh->h[4]=H4;
}

void shs_process(sha *sh,int byte)
{ /* process the next message byte */
    int cnt;
    
    cnt=(int)((sh->length[0]/32)%16);

    sh->w[cnt]>>=8;                            // modification
    sh->w[cnt]|=(mr_unsign32)((byte&0xFF)<<24);// modification

    sh->length[0]+=8;
    if (sh->length[0]==0L) { sh->length[1]++; sh->length[0]=0L; }
    if ((sh->length[0]%512)==0) shs_transform(sh);
}

void shs_hash(sha *sh,char hash[20])
{ /* pad message and finish - supply digest */
    int i;
    mr_unsign32 len0,len1;
    len0=sh->length[0];
    len1=sh->length[1];
    shs_process(sh,PAD);
    while ((sh->length[0]%512)!=448) shs_process(sh,ZERO);
    sh->w[14]=len1;
    sh->w[15]=len0;    
    shs_transform(sh);
    for (i=0;i<20;i++)
    { /* convert to bytes */
        hash[i]=((sh->h[i/4]>>(8*(i%4))) & 0xffL);//modification
    }
    shs_init(sh);
}

int main()
{
	miracl *mip=mirsys(50,0);

	big alpha=mirvar(0);
	big p=mirvar(0);
	big q=mirvar(0);
	big y=mirvar(0);
	big a=mirvar(0);
	big s=mirvar(0);
	big h=mirvar(0);
	big r=mirvar(0);
	big k=mirvar(0);
	big k1=mirvar(0);

   	char nom[30];
	char hash[20];
	char s1[13];
	char s2[13];
	char serial[]="000000-000000-000000-000000";

	int i;
	int len;
	sha sh;

	mip->IOBASE=16;
	irand(time(NULL));	// initialisation du RNG

	cinstr(alpha,"8DFC33DF82EDEFF56ABD1AE161BE17FBC1F403D5DF133106");
	cinstr(p,"AE2CCC8E5956DE7898143649944108EEFCA2C7EF909012BB");
	cinstr(q,"A7DD75045151");
	cinstr(y,"AA0D6424AD93D695435A3A09FAAFD5358620D37223EEAF39");
	cinstr(a,"40A6C8A2464A891E99DDBFCFC967BAFD4BAFA67B3ECEDC43");
	copy(alpha,r);

	bigrand(p,k);
	powmod(alpha,k,p,r);
	divide(r,q,q);
	copy(k,k1);
	xgcd(k1,q,k1,k1,k1); // Calcul de k^(-1) mod q

   	printf("FHCF - pDriLl's Crypto Keygenme 4\n");
	printf("Keygen par jB\n\n");
	printf("Name:\t\t");
	gets(nom);

	shs_init(&sh);
	for (i=0;nom[i]!=0;i++) shs_process(&sh,nom[i]);
	shs_hash(&sh,hash);    
	bytes_to_big(20,hash,h);
	mad(a,r,h,q,q,s);
	multiply(k1,s,s);
	divide(s,q,q);

	cotstr(r,s1);
	len=strlen(s1);
	strncpy(serial+12-len,s1,len-6);
	strncpy(serial+7,s1+len-6,6);
   	cotstr(s,s1);
	len=strlen(s1);
	strncpy(serial+26-len,s1,len-6);
	strncpy(serial+21,s1+len-6,6);

	printf("Serial:\t\t%s",serial);
	getchar();

	mirkill(alpha);
	mirkill(p);
	mirkill(q);
	mirkill(y);
	mirkill(a);
	mirkill(s);
	mirkill(h);
	mirkill(r);
	mirkill(k);
	mirkill(k1);

	return 0;
}
