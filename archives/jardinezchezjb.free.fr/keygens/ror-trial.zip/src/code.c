/*
ROR Official Recruit KeyGen Me No. 1
Keygen by jB
Feb. 7th 2005

Protection: ECC, SHA-1, RSA
*/

#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <windows.h> 	
#include <windowsx.h>
#include "resource.h"
#include "miracl.h"

void GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
	PLOGFONT lplf;
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			lplf=malloc(sizeof(LOGFONT));
			memset(lplf,0,sizeof(LOGFONT));
			lplf->lfHeight=15;
			lplf->lfWidth=6;
			lplf->lfWeight=FW_BOLD;
			SendDlgItemMessage(hwnd,IDC_SERIAL,WM_SETFONT,(unsigned int)CreateFontIndirect(lplf),1);
			free(lplf);

			SetWindowText(hwnd,"ROR Official Recruit KeyGen Me No. 1 - Keygen");
			SetDlgItemText(hwnd,IDC_NAME,"jB");
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_NAME:
   				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
			case IDC_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDC_ABOUT:
				MessageBox(hwnd, "ROR Official Recruit KeyGen Me No. 1\nKeygen by jB\n\nProtection: ECC-32, RSA-64, Mod. SHA-1","About...",MB_ICONINFORMATION | MB_OK | MB_APPLMODAL);
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;  
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}


int DecodeProdKey(char *des,int dlen, unsigned char *src, int slen)
{
  static char *digits = "BCDFGHJKMPQRTVWXY2346789";
  int i,n;
  unsigned int hi,low,value;

  if(slen!=15)
    return(-1);

  if(dlen<25)
    return(-2);

  memset(des,0,dlen);

  for(i=dlen-1;i>=0;i--)
  {
	  if((i+1)%6==0)
		  des[i]='-';
	  else{

		  n=slen-1;
		  hi=0;
      do
      {
        low=src[n];
        value=hi<<8;
        value|=low;
        src[n]=value%24;
        src[n]=value/24;
        hi=value%24;
      }while((--n)>=0);
  


      des[i]=digits[value%24];
	  }
	  des[dlen]='\0';
  }
  return(0);
}

void mod1_shs_init(sha *sh){
    int i;
    DWORD sn;
    for (i=0;i<80;i++) sh->w[i]=0L;
    sh->length[0]=sh->length[1]=0L;
    sh->h[0]=GetVersion();
    GetVolumeInformation("C:\\",NULL,0,&sn,NULL,NULL,NULL,0);
    sh->h[1]=sn;
    sh->h[2]=0x19790222;
    sh->h[3]=0xCCEFB1B1;
    sh->h[4]=0x524F52;
}


#define MIN_NAME 1
#define MAX_NAME 100

void GenererSerial(HWND hwnd){
	unsigned char bytes[16], coords[8];
	char serial[30];
	int i;
	unsigned char tmp;
	
	int len;
	sha sh1;
	unsigned char s[20],s2[20];
	char name[MAX_NAME];
	unsigned char ror[]="TEAM ROR 2004";
	unsigned int c;
	
	big p,k,k1,xA,yA,xR,yR,r,order,a,b,sha1,n,d,s3;
	epoint * A;
	epoint * R;

    miracl *mip;
    mip =mirsys(100,0);
    
	p=mirvar(0);
    k=mirvar(0);
    k1=mirvar(0);
    xA=mirvar(0);
    yA=mirvar(0);
	xR=mirvar(0);
	yR=mirvar(0);

	r=mirvar(0);
	order=mirvar(0);

	n=mirvar(0);
	d=mirvar(0);
	sha1=mirvar(0);
	s3=mirvar(0);
	
	memset(&name,0,MAX_NAME);
	GetDlgItemText(hwnd,IDC_NAME,name,100);

	if(strlen(name)<MIN_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL, "Please enter a longer name");
		mirexit();
		return;
	}

    mip->IOBASE=16;

	/* Initialisation de la courbe */
    a=mirvar(1);
    b=mirvar(0xD);
    cinstr(p,"FFAE8E6F");
    

	/* Deux points sur la courbe */

    cinstr(xA,"0BCBBEC6");
    cinstr(yA,"48074670");

    A = epoint_init();
	R = epoint_init();

	/* Logarithme discret r�solu sur GF(p) */

    cinstr(k,"FCC4D43B");
    cinstr(order,"FFADA3AD");

    
    /* SHA(name+"TEAM ROR 2004") */
   	mod1_shs_init(&sh1);
   	len=strlen(name);
	for(i=0;i<len;i++)
		shs_process(&sh1,name[i]);
	len=strlen(ror);
	for(i=0;i<len;i++)
		shs_process(&sh1,ror[i]);
	shs_hash(&sh1,s);

	/* 8 premiers bytes du hash */
	bytes_to_big(8,s,sha1);
	
	/* RSA parameters */
    cinstr(n,"FF5C4C4FBFA9EE03");
	cinstr(d,"EE10742A803F7811");
	
	powmod(sha1,d,n,sha1);
	
	/* Inversion de l'ordre des octets */
	big_to_bytes(8,sha1,bytes,TRUE);
	for(i=0;i<4;i++){
		tmp=bytes[i];
		bytes[i]=bytes[7-i];
		bytes[7-i]=tmp;
	}
	
	for(i=8;i<16;i++)
		bytes[i]=0;

	
	/* On g�n�re un point sur la courbe */
	irand(GetTickCount());
	bigrand(order,r);
	ecurve_init(a,b,p,MR_AFFINE);
    
	epoint_set(xA,yA,0,A);
	epoint_set(xA,yA,0,R);
	
	ecurve_mult(r,R,R);									/* R=r*A */
	epoint_get(R,xR,yR);
	
	printf("r: ");
	cotnum(r,stdout);

	/* Extraction des coordonn�es de R */	
	big_to_bytes(4,xR,coords,TRUE);
	big_to_bytes(4,yR,coords+4,TRUE);
	
	
	/* SHA(name+xR+yR) */
	mod1_shs_init(&sh1);
   	len=strlen(name);
	for(i=0;i<len;i++)
		shs_process(&sh1,name[i]);
	for(i=0;i<8;i++)
		shs_process(&sh1,coords[i]);
	shs_hash(&sh1,s2);									
	for(i=0;i<20;i++)
		printf("%02X",s2[i]);
	printf("\n");
	
	memcpy(&c,s2,4);									/* Copie les 4 premiers bytes du hash */
	c&=0x3FFFF;
	s3=mirvar(c);
	
	multiply(s3,k,k1); //k1=s3*k
	divide(k1,order,order);
	subtract(r,k1,r);
	if(exsign(r)==-1)
		add(r,order,r);
	big_to_bytes(4,r,bytes+8,TRUE);
	
	for(i=0;i<2;i++){
		tmp=bytes[8+i];
		bytes[8+i]=bytes[8+3-i];
		bytes[8+3-i]=tmp;
	}
		
	memcpy(bytes+12,&c,4);
	
	
    DecodeProdKey(serial,29,bytes,15);
    printf("\n%s\n",serial);

	epoint_free(A);
	epoint_free(R);
	
	mirkill(p);
	mirkill(k);
	mirkill(k1);
	mirkill(xA);
    mirkill(yA);
    mirkill(xR);
    mirkill(yR);
    mirkill(r);	
	mirkill(order);
	mirkill(a);
    mirkill(b);
    mirkill(sha1);
    mirkill(n);
    mirkill(d);
    mirkill(s3);
		
	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	mirexit();
}