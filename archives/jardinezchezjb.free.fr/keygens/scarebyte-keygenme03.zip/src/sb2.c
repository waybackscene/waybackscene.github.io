#include <stdio.h>
#include <string.h>
#include "rmd160.h"

int count1(int num); /* Compte le nombre de 1 dans la repr�sentation binaire de l'int en entr�e */
void toBase16(char * str, unsigned int num); /* Convertit un nombre en base 16 et place le r�sultat dans str */
void MixString(char * str); /* Modifie str (substitution) */
void DemixString(char * str); /* Proc�dure inverse de MixString */
char GenerateChar(char * str); /* G�n�re un nouveau char � partir de str */

#ifndef RMDsize
#define RMDsize 160
#endif

byte *RMD(byte *message)
/*
 * returns RMD(message)
 * message should be a string terminated by '\0'
 */
{
   dword         MDbuf[RMDsize/32];   /* contains (A, B, C, D(, E))   */
   static byte   hashcode[RMDsize/8]; /* for final hash-value         */
   dword         X[16];               /* current 16-word chunk        */
   unsigned int  i;                   /* counter                      */
   dword         length;              /* length in bytes of message   */
   dword         nbytes;              /* # of bytes not yet processed */

   /* initialize */
   MDinit(MDbuf);
   length = (dword)strlen((char *)message);

   /* process message in 16-word chunks */
   for (nbytes=length; nbytes > 63; nbytes-=64) {
      for (i=0; i<16; i++) {
         X[i] = BYTES_TO_DWORD(message);
         message += 4;
      }
      compress(MDbuf, X);
   }                                    /* length mod 64 bytes left */

   /* finish: */
   MDfinish(MDbuf, message, length, 0);

   for (i=0; i<RMDsize/8; i+=4) {
      hashcode[i]   =  MDbuf[i>>2];         /* implicit cast to byte  */
      hashcode[i+1] = (MDbuf[i>>2] >>  8);  /*  extracts the 8 least  */
      hashcode[i+2] = (MDbuf[i>>2] >> 16);  /*  significant bits.     */
      hashcode[i+3] = (MDbuf[i>>2] >> 24);
   }

   return (byte *)hashcode;
}

char GenerateChar(char * str){
	char table[]="ucfsbNARCIwitegMTUSHa5h3rEODxXyYzZvVpPqQmondjkKlLB0F1G2J6W4789";
	unsigned char len = strlen(str);
	char ebp_5=1;
	int nb1;
	unsigned int j,k;
	unsigned int tmp=len;
	unsigned int edx;
	unsigned int letter;
	
	while(len!=0){
		letter=str[ebp_5-1];
		nb1=count1(letter);
		switch(nb1){
			case 0:
			case 1:
			case 2:
			{
				j=(str[ebp_5 - 1] << 4) | (str[ebp_5 - 1] >> 3);
				k = ~((str[ebp_5 - 1] << 7) | (str[ebp_5 - 1] >> 5));
				j &= k;
			}
			break;
			case 3:
			case 4:
			{
				j = (str[ebp_5 - 1] << 7) | (str[ebp_5 - 1] >> 5);
				k = ~((str[ebp_5 - 1] << 3) | (str[ebp_5 - 1] >> 4));
				j &= k;
			}
			break;
			case 5:
			case 6:
			{
				j = (str[ebp_5 - 1] << 9) | (str[ebp_5 - 1] >> 6);
				k = ~((str[ebp_5 - 1] << 3) | (str[ebp_5 - 1] >> 2));
				j &= k;
			}
			break;
			default:
			{
				j = (str[ebp_5 - 1] << 2) | (str[ebp_5 - 1] >> 1);
				k = ~((str[ebp_5 - 1] << 9) | (str[ebp_5 - 1] >> 3));
				j &= k;
			}
		}
		edx=~(~tmp & j);
		tmp=~(tmp & ~j);
		tmp=~(tmp & edx);
		
		ebp_5++;
		len--;
	}
	return table[tmp % 0x3E];
}

void MixString(char * str){
	int len=strlen(str);
	unsigned char i=len-1;
	unsigned int j,k;
	char tmp;
	
	while(i!=0xFF){
		j=((len>>1)-i-1);
		j%=len;
		k=(len-i-1);
		k%= len;
		tmp=str[j];
		str[j]=str[k];
		str[k]=tmp;
		
		j=(len+i-1);
		j %=len;
		k=i;
		k%=len;
		tmp=str[j];
		str[j]=str[k];
		str[k]=tmp;
		i--;
	}
}

void DemixString(char * str){
	int len=strlen(str);
	unsigned char i=0;
	unsigned int j,k;
	char tmp;
	
	while(i!=len){
		j=(len+i-1);
		j %=len;
		k=i;
		k%=len;
		tmp=str[j];
		str[j]=str[k];
		str[k]=tmp;
		
		j=((len>>1)-i-1);
		j%=len;
		k=(len-i-1);
		k%= len;
		tmp=str[j];
		str[j]=str[k];
		str[k]=tmp;
		i++;
	}
}

int count1(int num){
	int compteur=0;
	while(num!=0){
		if(num%2==1)
			compteur++;
		num/=2;
	}
	return compteur;
}

void toBase16(char * str, unsigned int num){
	int i;
	for(i=0;i<8;i++){
		str[i]=(num % 16)+'A';
		num/=16;
	}
	strrev(str);
}

int main(){
	char s[]="A@A@A@A@A@A@A@A@A@A@A@A@";
	char serial[40];
	char hash[50];
	unsigned char base16[10];	
	char nom[30];
	unsigned char * rmd;
	char tab[50];
	char table[20];
	unsigned int * pRmd;
	unsigned int dtNum1;
	unsigned int dtNum2;
	
	int ebp_30;	
	int ebp_2F;
	int ebp_2E;
	int ebp_2D;
	unsigned int i,j;
	int plop;
	int compteur=0;
	char * pdest;
	
	memset(nom,0,30);
	printf("Name:\t\t");
	gets(nom);
	DemixString(nom);
	printf("Reg with this name: %s\n",nom);
	
	i=strlen(nom);
	while(i<20){
		nom[i]=GenerateChar(nom);
		i++;
	};
	
	rmd=RMD((byte *)nom);
	
	/* On construit un tableau tab � partir du ripemd */
	for(i=0;i<20;i++){
		tab[2*i]=(rmd[i] >> 4) + 'A';
		tab[2*i+1]=(rmd[i] & 0xF) + 'A';
	}
	
	/* On construit la table
	Les chars de tab sont copi�s dans la table s'ils n'y sont pas d�j�
	jusqu'� ce que la table contienne 8 chars ou que compteur soit sup�rieur
	� 0x14. Ensuite on compl�te la table avec les caract�res qui ne sont pas
	dedans, dans l'ordre alphab�tique */
	
	memset(table,0,sizeof(table));	
	i=0;
	j=0;
	while(j<8 && compteur<=0x14){
		pdest=strchr(table,tab[i]);
		if(!pdest){
			table[j]=tab[i];
			j++;
		}
		else compteur+=pdest-table;
		i++;
	}	
	
	for(i=0;i<16;i++){
		pdest=strchr(table,'A'+i);
		if(!pdest){
			table[j]='A'+i;
			j++;
		}
	}	
	
	memset(hash,0,sizeof(hash));
	
	pRmd=(unsigned int *)rmd;
	dtNum1 = (pRmd[1] | pRmd[2]) & ~pRmd[0];
	dtNum2 = (pRmd[1] ^ pRmd[2]) & pRmd[0];
	dtNum1 |= dtNum2;
	dtNum1 &= pRmd[3];	
	
	memset(base16,0,sizeof(base16));
	toBase16(base16,dtNum1);
	strcat(hash,base16);
	
	dtNum1=(~pRmd[4] | pRmd[2]) & ~pRmd[1];
	dtNum2=(~pRmd[2] | pRmd[4]) & pRmd[1];
	dtNum1 |= dtNum2;
	dtNum1 ^= pRmd[0];
	
	memset(base16,0,sizeof(base16));
	toBase16(base16,dtNum1);
	strcat(hash,base16);

	compteur=count1(rmd[8]);	
	dtNum1=~(pRmd[3] << compteur);
	dtNum2=(pRmd[4]>>0x10);
	compteur=count1(dtNum2 & 0xFF);
	
	dtNum2=(dtNum2 & 0xFF00) | compteur;
	dtNum2=pRmd[0] >> compteur;
	dtNum1 |= dtNum2;
	
	memset(base16,0,sizeof(base16));
	toBase16(base16,dtNum1);
	strcat(hash,base16);

	/*
	Modification du hash
	Si hash[2*i]=hash[2*i+1], hash[2*i+1]--
	sauf si hash[2*i+1]='A', dans ce cas hash[2*i+1]='B'
	*/
	for(i=0;i<strlen(hash)/2;i++){
		if(hash[2*i]==hash[2*i+1]){
			if(hash[2*i]=='A') hash[2*i+1]='B';
			else hash[2*i+1]--;
		}
	}
	
	/*
	Bruteforce de la routine � reverser
	16^2 possibilit�s � chaque fois donc c'est quasiment instantan�
	*/
	memset(serial,0,sizeof(serial));	
	for(i=0;i<strlen(s)/2;i++){
		while(serial[2*i]!=hash[2*i] || serial[2*i+1]!=hash[2*i+1] || serial[2*i]==serial[2*i+1]){
			if(s[2*i]=='P' && s[2*i+1]=='P'){
				printf("no serial\n");
				break;
			}
			
			if(s[2*i+1]=='P'){
				s[2*i]++;
				s[2*i+1]='A';
			}
			else s[2*i+1]++;

			pdest=strchr(table,s[2*i]);
			ebp_2D = (pdest-table) & 3;
			ebp_2F = (pdest-table) >> 2;
			pdest=strchr(table,s[2*i+1]);
			ebp_2E = (pdest-table) & 3;
			ebp_30 = (pdest-table) >> 2;
			if(ebp_2D==ebp_2E){
				plop = (ebp_30 << 2) + ((ebp_2E + 1) & 3);
				serial[2*i] = table[plop];
				plop = (ebp_2F << 2) + ((ebp_2D + 1) & 3);
				serial[2*i+1] = table[plop];
			}
			else if(ebp_30==ebp_2F){
				plop = (((ebp_30 + 1) & 3) << 2) + ebp_2E;
				serial[2*i] = table[plop];
				plop = (((ebp_2F + 1) & 3) << 2) + ebp_2D;
				serial[2*i+1] = table[plop];
			}
			else {
				plop = (ebp_30 << 2) + ebp_2D;
				serial[2*i] = table[plop];
				plop = ((ebp_2F) << 2) + ebp_2E;
				serial[2*i+1] = table[plop];
			}
		}
	}

	/* Tri du serial */
	DemixString(s);
	memset(serial,0,sizeof(serial));
	for(i=0;i<6;i++)
		strncpy(serial+5*i,s+4*i,4);
	for(i=0;i<5;i++)
		serial[4+5*i]='-';
	
	printf("Serial:\t\t%s\n",serial);

	return 0;
}
