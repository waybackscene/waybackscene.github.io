////////////////////////////////////////////////////////////
// Crackme v22 (mini-psyho) by veneta
// Keygen by jB
// Aug. 29th, 2005
//
// ElGamal-128
// g=985AD5D73B04816BD6CF039C125A52EA
// y=9A45BBF7BD4859AF4D4979978BA7F35F
// p=F79A48C7431F55787B2BEA04B447ED73
// x=B687E4D07A6A92A201627CC069866815 (computed using index calculus)
//
////////////////////////////////////////////////////////////


#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "resource.h"
#include "miracl.h"

#define MIN_NAME 0
#define MAX_NAME 32

DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,"Crackme v22 (mini-psyho) by veneta");
			SetDlgItemText(hwnd,IDC_NAME,"jB");			
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDC_NAME:
				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
			case IDC_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDC_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }
   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

DWORD WINAPI GenererSerial(HWND hwnd){
	miracl *mip=mirsys(50,0);
	mip->IOBASE=16;

    char name[35];
	char serial[80],serial2[40];
	unsigned char s[20];
	sha sh;
	
	int i,len;

	big x,g,y,k,h,p,p1;
	x=mirvar(0);
	g=mirvar(0);
	y=mirvar(0);
	k=mirvar(0);
	h=mirvar(0);
	p=mirvar(0);
	p1=mirvar(0);

	GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME);
	len=strlen(name);
	if(len<MIN_NAME || len>MAX_NAME){
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a valid name...");
		return 0;
	}

	shs_init(&sh);
    for(i=0;i<len;i++) shs_process(&sh,name[i]);
    shs_hash(&sh,s);
	bytes_to_big(16,s,h);

	cinstr(g,"985AD5D73B04816BD6CF039C125A52EA");
	cinstr(x,"B687E4D07A6A92A201627CC069866815");
	cinstr(y,"9A45BBF7BD4859AF4D4979978BA7F35F");
	cinstr(p,"F79A48C7431F55787B2BEA04B447ED73");
	decr(p,1,p1);

	lgconv(rand()*2+1,k);	// k always odd so that gcd(k,p-1)=1
	powmod(g,k,p,g);		// s1 = g^k mod p
	multiply(g,x,x);
	mad(k,h,x,p1,p1,k);		// s2 = x*s1 + k+h mod p-1

	cotstr(g,serial);
	cotstr(k,serial2);
	strcat(serial," ");
	strcat(serial,serial2);

	SetDlgItemText(hwnd,IDC_SERIAL,serial);

	mirkill(x);
	mirkill(g);
	mirkill(y);
	mirkill(k);
	mirkill(h);
	mirkill(p);
	mirkill(p1);
	mirexit();
    return 0;
}