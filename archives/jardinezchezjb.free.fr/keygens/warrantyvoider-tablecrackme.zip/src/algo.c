#include <windows.h>

void process_serial(char *name, char *serial)
{
	int i=0;
	int len=strlen(name);
	unsigned int sum=0;

	__asm
	{
		/*
		Hash of the name (ripped from the crackme)
		The result is stored in 'sum'
		*/

		mov esi, name
		mov edi, len
		xor edx, edx
		xor ecx, ecx
loc1:
		movsx edx, byte ptr [edx+esi]
		xor eax, eax
loc2:
		movsx ebx, byte ptr [eax+esi]
		add ecx, edx
		add ebx, edx
		add ebx, ebx
		add ecx, ecx
		xor ecx, ebx
		add eax, 1
		add sum, ecx
		cmp eax, edi
		jb loc2
		mov edx, i
		add edx, 1
		cmp edx, edi
		mov i, edx
		jb loc1

		/*
		Original algorithm
		xor edx, 8d37423ah
		ror edx, 5
		bswap edx
		ror edx, 15h
		add edx, 0f5a73c0h 

		Let's reverse that:
		*/
		mov edx, sum
		sub edx, 0f5a73c0h
		rol edx, 15h
		bswap edx
		rol edx, 5
		xor edx, 8d37423ah
		mov sum, edx
	}

	wsprintf(serial,"%08X", sum);
}

