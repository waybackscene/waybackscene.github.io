////////////////////////////////////////////////////////////
// warrantyVoider - The secret of the invisible lookup table
// Keygen by jB
// Dec. 30th, 2005
//
// NT Kernel level hooking
////////////////////////////////////////////////////////////

#define WIN32_EXTRA_LEAN

#include <windows.h> 	
#include "rsrc/resource.h"

#define PROGNAME "The secret of the invisible lookup table"
#define MIN_NAME 5
#define MAX_NAME 100
#define MAX_SERIAL 10

void process_serial(char *name, char *serial);
DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,PROGNAME " - Keygen");
			SetDlgItemText(hwnd,IDC_NAME,"jB");
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
			case IDC_NAME:
   				if(HIWORD(wParam)==EN_CHANGE)
					GenererSerial(hwnd);
				break;
   			case IDB_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDB_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_KEYGEN),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

DWORD WINAPI GenererSerial(HWND hwnd){
    unsigned char name[MAX_NAME];
	char serial[MAX_SERIAL];
	memset(serial,0,MAX_SERIAL);

	if(GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME)<MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return 1;
	}
	process_serial(name, serial);
	SetDlgItemText(hwnd, IDC_SERIAL,serial);
    return 0;
}