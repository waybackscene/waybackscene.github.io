/**********************************************************************
Find a signature (r,s) and a private key x (according to the ECDSA
scheme) for the messages e1 and e2, two different hashes of 160 bits.

For each message e:
J = u1*G + u2*H
  = w*e*G + w*r*H , with w=s^(-1) mod n
  = (w*e + w*r*d)*G, with H = d*G

The *abscisses* of the obtained points must be the same, with the two
messages.
J(x, y) and -J(x, -y) have the same abscisses. Let's check...
w*e1 + w*r*d = -w*e2 - w*r*d
w(e1+e2) = -2*w*r*d
So d = (n-2)^(-1) * (e1+e2) * r^(-1) mod n
That's all folks.

No we can generate a valid signature for the two messages. There is a
small trick with the LSB of one point, but no real difficulty.

As WiteG wrote it in his Readme, it was 3 years since he hadn't written
a crackme. This one is really nice, I enjoyed it. Thanks a lot! I'm waiting
for your Crackme 11.

jB, Mar. 22nd, 2006
***********************************************************************/

#include <windows.h>
#include "miracl.h"

unsigned char	szTag[]= ", you just cracked my 10th crackme.. congrats!";

void hashing(unsigned char *dataIn, int lenIn, big hash)
{
	unsigned char h[20];
	sha sh;
	int i;

	shs_init(&sh);
	for (i=0;i<lenIn;i++)
		shs_process(&sh,dataIn[i]);

	shs_hash(&sh,h);
	bytes_to_big(20,h,hash);
}

void process_serial(char *name, char *serial1, char *serial2, char *serial3)
{
	unsigned long lName, snLSB;
	miracl *mip=mirsys(100,10);
	char szName[120];

	/* Big Numbers initialisation */
	big secp160r1_a = mirvar(0);
	big secp160r1_b = mirvar(0);
	big secp160r1_p = mirvar(0);
	big secp160r1_n = mirvar(0);
	big secp160r1_x = mirvar(0);
	big secp160r1_y = mirvar(0);

	big x=mirvar(0);
	big r=mirvar(0);
	big s=mirvar(0);
	big e1=mirvar(0);
	big e2=mirvar(0);
	big k=mirvar(0);
	big r1=mirvar(0);
	big n2=mirvar(0);
	big d=mirvar(0);

	/* Points */
	epoint* pointG = epoint_init();
	epoint* pointH = epoint_init();
	epoint* pointJ = epoint_init();

	mip->IOBASE=16;
	strcpy(szName, name);

	/* Curve parameters and fixed point */
	cinstr(secp160r1_a, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFC");
	cinstr(secp160r1_b, "1C97BEFC54BD7A8B65ACF89F81D4D4ADC565FA45");
	cinstr(secp160r1_p, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFF");

	cinstr(secp160r1_n, "100000000000000000001F4C8F927AED3CA752257");
	cinstr(secp160r1_x, "4A96B5688EF573284664698968C38BB913CBFC82");
	cinstr(secp160r1_y, "23A628553168947D59DCC912042351377AC5FB32");

	cinstr(n2, "80000000000000000000FA647C93D769E53A912B");	// (n-2)^(-1) mod n

	ecurve_init(secp160r1_a,secp160r1_b,secp160r1_p,MR_PROJECTIVE);

	epoint_set(secp160r1_x,secp160r1_y,0,pointG);

	/* Hashes name and modified name */
	lName = lstrlen(szName);
	hashing(szName, lName, e1);

	lstrcat(szName, szTag);
	lName = lstrlen(szName);
	hashing(szName, lName, e2);

	/*
	Small bruteforce, I don't know if there is a smart way... 
	We search for H(r, y1)=k*G and J(x, y2)=d*G such as:
	r % 2 = lsb(x), k being a random number
	*/

	irand(GetTickCount());
	do 
	{
		add(e1, e2, d);
		bigrand(secp160r1_n, k);
		ecurve_mult(k, pointG, pointH);
		epoint_get(pointH, r, r);
		snLSB=remain(r, 2);
		copy(r, r1);
		xgcd(r1, secp160r1_n, r1, r1, r1); // r1 = r^(-1) mod n
		mad(d, r1, r1, secp160r1_n, secp160r1_n, d);
		mad(d, n2, n2, secp160r1_n, secp160r1_n, d);
		ecurve_mult(d, pointG, pointJ);
	} while(snLSB!=epoint_get(pointJ, x, x));
	
	mad(d, r, e1, secp160r1_n, secp160r1_n, s);	// s = e1*d+r mod n
	xgcd(k, secp160r1_n, k, k, k); // k = k^(-1) mod n
	mad(k,s,s,secp160r1_n,secp160r1_n,s); // s = k^(-1) * (e1*d+r) mod n

	cotstr(x, serial1);
	cotstr(r, serial2);
	cotstr(s, serial3);

	mirkill(x);
	mirkill(r);
	mirkill(s);
	mirkill(e1);
	mirkill(e2);
	mirkill(k);
	mirkill(r1);
	mirkill(n2);
	mirkill(d);

	mirkill(secp160r1_a);
	mirkill(secp160r1_b);
	mirkill(secp160r1_p);
	mirkill(secp160r1_n);
	mirkill(secp160r1_x);
	mirkill(secp160r1_y);

	epoint_free(pointG);
	epoint_free(pointH);
	epoint_free(pointJ);

	mirexit();
}

