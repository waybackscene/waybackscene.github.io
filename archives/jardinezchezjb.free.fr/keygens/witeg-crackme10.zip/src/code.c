////////////////////////////////////////////////////////////
// WiteG - Crackme 10
// Keygen by jB
// Mar. 22nd, 2005
//
// ECDSA - Signing two different messages with the same signature
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#define WIN32_EXTRA_LEAN

#include <windows.h> 	
#include "rsrc/resource.h"

#define PROGNAME "CrackMe 10 by WiteG"
#define MIN_NAME 4
#define MAX_NAME 0x40
#define MAX_SERIAL 0x40

void process_serial(char *name, char *s1, char *s2, char *s3);
DWORD WINAPI GenererSerial(HWND hwnd);
HINSTANCE hInst;

BOOL CALLBACK DlgProc( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hwnd,0); 
   			break;

		case WM_INITDIALOG:
			SetWindowText(hwnd,PROGNAME " - Keygen");
			SetDlgItemText(hwnd,IDC_NAME,"jB");
			SendDlgItemMessage(hwnd,IDC_NAME,EM_LIMITTEXT,MAX_NAME,0);
			SetFocus(GetDlgItem(hwnd,IDC_NAME));
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
   			case IDB_GENERATE:
				GenererSerial(hwnd);
				break;
			case IDB_EXIT:
				EndDialog(hwnd,0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_KEYGEN),NULL,DlgProc,(LPARAM)NULL);
 	return 0;
}

DWORD WINAPI GenererSerial(HWND hwnd){
    unsigned char name[MAX_NAME];
	char serial1[MAX_SERIAL];
	char serial2[MAX_SERIAL];
	char serial3[MAX_SERIAL];
	memset(serial1,0,MAX_SERIAL);
	memset(serial2,0,MAX_SERIAL);
	memset(serial3,0,MAX_SERIAL);

	if(GetDlgItemText(hwnd,IDC_NAME,name,MAX_NAME)<MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL1,"Please enter a longer name...");
		return 1;
	}
	process_serial(name, serial1, serial2, serial3);
	SetDlgItemText(hwnd, IDC_SERIAL1,serial1);
	SetDlgItemText(hwnd, IDC_SERIAL2,serial2);
	SetDlgItemText(hwnd, IDC_SERIAL3,serial3);
    return 0;
}