/**********************************************************************
Signature generation over GF(p^3).

The serial is entered using base64 charset. It is composed of two parts
r and s, of 64 bits. Two points P and Q are taken on the field, such as
Q=d*P. The field is of order n=FFFCCDE18D3CA8AB.
The name is hashed using among other MD5, to generate a 64 bit string h.

Signature verification:
-----------------------
Verify that r and s are integers in the interval [0, n-1].
Compute h = Hash(name)
Compute X = r*P + s*Q
If X = infinite point then reject the signature
Convert the x-coordinate of X to an integer x, and compute v = x mod n
If r - x = h accept the signature,
else reject the signature.

The DLP has been computed using Pollard's Rho algorithm. The implementation
has been done in C using Miracl. It took about 7 hours to find d such as
Q = d*P. I wrote an othier implementation using Maple, but is was damn slow.
It would have taken something like three weeks.
Finally d = 1F1B2BB3135CFB06
Now it is easy to generate a valid signature:

Signature generation:
---------------------
Select k in [1, n-1]
Compute k*P = (x1, y1) and convert x1 to an integer x.
Compute r = x + h mod n
Compute h = Hash(name)
Compute s = (k-r) * d^(-1) mod n
Return (r, s)

Some quick explanations:
We want : r - x = h, ie : x = r - h
Let take k a random number. We want :
absc(k*P) = absc(r*P * s*Q) = r - h
So :
 . r = h + absc(k*P)
 . absc(r*P * s*Q) = absc((r + s*d)*P)
                   = absc(k*P)
   So k = r + s*d mod n
   That gives : d = (k-r)^(-1) mod n

I don't check if s = 0 in the keygen, it would be really bad luck =)

This is a really, really nice crackme. Definitely not for beginners or
intermediate crackers. WiteG, I wait for your next crackme =) Thanks a
lot for this one, you are really elite.

jB, Mar. 31, 2006
***********************************************************************/

#include <windows.h>
#include "miracl.h"
#include "global.h"
#include "md5.h"

struct s_point
{
	BOOL set;
	UINT32 x[3];
	UINT32 y[3];
};

typedef struct s_point *point;

void point_getx(point p, char *x);				// gets the abscissa of p. x must be at least 128 bits
void field_add(point p1, point p2);				// on exit p2 = p1 + p2
void field_mult(char *k, point p1, point p2);	// on exit p2 = k * p1. k : 96 bit number


/* Copies one point to another one.
   On exit p_out = p_in */
void point_copy(point p_in, point p_out)
{
	int i;
	if(p_in->set==FALSE)
	{
		p_out->set=FALSE;
		return;
	}
	for(i=0; i<3; i++)
	{
		p_out->x[i]=p_in->x[i];
		p_out->y[i]=p_in->y[i];
	}
}

/* Multiplication by a scalar
   On exit p2 = k*p1 */
void field_bigmult(big k, point p1, point p2)
{
	int i;
	unsigned char str[16];	// assumes that length(k) < 128 bits, always the case
							// which is always the case here
	big_to_bytes(16, k, str, TRUE);
	for(i=0; i<8; i++)
	{
		unsigned char tmp=str[i];
		str[i]=str[15-i];
		str[15-i]=tmp;
	}
	field_mult(str, p1, p2);
}

void point_biggetx(point p, big x)
{
	int i;
	unsigned char str[16];
	point_getx(p, str);
	
	for(i=0; i<4; i++)
	{
		unsigned char tmp=str[i];
		str[i]=str[7-i];
		str[7-i]=tmp;
	}
	bytes_to_big(8, str, x);
}

/* Creates a point at infinite */
point point_null()
{
	int i;
	point p=malloc(sizeof(struct s_point));
	p->set=FALSE;
	for(i=0; i<3; i++)
	{
		p->x[i]=0;
		p->y[i]=0;
	}
	return p;
}

/* Creates a point using two initialisation vectors */
point point_new(unsigned int *px, unsigned int *py)
{
	int i;
	point p=malloc(sizeof(struct s_point));
	p->set=TRUE;
	for(i=0; i<3; i++)
	{
		p->x[i]=px[i];
		p->y[i]=py[i];
	}
	return p;
}

/* Base 64 conversion. This routine has been written by tE!, if
I remember well. */
static const char base64digits[] =
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void to64frombits(unsigned char *out, const unsigned char *in, int inlen)
/* raw bytes in quasi-big-endian order to base 64 string (NUL-terminated) */
{
	for (; inlen >= 3; inlen -= 3)
	{
		*out++ = base64digits[in[0] >> 2];
		*out++ = base64digits[((in[0] << 4) & 0x30) | (in[1] >> 4)];
		*out++ = base64digits[((in[1] << 2) & 0x3c) | (in[2] >> 6)];
		*out++ = base64digits[in[2] & 0x3f];
		in += 3;
	}
	if (inlen > 0)
	{
		unsigned char fragment;

		*out++ = base64digits[in[0] >> 2];
		fragment = (in[0] << 4) & 0x30;
		if (inlen > 1)
			fragment |= in[1] >> 4;
		*out++ = base64digits[fragment];
		*out++ = (inlen < 2) ? '=' : base64digits[(in[1] << 2) & 0x3c];
		*out++ = '=';
	}
	*out = '\0';
}

/* Creates a 64 bit hash from the name, and converts it to a big integer */
void hashing(char *name, big hash)
{
	int i;
	unsigned char h[16];
	MD5_CTX ctx;
	MD5Init(&ctx);
	MD5Update(&ctx, name, strlen(name));
	MD5Final(h, &ctx);

	__asm
	{
		mov ebx, dword ptr [h+8]
		xor dword ptr [h], ebx
		mov eax, dword ptr [h+0Ch]
		xor dword ptr [h+4], eax
	}
	for(i=0; i<4; i++)
	{
		unsigned char tmp=h[i];
		h[i]=h[7-i];
		h[7-i]=tmp;
	}
	bytes_to_big(8, h, hash);
}

/* Converts the signature (r, s) to base 64 */
int format_signature(char *serial, big r, big s)
{
	int i;
	unsigned char buffer[16];

	big_to_bytes(8, s, buffer, TRUE);
	big_to_bytes(8, r, buffer+8, TRUE);

	for(i=0; i<8; i++)
	{
		unsigned char tmp=buffer[i];
		buffer[i]=buffer[15-i];
		buffer[15-i]=tmp;
	}
	to64frombits(serial, buffer, 16);
	return (int)strlen(serial);
}

/* main procedure for serial computation */
void process_serial(char *name, char *serial)
{
	miracl *mip=mirsys(100,16);
	big n=mirvar(0);
	big k=mirvar(0);
	big h=mirvar(0);
	big r=mirvar(0);
	big s=mirvar(0);
	big d=mirvar(0);

	/* Point initialisation */
	int p1x[]={0x272D02, 0x03EE82, 0x062585};
	int p1y[]={0x112619, 0x1E112A, 0x280082};

	int p2x[]={0x1aa1dd, 0x11d935, 0x12cbfc};
	int p2y[]={0x09c69b, 0x00e91c, 0x05e285};

	point p1=point_new(p1x, p1y);
	point p2=point_new(p2x, p2y);	/* p2 = d*p1 */
	point p3=point_null();

	mip->IOBASE=16;
	cinstr(n, "FFFCCDE18D3CA8AB");	/* order of points */
	cinstr(d, "E52B6EFEB4ED51A9");	/* d^(-1) mod n */

	hashing(name, h);

	do{
		/* First part of the signature
		Generates k, then computes r = abs(k*p1)+h mod n */
		irand(GetTickCount());
		bigrand(n, k);
		field_bigmult(k, p1, p3);
		point_biggetx(p3, r);
		add(r, h, r);
		divide(r, n, n);

		/* Second part of the signature
		s = (k-r) * d^(-1) mod n */
		subtract(k, r, s);
		if(exsign(s)==-1)
			add(s, n, s);
		multiply(s, d, s);
		divide(s, n, n);
	}
	while(format_signature(serial, r, s)!=24);

	mirkill(d);
	mirkill(s);
	mirkill(r);
	mirkill(h);
	mirkill(k);
	mirkill(n);
	mirexit();
}
