////////////////////////////////////////////////////////////
// CrackMe 12 by WiteG/xt
// Keygen by jB
// Dec. 18, 2006
//
// LUC cryptosystem - Custom hash
//
// http://jardinezchezjb.free.fr / resrever@gmail.com
////////////////////////////////////////////////////////////

#include "all.h"
#include "miracl.h"

void CustomHash(LPBYTE digest, DWORD len, LPBYTE input);

/* Compute the Legendre symbol (a|p) such as:
 (a|p) = 0 if p divides a
 (a|p) = 1 if a is a quadratic residue mod p
 (a|p) = -1 else
*/
int legendre(big a, big b)
{
	big w = mirvar(0);
	copy(a, w);
	divide(w, b, b);
	if(size(w) == 0)
		return 0;
	if(sqroot(a, b, w))
		return 1;
	else return -1;
	mirkill(w);
}

/* Compute the discriminant
   D = M^2 - 4
*/
void disc(big D, big M)
{
	copy(M, D);
	multiply(D, D, D);
	decr(D, 4, D);
}

/* Compute the private key d of the cryptosystem.
   d * e = 1 mod S(N)
   with S(N) = lcm(p - (D|p), q - (D|q))
   and N = p * q
*/
void GetPrivateKey(big d, big m, big e, big p, big q)
{
	int l;
	big D = mirvar(0);
	big p1 = mirvar(0);
	big q1 = mirvar(0);
	big g = mirvar(0);
	disc(D, m);

	copy(p, p1);
	l = legendre(D, p);
	if(l == -1)
		incr(p1, 1, p1);
	if(l == 1)
		decr(p1, 1, p1);

	copy(q, q1);
	l = legendre(D, q);
	if(l == -1)
		incr(q1, 1, q1);
	if(l == 1)
		decr(q1, 1, q1);

	egcd(p1, q1, g);
	multiply(p1, q1, p1);
	divide(p1, g, p1);

	copy(e, d);
	xgcd(d, p1, d, d, d);
	mirkill(D);
	mirkill(p1);
	mirkill(q1);
	mirkill(g);
}

DWORD WINAPI GenererSerial(HWND hwnd)
{
	big m, c, e, d, n, p, q;
	miracl *mip;
	int i;
	int l;
	DWORD k;
	TCHAR name[MAX_NAME];
	DWORD h[20];
	BYTE cipher[8];
	TCHAR serial[MAX_SERIAL];

	if(GetDlgItemText(hwnd, IDC_NAME, name, MAX_NAME) < MIN_NAME)
	{
		SetDlgItemText(hwnd, IDC_SERIAL,"Please enter a longer name...");
		return 0;
	}
	mip = mirsys(50,0);

	/* Hash the name and do some computations to obtain a 64 bit buffer */
	CustomHash(h, strlen(name), name);

	k = _lrotl(h[4], 7);
	((DWORD *)cipher)[0] = k ^ h[0] ^ h[2];
	k = _lrotl(k, 18);
	((DWORD *)cipher)[1] = k ^ h[1] ^ h[3];

	for(i = 0; i < 4; i++)
	{
		BYTE tmp = cipher[i];
		cipher[i] = cipher[7 - i];
		cipher[7 - i] = tmp;
	}
	n = mirvar(0);
	m = mirvar(0);
	e = mirvar(0);
	p = mirvar(0);
	q = mirvar(0);
	c = mirvar(0);
	d = mirvar(0);

	mip->IOBASE=16;
	bytes_to_big(8, cipher, c);
	cinstr(e, "100000001");		// Public key
	cinstr(p, "852D76F");
	cinstr(q, "1EC1843937");
	multiply(p, q, n);			// RSA modulus n = p * q

	GetPrivateKey(d, c, e, p, q);
	lucas(c, d, n, m, m);		// Compute the Lucas exponentiation mod n
	big_to_bytes(8, m, cipher, TRUE);

	for(i = 0; i < 8; i++)
		sprintf(serial + 2 * i, "%02X", cipher[7 - i]);

	SetDlgItemText(hwnd, IDC_SERIAL, serial);
	mirkill(n);
	mirkill(m);
	mirkill(e);
	mirkill(p);
	mirkill(q);
	mirkill(c);
	mirkill(d);
	mirexit();
	return 0;
}
