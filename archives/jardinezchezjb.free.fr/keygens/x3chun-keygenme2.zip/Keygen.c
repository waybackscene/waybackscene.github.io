/************************************
  x3chun's Crypto KeyGenMe #2
  Keygen by jB

  Date: 22/12/2003
  Protection: Modified MD4 + TEA
************************************/

#include <stdio.h>
#include <string.h>
#include "md4.h"

void code(long* v, long* k)  {              
  unsigned long y=v[0],z=v[1], sum=0,
  delta=0x9e3779b9, n=32 ;
  while (n-->0) {
      sum += delta ;
      y += (z<<4)+k[0] ^ z+sum ^ (z>>5)+k[1] ;
      z += (y<<4)+k[2] ^ y+sum ^ (y>>5)+k[3] ;
              } 
      v[0]=y ; v[1]=z ; 
}

int main() {
  unsigned char string[256];

  long serial[]={0x78336368,0x756E3A29}; // "x3chun:)"
  MD4_CTX context;
  unsigned char digest[16];
  unsigned int len, i=0;

  printf("x3chun's KeyGenMe #2 - Keygen by jB\n\nName:\t");
  gets(string);

  MD4Init (&context); // Modified (see MD4.C, a constant has been changed)
  MD4Update (&context, string, strlen(string));
  MD4Final (digest, &context);

  while(digest[i++]!=0);// If a null char is found in the hash, the next chars
  while(i<16)		// of the hash are put to 0.
      digest[i++]=0;	// The procedure used by x3chun calls lstrcpy, so the
			// chars following \0 are not copied and are set to zero.
  
  // TEA encryption
  code((long *)serial, (long*) digest);

  printf("Serial:\t%08lX%08lX\n",serial[0],serial[1]);
 return(0);
}
