#include "all.h"
#include <stdio.h>
#include "resource.h"
#include "aes.h"
#include "crc32.h"

#define SERIAL_LENGTH_MAX 40
#define NAME_LENGTH_MAX   100
#define NAME_LENGTH_MIN   1

VOID InitStuff(HWND hWnd)
{
	int i;
	for(i = 0; i < 16; i++)
		CheckDlgButton(hWnd, IDC_CHECK1 + i, BST_CHECKED);
	SendMessage(GetDlgItem(hWnd, IDC_SERIALNUMBER), EM_SETLIMITTEXT, 8, 0);
	SetDlgItemText(hWnd, IDC_SERIALNUMBER, "00000000");
}

void GenererSerial(HWND hWnd)
{
	aes_context ctx;
	static BYTE aeskey[] =
	{
		0xE9, 0x3F, 0x0D, 0xA1, 0x96, 0x95, 0x31, 0x04,
		0x49, 0x2D, 0x9E, 0x61, 0x83, 0xCF, 0x09, 0x6F
	};
	char szName[NAME_LENGTH_MAX];
	char szActivationCode[SERIAL_LENGTH_MAX];
	char szSerialNumber[9];
	crc32_t dwCrcName;
	BYTE aPlainLicense[16];
	BYTE aCryptedLicense[16];
	WORD wOptions;
	WORD wFixed = 0x1979;
	DWORD dwSerialNumber = 0x12345678;
	int i;
	DWORD dwRandom = 0;

	if(GetDlgItemText(hWnd, IDC_NAME, szName, NAME_LENGTH_MAX) < NAME_LENGTH_MIN)
	{
		SetDlgItemText(hWnd, IDC_ACTIVATION, "Please enter a longer name...");
		return;
	}
	GetDlgItemText(hWnd, IDC_SERIALNUMBER, szSerialNumber, 9);
	if(sscanf(szSerialNumber, "%08X", &dwSerialNumber) == 0)
	{
		SetDlgItemText(hWnd, IDC_ACTIVATION, "Please enter a valid serial number...");
		return;
	}

	for(i = 0; i < 16; i++)
	{
		wOptions <<= 1;
		wOptions |= IsDlgButtonChecked(hWnd, IDC_CHECK1 + 15 - i);
	}

	dwCrcName = crc32(0, (LPBYTE)szName, strlen(szName));
	memset(aPlainLicense, 0, sizeof(aPlainLicense));
	memcpy(aPlainLicense, &dwCrcName, sizeof(dwCrcName));
	memcpy(aPlainLicense + 4, &wOptions, sizeof(wOptions));
	memcpy(aPlainLicense + 6, &wFixed, sizeof(wFixed));
	memcpy(aPlainLicense + 8, &dwSerialNumber, sizeof(dwSerialNumber));
	aes_set_key(&ctx, aeskey, 128);
	
	DWORD dwChecksum;
	do
	{
		dwChecksum = 0;
		memcpy(aPlainLicense + 12, &dwRandom, sizeof(dwRandom));
		aes_encrypt(&ctx, aPlainLicense, aCryptedLicense);
		for(i = 0; i < 12; i++)
			dwChecksum += aCryptedLicense[i];
		dwRandom++;
		if(dwRandom == 0)
		{
			dwSerialNumber++;
			memcpy(aPlainLicense + 8, &dwSerialNumber, sizeof(dwSerialNumber));
		}
	} while((aCryptedLicense[14] != (dwChecksum >> 8)) || (aCryptedLicense[15] != (BYTE)dwChecksum));
	
	for(i = 0; i < 16; i++)
		sprintf(szActivationCode + 2 * i, "%02X", aCryptedLicense[i]);

	FILE *f; /* Too lazy for a GetOpenFileName... */
	fopen_s(&f, "key.dat", "wb");
	fprintf(f, "N=%s K=%s", szName, szActivationCode);
	fclose(f);

	sprintf(szSerialNumber, "%08X", dwSerialNumber);
	SetDlgItemText(hWnd, IDC_SERIALNUMBER, szSerialNumber);
	SetDlgItemText(hWnd, IDC_ACTIVATION, szActivationCode);
}
