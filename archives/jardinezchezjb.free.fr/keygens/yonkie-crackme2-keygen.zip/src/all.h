#include <Windows.h>

#define PROGNAME "Yonkie's Crackme #2"
