#include "all.h"
#include "resource.h"

void GenererSerial(HWND hwnd);
void InitStuff(HWND hwnd);

HINSTANCE hInst;

BOOL CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam,LPARAM lParam)
{ 
   switch (uMsg)
   {
   		case WM_CLOSE:
   			EndDialog(hWnd, 0); 
   			break;

		case WM_INITDIALOG:
			{
				InitStuff(hWnd);
				HANDLE hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDI_ICON));
				SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
				SetDlgItemText(hWnd, IDC_NAME, "JB");
				SetWindowText(hWnd, PROGNAME" - Keygen");
				SetFocus(GetDlgItem(hWnd, IDC_NAME));
			}
			return FALSE;
			
 		case WM_COMMAND:
   			switch(LOWORD(wParam))
   			{
			case IDC_GENERATE:
				GenererSerial(hWnd);
				break;
			case IDC_EXIT:
				EndDialog(hWnd, 0);
				break;
   			}
 		default:
   			return FALSE;
   }   
   return TRUE;
}


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{ 
	hInstance = GetModuleHandle(NULL);
	hInst = hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_KEYGEN), NULL, DlgProc, (LPARAM)NULL);
 	return 0;
}
