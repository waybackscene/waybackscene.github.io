//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rsrc.rc
//
#define IDI_ICON                        5
#define IDD_KEYGEN                      101
#define IDC_NAME                        1000
#define IDC_EXIT                        1003
#define IDC_ACTIVATION                  1010
#define IDC_GENERATE                    1011
#define IDC_ACTIVATION2                 1012
#define IDC_SERIALNUMBER                1012
#define IDC_CHECK1                      1020
#define IDC_CHECK2                      1021
#define IDC_CHECK3                      1022
#define IDC_CHECK4                      1023
#define IDC_CHECK5                      1024
#define IDC_CHECK6                      1025
#define IDC_CHECK7                      1026
#define IDC_CHECK8                      1027
#define IDC_CHECK9                      1028
#define IDC_CHECK10                     1029
#define IDC_CHECK11                     1030
#define IDC_CHECK12                     1031
#define IDC_CHECK13                     1032
#define IDC_CHECK14                     1033
#define IDC_CHECK15                     1034
#define IDC_CHECK16                     1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
