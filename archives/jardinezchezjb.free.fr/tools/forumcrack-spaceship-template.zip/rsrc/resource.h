//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rsrc.rc
//
#define IDD_KEYGEN                      101
#define IDB_ABOUT_DOWN                  102
#define FFF_ICON                        103
#define IDB_ABOUT_HOVER                 103
#define IDB_EXIT_DOWN                   104
#define IDB_EXIT_HOVER                  105
#define IDB_GENERATE_DOWN               106
#define IDB_GENERATE_HOVER              107
#define IDB_BITMAP1                     109
#define IDB_KEYGEN                      110
#define IDB_ABOUT                       112
#define IDD_DIALOG1                     114
#define IDD_ABOUT                       114
#define IDR_FONT1                       116
#define IDB_AIRCRAFT                    117
#define IDB_ENNEMY2                     119
#define IDB_ENNEMY3                     120
#define IDB_SWORD                       121
#define IDB_BITMAP7                     122
#define IDB_ENNEMY2_                    122
#define IDB_ENNEMY4_                    123
#define IDB_BIG_EXPLOSION               124
#define IDB_ENNEMY                      126
#define IDB_ENNEMY3_                    127
#define IDB_ENNEMY4                     128
#define IDB_ENNEMY_                     129
#define IDB_EXPLOSION                   130
#define IDR_RT_FONT1                    131
#define IDR_FONT2                       132
#define ID_MYMOD                        133
#define IDC_SERIAL                      1003
#define IDB_EXIT                        1005
#define IDC_EXIT                        1005
#define IDB_GENERATE                    1006
#define IDC_GENERATE                    1006
#define IDC_KEYGEN                      1007
#define IDC_BUTTON1                     1008
#define IDC_ABOUT                       1008
#define IDC_GAME                        1009
#define IDT_TIMER                       1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
