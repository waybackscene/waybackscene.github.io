#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include "rsrc/resource.h"
#include "minifmod.h"

extern HINSTANCE hInst;
#define PROGNAME "Forumcrack - Template contest"

BOOL CALLBACK DlgProc2( HWND hwnd, UINT uMsg, WPARAM wParam,LPARAM lParam);