
/******************************************************************************\
*                     CodeMe#2 propos� par Clandestino                         *
*                            Cod� par Kharneth                                 *
*                                                                              *
*  kharneth@free.fr        Aides &                                             *
*                       Didacticiels sur http://www.developpez.com             *
*                                        http://www.cppfrance.com              *
*                                        http://www.foosyerdoos.fsnet.co.uk/   *
\******************************************************************************/


// D�claration des biblioth�ques utilis�es.
#include <windows.h>             // Fonctions standards de Windows.
#include <commctrl.h>            // Contr�les suppl�mentaires dont StatusBar & ToolTip. Ajouter "-lcomctl32" dans les options du linker.
#include <stdio.h>               // Fonctions de gestion d'entr�e / sortie (clavier / �cran).

// Identifiants uniques pour chaque contr�le.
#define ID_EDIT 100              // Champ texte.
#define ID_OPEN 101              // El�ment "Ouvrir" du menu.
#define ID_SAVEAS 102            // El�ment "Enregistrer sous" du menu.
#define ID_QUIT 103              // El�ment "Quitter" du menu.
#define ID_FONTCOLOR 104         // El�ment "Couleur de police" du menu.
#define ID_BGCOLOR 105           // El�ment "Couleur de fond" du menu.
#define ID_ASSOC 106             // El�ment "Associer les .nfo � ce programme" du menu.
#define ID_ABOUT 107             // El�ment "A propos" du menu.
#define ID_STATUS 108            // Barre d'�tat.
#define ID_FAV 1001              // Favoris.

// Variables globales.
  COLORREF BgColor, FColor;                 // Couleurs de fond & de police.
  HMENU hMenu, hSubMenu1, hSubMenu2;        // Handle des menus "Fichier", "Options", "A propos".
  int increment=0;                          // Valeur ajout�e � ID_FAV pour que chaque favoris ait un Id unique.
  char IniPath[MAX_PATH];                   // Chemin du fichier INI.

  HWND Mainhwnd, hWnd, hwndStatus, E_hWnd;  // Handle de la fen�tre principale, Handle de la fen�tre, de la barre d'�tat et du champ texte.

// D�claration de la proc�dure de gestion de la fen�tre.
LRESULT CALLBACK MainProc(HWND Dlg,UINT message,WPARAM wParam,LPARAM lParam);

// D�claration des autres proc�dures.
void AfficherFavoris(LPTSTR Chemin);
void CreerToolTip(HWND hwnd, HINSTANCE hInst, LPTSTR texte);
void ChoisirCouleur(INT id);
void OuvrirFichier(LPTSTR FileName);
bool SauverFichier(LPTSTR FileName);
void ChoisirOuvrir();
void ChoisirSauver();
void Registre(char* chemin, char* valeur);

/******************************************************************************\
*                               WINMAIN                                        *
\******************************************************************************/
int WINAPI
WinMain (HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow)
{

  InitCommonControls();                                           // Chargement de la dll.

  GetWindowsDirectory(IniPath, MAX_PATH);                         // R�cup�ration du chemin du dossier "windows".
  strcat(IniPath, "\\codeme2.ini");                               // Affectation du chemin du fichier INI � la variable globale.

// D�finition de la classe de fen�tre standard.
   WNDCLASSEX Fenetre;
   Fenetre.cbSize=sizeof(WNDCLASSEX);                             // Taille de la classe.
   Fenetre.style=0;//CS_HREDRAW|CS_VREDRAW;                       // Redessine la fen�tre apr�s changement de taille.
                                                                  // Supprim� pour �viter le scintillement du champ texte.
   Fenetre.lpfnWndProc=MainProc;                                  // Proc�dure de gestion de la fen�tre.
   Fenetre.cbClsExtra=0;
   Fenetre.cbWndExtra=0;
   Fenetre.hInstance=hInst;                                       // Handle de l'Instance de l'application.
   Fenetre.hIcon=LoadIcon(hInst,MAKEINTRESOURCE(500));            // Ic�ne attach� � la fen�tre.
   Fenetre.hCursor=LoadCursor(NULL,IDC_ARROW);                    // Curseur attach� � la fen�tre.
   Fenetre.hbrBackground=(HBRUSH)(COLOR_3DFACE+1);                // Couleur de la fen�tre.
   Fenetre.lpszMenuName=NULL;                                     // Identifie le nom de ressource du menu.
   Fenetre.lpszClassName="Std_Win";                               // Nom de la classe.
   Fenetre.hIconSm=LoadIcon(hInst,MAKEINTRESOURCE(500));          // Ic�ne miniature utilis� par la fen�tre.
   RegisterClassEx(&Fenetre);                                     // Enregistre la classe.

   POINT centre;                                                  // Coordonn�es de la fen�tre au centre de l'�cran.
   centre.x=(GetSystemMetrics(SM_CXSCREEN)-486)/2;                // Largeur de l'�cran - largeur de la fen�tre / 2
   centre.y=(GetSystemMetrics(SM_CYSCREEN)-445)/2;                // Hauteur de l'�cran - hauteur de la fen�tre / 2

// Cr�ation de la fen�tre principale.
   Mainhwnd = CreateWindow(                                       // Apr�s de nombreuses recherches, je n'ai trouv� aucun �quivalent �
           "Std_Win",                                             // Application.Title. J'ai donc essay� de d�cortiquer
           "codeme#2",                                            // l'objet TApplication de l'unit� Forms.pas fournie avec Delphi.
           WS_POPUP	| WS_SYSMENU | WS_MINIMIZEBOX,                // J'en ai d�duit la cr�ation d'une fen�tre cach�e utilis�e
           centre.x,                                              // seulement pour sp�cifier le titre de l'application
           centre.y,                                              // qui apparait dans la barre des t�ches.
           0,                                                     // Et une fen�tre fille contenant l'interface de l'application.
           0,
           HWND_DESKTOP,
           NULL,
           hInst,
           NULL
           );


// Cr�ation de la fen�tre.
   hWnd=CreateWindow(                                              // Ou CreateWindowEx pour acc�der � des styles suppl�mentaires.
                                                                   // Inutile ici car cr�ation d'une fen�tre standard.
      "Std_Win",                                                   // Nom de la classe appell�e.
      "Codeme#2 petit �diteur de nfo",                             // Nom de la fen�tre. Apparait dans la barre de titre.
      WS_OVERLAPPEDWINDOW | WS_VISIBLE,                            // Styles de la fen�tre. Utilisation d'une bordure classique.
      centre.x,                                                    // Position horizontale de la fen�tre centr�e sur l'�cran.
      centre.y,                                                    // Position verticale de la fen�tre centr�e sur l'�cran.
      486,                                                         // Largeur de la fen�tre.
      445,                                                         // Hauteur de la fen�tre.
      Mainhwnd,                                                    // Handle de la fen�tre parent.
      NULL,                                                        // Handle du menu attach� � la fen�tre.
      hInst,                                                       // Handle de l'Instance de l'application.
      NULL
   );

// Cr�ation de la zone de texte.
   E_hWnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,                                            // Bordure du contr�le.
      "EDIT",                                                      // Nom de la classe utilis�e pour cr�er le contr�le.
      "",                                                          // Texte apparaissant dans(ou sur) le contr�le.
      WS_CHILD | WS_VISIBLE |                                      // Styles du contr�le. Enfant de la fen�tre. Visible.
      WS_VSCROLL | ES_MULTILINE | ES_AUTOHSCROLL,                  // Barre de d�filement vertical. Multiligne. Pas de retour � la ligne.
      0, 0,                                                        // Position du contr�le dans la fen�tre.
      0, 0,                                                        // Taille du contr�le.
      hWnd,                                                        // Handle de la fen�tre.
      (HMENU) ID_EDIT,                                             // Identifiant unique du contr�le.
      hInst,                                                       // Handle de l'Instance de l'application.
      NULL
   );


// Cr�ation de la barre d'�tat.
    hwndStatus = CreateWindow(
        STATUSCLASSNAME,                                           // Nom de la classe utilis�e pour cr�er le contr�le.
        "",                                                        // Texte apparaissant dans(ou sur) le contr�le.
        SBARS_SIZEGRIP | WS_CHILD | WS_VISIBLE,                    // Styles du contr�le. Triangle de redimensionnement de la fen�tre.
        0, 0, 0, 0,                                                // Position & taille du contr�le.
        hWnd,                                                      // Handle de la fen�tre.
        (HMENU) ID_STATUS,                                         // Identifiant unique du contr�le.
        hInst,                                                     // Handle de l'Instance de l'application.
        NULL);

// Cr�ation du menu.
    hMenu=CreateMenu();                                            // Repr�sente la barre de menu dans laquelle on ajoute des �l�ments.
        hSubMenu1 = CreatePopupMenu();                             // Ajout de chaque �l�ment du menu surgissant contenu dans "Fichier".
        AppendMenu(hSubMenu1, MF_STRING, ID_OPEN, "Ouvrir");
        AppendMenu(hSubMenu1, MF_SEPARATOR, 2, NULL);
        AppendMenu(hSubMenu1, MF_STRING, ID_SAVEAS, "Enregistrer sous");
        AppendMenu(hSubMenu1, MF_STRING, ID_QUIT, "Quitter");
        AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu1, "Fichier");
                                                                   // Ajout du sous menu "Fichier" au menu principal.

        hSubMenu2 = CreatePopupMenu();                             // Ajout de chaque �l�ment du menu surgissant contenu dans "Options".
        AppendMenu(hSubMenu2, MF_STRING, ID_FONTCOLOR, "Couleur de police");
        AppendMenu(hSubMenu2, MF_STRING, ID_BGCOLOR, "Couleur de fond");
        AppendMenu(hSubMenu2, MF_STRING, ID_ASSOC, "Associer les .nfo � ce programme");
        AppendMenu(hMenu, MF_STRING | MF_POPUP, (UINT)hSubMenu2, "Options");
                                                                   // Ajout du sous menu "Options" au menu principal.

        AppendMenu(hMenu, MF_STRING, ID_ABOUT, "A propos");        // Ajout du sous menu "A propos" au menu principal.

        SetMenu(hWnd, hMenu);                                      // Affecte le menu pr�c�demment cr�� � la fen�tre.

// Lecture des favoris dans le fichier INI.
        char temp1[256],temp2[256];
        int j;
        for (j=4;j>0;j--) {                                        // Nombre de favoris limit� � 4.
            sprintf(temp1,"Fav%i",j);                              // Les 4 cl�s se nomment "Fav1", "Fav2", "Fav3", "Fav4".
            GetPrivateProfileString("Favoris", temp1, "", temp2, 256, IniPath);
                                                                   // R�cup�ration des valeurs de chaque cl� dans la section "Favoris" du fichier INI.
            if (strcmp(temp2,"")) {
               AfficherFavoris(temp2);                             // Affichage des favoris dans le menu.
            }
        }

// Cr�ation d'une police personnalis�e.
      	HFONT hf = CreateFont(16, 6, 0, 0, FW_REGULAR, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
					OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
					FF_SCRIPT, "Verdana");

// Affectation de cette police au contr�le EDIT.
        SendDlgItemMessage(hWnd, ID_EDIT, WM_SETFONT, (WPARAM)hf, TRUE);

// Cr�ation des infobulles pour les contr�les EDIT & STATUSBAR.
        CreerToolTip(E_hWnd, hInst, "Tooltip1: Codeme#2 pour CRFF par clandestino");
        CreerToolTip(hwndStatus, hInst, "Tooltip2: ceci est une status bar");


// Affichage de la fen�tre.
   ShowWindow(Mainhwnd,SW_SHOW);

// Placement du curseur dans le contr�le EDIT.
   SetFocus(E_hWnd);

// Suppression des �l�ments ind�sirables du menu syst�me.
    HMENU hSysMenu=GetSystemMenu(Mainhwnd, false);
    DeleteMenu(hSysMenu, SC_SIZE, MF_BYCOMMAND);                   // Commande Taille.
    DeleteMenu(hSysMenu, SC_MAXIMIZE, MF_BYCOMMAND);               // Commande Agrandir.
    DeleteMenu(hSysMenu, SC_MOVE, MF_BYCOMMAND);                   // Commande D�placer.



// Texte initial dans le contr�le EDIT.
   SetWindowText(E_hWnd,"                                         Codeme#2 pour CRFF\r\n\r\n\r\n"
                        "Ceci est un petit editeur de nfo,\r\n"
                        "cod� sous Dev-C++ 4 par Kharneth\r\n\r\n\r\n"
                        "Les nouveaux points de programmation ici abord�s sont :\r\n\r\n"
                        "Couleurs de texte et de fond\r\n"
                        "Dialogues d\'ouverture, de fermeture, de choix de couleur\r\n"
                        "Ecriture dans la base de registre\r\n"
                        "Ouverture et lecture d'un fichier texte\r\n"
                        "Ecriture dans un fichier (texte) et enregistrement de celui-ci sur le disque dur\r\n"
                        "Tooltips\r\n\r\n"
                        "Happy coding\r\n\r\n"
                        "Clandestino\0");

// R�ception & acheminement des messages.
   MSG msg;
   while(GetMessage(&msg, NULL, 0, 0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }
   return 0;
}

/******************************************************************************\
*                               AFFICHER LES FAVORIS                           *
\******************************************************************************/
void AfficherFavoris(LPTSTR Chemin) {                              // Texte � afficher.
    int i;
    char temp[256];
    if (GetMenuItemCount(hSubMenu1)==4) {                          // S'il y a 4 �l�ments dans le menu(Ouvrir, S�parateur, Enregistrer sous, Quitter),
                                                                   // aucun favoris n'est affich�.
       InsertMenu(hSubMenu1, ID_SAVEAS, MF_SEPARATOR | MF_BYCOMMAND, 3, NULL);
    }                                                              // Donc cr�ation d'un nouveau s�parateur au-dessus de Enregistrer sous.
    for (i=2;i<6;i++) {                                            // Parcours des favoris (du 2�me au 5�me �l�ment).
        GetMenuString(hSubMenu1, i, temp, 256, MF_BYPOSITION);     // R�cup�ration du chemin du favoris.
        if (!strcmp(temp, Chemin)) {                               // S'il existe d�j�,  (strcmp renvoie 0 si les 2 variables sont �gales)
           DeleteMenu(hSubMenu1, i, MF_BYPOSITION);                // Suppression.
        }
    }
    if (GetMenuItemCount(hSubMenu1)<9) {                           // S'il y a moins de 9 �l�ments (les 4 de bases + les 4 favoris),
       InsertMenu(hSubMenu1, 2, MF_STRING | MF_BYPOSITION, ID_FAV+(increment++), Chemin);
    }                                                              // Insertion du nouveau favoris en t�te de liste.
    else {
         DeleteMenu(hSubMenu1, 5, MF_BYPOSITION);                  // Sinon, suppression du dernier favoris &
         InsertMenu(hSubMenu1, 2, MF_STRING | MF_BYPOSITION, ID_FAV+(increment++), Chemin);
    }                                                              // Insertion du nouveau favoris en t�te de liste.
}

/******************************************************************************\
*                               CREER UNE INFOBULLE                            *
\******************************************************************************/
void CreerToolTip(HWND hwnd, HINSTANCE hInst, LPTSTR texte) {      // Handle du contr�le, Instance de l'app, Texte � afficher.
     TOOLINFO ToolTipStruct;
     HWND ToolTipHwnd = CreateWindow(TOOLTIPS_CLASS, NULL,         // Cr�ation du contr�le infobulle.
                            WS_POPUP | WS_EX_TOOLWINDOW | TTS_ALWAYSTIP | WS_BORDER,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            CW_USEDEFAULT, CW_USEDEFAULT,
                            hwnd, NULL, hInst,
                            NULL);

     SendMessage(ToolTipHwnd, TTM_ACTIVATE, TRUE, 0);              // Activation du contr�le infobulle.

     memset(&ToolTipStruct, 0x0, sizeof(ToolTipStruct));           // D�finition des param�tres de l'infobulle.
            ToolTipStruct.cbSize = sizeof(ToolTipStruct);
            ToolTipStruct.uFlags = TTF_SUBCLASS | TTF_IDISHWND;    // Interception des messages de la souris.
            ToolTipStruct.hwnd = hwnd;
            ToolTipStruct.uId = (WPARAM)ToolTipStruct.hwnd;
            ToolTipStruct.lpszText = texte;
            ToolTipStruct.hinst = hInst;
                                                                   // Affectation de la structure de l'infobulle au contr�le pr�c�demment cr��.
     SendMessage(ToolTipHwnd, TTM_ADDTOOL, 0, (LPARAM)&ToolTipStruct);
}

/******************************************************************************\
*                               CHOOSE FONT COLOR                              *
\******************************************************************************/
void ChoisirCouleur(INT id) {                                      // Couleur de fond ou de police.
    COLORREF g_rgbCustom[16] = {0};                                // Initialisation des couleurs personnalis�es.
    CHOOSECOLOR cc = {sizeof(CHOOSECOLOR)};                        // Structure de la bo�te de dialogue de Choix des couleurs.

    cc.Flags = CC_RGBINIT;                                         // D�finition de la Couleur initialement s�lectionn�e.
    cc.hwndOwner = hWnd;
    cc.lpCustColors = g_rgbCustom;                                 // Affectation des couleurs personnalis�es. (OBLIGATOIRE)
    if (id) {                                                      // Couleur initialement s�lectionn�e correspondant �:
       cc.rgbResult = BgColor;                                     // La couleur du Fond en cours.
    }
    else {
         cc.rgbResult = FColor;                                    // La couleur de la Police en cours.
    }
    if (ChooseColor(&cc)) {                                        // Ouverture de la bo�te de dialogue de choix des couleurs.
       if (id) {                                                   // Si une couleur est retourn�e,
        BgColor=cc.rgbResult;                                      // Celle-ci est affect�e au Fond.
       }
       else {
        FColor=cc.rgbResult;                                       // Ou � la Police.
       }
       InvalidateRect(hWnd,0,0);                                   // Raffraichissement de l'affichage pour prendre en compte les nouvelles couleurs.
    }
}

/******************************************************************************\
*                               CHOISIR OUVRIR FICHIER                         *
\******************************************************************************/
void ChoisirOuvrir() {
    OPENFILENAME ofn;                                              // Structure de la bo�te de dialogue d'Ouverture de fichier.
    char szFileName[MAX_PATH] = "";                                // Chemin du fichier � ouvrir.

    ZeroMemory(&ofn, sizeof(ofn));                                 // Initialisation de la structure. (OBLIGATOIRE)

    ofn.lStructSize = sizeof(ofn);                                 // Taille de la structure.
    ofn.hwndOwner = hWnd;                                          // Handle de la fen�tre.
    ofn.lpstrFilter = "Fichiers nfo \0*.nfo\0";                    // Information sur les types de fichier � afficher.
    ofn.lpstrFile = szFileName;                                    // Fichier initialement s�lectionn�.
    ofn.nMaxFile = MAX_PATH;                                       // Taille maximale du chemin du fichier.
    ofn.lpstrDefExt = "nfo";                                       // Filtre sur les extensions autoris�es.

    if (GetOpenFileName(&ofn)) {                                   // Ouverture de la bo�te de dialogue.
       OuvrirFichier(ofn.lpstrFile);                               // Ouverture & lecture du fichier retourn�.
    }
}

/******************************************************************************\
*                               CHOISIR SAUVER FICHIER                         *
\******************************************************************************/
void ChoisirSauver() {
    OPENFILENAME ofn;                                              // Structure de la bo�te de dialogue d'Enregistrement de fichier.
    char szFileName[MAX_PATH] = "";                                // Chemin du fichier � sauvegarder.

    ZeroMemory(&ofn, sizeof(ofn));                                 // Initialisation de la structure.

    ofn.lStructSize = sizeof(ofn);                                 // Taille de la structure.
    ofn.hwndOwner = hWnd;                                          // Handle de la fen�tre.
    ofn.lpstrFilter = "Fichiers nfo \0*.nfo\0";                    // Information sur les types de fichier � afficher.
    ofn.lpstrFile = szFileName;                                    // Fichier initialement s�lectionn�.
    ofn.nMaxFile = MAX_PATH;                                       // Taille maximale du chemin du fichier.
    ofn.lpstrDefExt = "nfo";                                       // Filtre sur les extensions autoris�es.

    if (GetSaveFileName(&ofn)) {                                   // Ouverture de la bo�te de dialogue d'Enregistrement de fichier.
       SauverFichier(ofn.lpstrFile);                               // Sauvegarde du fichier retourn�.
    }
}

/******************************************************************************\
*                               OUVRIR FICHIER                                 *
\******************************************************************************/
void OuvrirFichier(LPTSTR FileName) {                              // Chemin du fichier � ouvrir.
    HANDLE hFile;                                                  // Handle du fichier ouvert.
                                                                   // Ouverture du fichier en Lecture.
    hFile = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, NULL,OPEN_EXISTING, 0, NULL);

    if(hFile != INVALID_HANDLE_VALUE) {

        DWORD dwFileSize;
        dwFileSize = GetFileSize(hFile, NULL);                     // Taille du fichier ouvert.
        if(dwFileSize != 0xFFFFFFFF){

            LPSTR pszFileText;                                     // Texte contenu dans le fichier.
            pszFileText = (LPSTR)GlobalAlloc(GMEM_FIXED, dwFileSize + 1);
            if(pszFileText != NULL) {                              // Allocation de la m�moire.

                DWORD dwRead;                                      // Lecture du fichier.
                if(ReadFile(hFile, pszFileText, dwFileSize, &dwRead, NULL)) {
                                                                   // Affichage du texte dans le contr�le EDIT.
                    SetWindowText(GetDlgItem(hWnd,ID_EDIT), pszFileText);
                                                                   // Affichage du chemin du fichier dans la barre de status.
                    SendMessage(GetDlgItem(hWnd,ID_STATUS),SB_SETTEXT,0,(LPARAM)TEXT(FileName));
                                                                   // Cr�ation de la police Terminal. Hauteur � -12 pour avoir une taille de 9. (Merci DELPHI!)
    	            HFONT hf = CreateFont(-12, 0, 0, 0, 0, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
					                OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
					                DEFAULT_PITCH | FF_DONTCARE, "Terminal");
                                                                   // Affectation da la police au contr�le EDIT.
                    SendDlgItemMessage(hWnd, ID_EDIT, WM_SETFONT, (WPARAM)hf, TRUE);
                }
                GlobalFree(pszFileText);                           // Lib�ration de la m�moire.
            }
        }
        CloseHandle(hFile);                                        // Fermeture du Handle du fichier.
    }
    AfficherFavoris(FileName);                                     // Afficher le chemin du fichier ouvert dans les favoris.
}

/******************************************************************************\
*                               ENREGISTRER FICHIER                            *
\******************************************************************************/
bool SauverFichier(LPTSTR FileName) {                              // Chemin du fichier � sauvegarder.
    BOOL bSuccess = FALSE;
    HANDLE hFile;
    LPDWORD lpNumberOfBytesWritten;
                                                                   // Ouverture en �criture ou cr�ation du fichier.
    hFile = CreateFile(FileName, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL);
    if(hFile != INVALID_HANDLE_VALUE)
    {
        DWORD dwFileSize;                                          // Taille du texte � sauvegarder.
        dwFileSize = GetWindowTextLength(GetDlgItem(hWnd,ID_EDIT));// Provenant du contr�le EDIT.
        if(dwFileSize != 0xFFFFFFFF)
        {
            LPSTR pszFileText;
            pszFileText = (LPSTR)GlobalAlloc(GMEM_FIXED, dwFileSize+1 );
            if (pszFileText != NULL)
            {                                                      // R�cup�ration du texte.
               if (GetWindowText(GetDlgItem(hWnd,ID_EDIT), pszFileText, GetWindowTextLength(GetDlgItem(hWnd,ID_EDIT))))
               {                                                   // Ecriture du texte dans le fichier.
                  WriteFile(hFile, pszFileText, dwFileSize, lpNumberOfBytesWritten, NULL);
                  bSuccess=true;
               }
            GlobalFree(pszFileText);
            }
        }
        CloseHandle(hFile);
    }
    return bSuccess;
}

/******************************************************************************\
*                         Ecriture dans la base de registre                    *
\******************************************************************************/
void Registre(char* chemin, char* valeur) {
     HKEY result;                                                  // Handle de la clef ouverte.
     RegCreateKeyEx(HKEY_LOCAL_MACHINE, chemin, 0, NULL, REG_OPTION_NON_VOLATILE,
                    KEY_ALL_ACCESS, NULL, &result, 0);             // Ouverture de la clef ou cr�ation si abscente.
     RegSetValueEx(result, NULL, 0, REG_SZ, (CONST BYTE*)valeur, strlen(valeur)+1);
                                                                   // Ecriture de la valeur.
     RegCloseKey(result);                                          // Fermeture de la clef.
}

/******************************************************************************\
*                             MAINPROC Gestion des messages                    *
\******************************************************************************/
LRESULT CALLBACK MainProc(HWND hWnd, UINT mes, WPARAM wParam, LPARAM lParam)
{
   HDC hDC;
   PAINTSTRUCT paintst;
   RECT rcClient, stClient;
   int j;
   char temp1[256], temp2[256];
   switch (mes)
   {
   case WM_CREATE:                                                 // Cr�ation de la fen�tre.
        BgColor=RGB(255,255,255);                                     // Couleur du fond: Blanc.
        FColor=RGB(0,0,0);                                            // Couleur de la police: Noir.
   return 0;
   case WM_CLOSE:                                                  // Fermeture de la fen�tre.
        for (j=0;j<GetMenuItemCount(hSubMenu1)-5;j++) {               // Enregistrement des favoris dans le fichier INI.
            sprintf(temp1,"Fav%i",j+1);
            GetMenuString(hSubMenu1, j+2, temp2, 256, MF_BYPOSITION);
            WritePrivateProfileString("Favoris", temp1, temp2, IniPath);
        }
        DestroyWindow(hWnd);                                          // Destruction de la fen�tre.
   return 0;
   case WM_SYSCOMMAND:                                             // Interception des commandes du menu syst�me.
        switch (wParam & 0xFFF0) {
               case SC_MINIMIZE:                                      // Lorsqu'une fen�tre fille est minimis�e, elle reste dans le coin inf�rieur gauche
                    ShowWindow(Mainhwnd, SW_MINIMIZE);                // de la fen�tre principale. Pour �viter �a, la fen�tre principale est minimis�e
               return 0;                                              // � la place.
               default:
                      return DefWindowProc(hWnd,mes,wParam,lParam);
        }
   break;
   case WM_SIZE:                                                   // Changement de taille de la fen�tre.
        GetClientRect(hWnd, &rcClient);                               // R�cup�ration des dimensions de la fen�tre.
        GetClientRect(GetDlgItem(hWnd,ID_STATUS), &stClient);         // R�cup�ration des dimensions de la Barre d'�tat.
        SendMessage(GetDlgItem(hWnd,ID_STATUS),WM_SIZE,0,0);          // Redimensionnement de la barre d'�tat.
        MoveWindow(GetDlgItem(hWnd, ID_EDIT),0,0,                     // Redimensionnement du contr�le EDIT.
                   rcClient.right-rcClient.left,                      // Par rapport � la taille de la fen�tre.
                   (rcClient.bottom-rcClient.top)-stClient.bottom,true);
   return 0;
   case WM_COMMAND:                                                // Actions de l'utilisateur.
        switch (LOWORD(wParam))                                    // ID des �l�ments de menu ou des contr�les actionn�s.
        {
        case ID_FONTCOLOR:                                            // Choix de la couleur de police.
             ChoisirCouleur(0);
        break;
        case ID_BGCOLOR:                                              // Choix de la couleur du fond.
             ChoisirCouleur(1);
        break;
        case ID_ASSOC:                                                // Association de l'extention nfo au programme.
             char appPath[MAX_PATH];                                  // Chemin du programme.
             GetModuleFileName(NULL, appPath, MAX_PATH);              // R�cup�ration du chemin du programme.
             Registre("SOFTWARE\\Classes\\.nfo", "nfo_file");         // Association de l'extension nfo � un programme.
             Registre("SOFTWARE\\Classes\\nfo_file\\Shell\\codeme2", "Ouvrir avec CodeMe#2");
                                                                      // Texte apparaissant dans le menu contextuel lors d'un click droit.
             Registre("SOFTWARE\\Classes\\nfo_file\\Shell\\codeme2\\command", appPath);
                                                                      // Inscription du programme.
             MessageBox(hWnd, "La clef HKEY_LOCAL_MACHINE\\SOFTWARE\\CLASSES\\nfo_file\\shell\\\n"
                              "a �t� cr��e dans votre base de registre pour associer les .nfo � cette application...\n"
                              "Sur les OS anciens il faut rebooter manuellement pour que les changements prennent effet\n"
                              "Ce programme ne produit pas le reboot de votre machine", "Avertissement", MB_OK);
        break;
        case ID_ABOUT:                                                // A propos.
             MessageBox(hWnd,"codeme#2 : un simple �diteur nfo","k�sako",MB_OK);
        break;
        case ID_OPEN:                                                 // Ouvrir un fichier.
             ChoisirOuvrir();
             SetFocus(GetDlgItem(hWnd, ID_EDIT));                     // Placement du curseur dans le contr�le EDIT.
        break;
        case ID_SAVEAS:                                               // Sauvegarder un fichier.
             ChoisirSauver();
        break;
        case ID_QUIT:                                                 // Quitter le programme.
             SendMessage(hWnd,WM_CLOSE,0,0);
        break;
        default:
             if (LOWORD(wParam)>1000) {                               // Seuls les favoris ont un ID sup�rieur � 1000
             GetMenuString(hSubMenu1, LOWORD(wParam), temp2, 256, MF_BYCOMMAND);
             OuvrirFichier(temp2);                                    // Ouverture du fichier correspondant au favori.
             }
        break;
        }
        return 0;
   case WM_CTLCOLOREDIT:                                           // Affichage du contr�le EDIT.
        SetTextColor((HDC)wParam, FColor);                            // Affectation de la couleur du texte.
        SetBkColor((HDC)wParam,BgColor);                              // Affectation de la couleur de fond du texte. (identique � la couleur de fond du contr�le EDIT)
        return (LRESULT)CreateSolidBrush(BgColor);;                   // Affectation de la couleur de fond du contr�le EDIT.
   case WM_PAINT:                                                  // Affichage de la fen�tre.
        hDC=BeginPaint(hWnd,&paintst);
        EndPaint(hWnd,&paintst);
        return 0;
   case WM_DESTROY:                                                // Destruction de la fen�tre.
        PostQuitMessage(0);                                           // Fermeture de l'application.
        return 0;
   default:
        return DefWindowProc(hWnd, mes, wParam, lParam);           // Traitement des autres messages.
   }
}


/******************************************************************************\
*                              FIN DU PROGRAMME                                *
*                     CodeMe#2 propos� par Clandestino                         *
*                            cod� par Kharneth                                 *
*                                                                              *
*  kharneth@free.fr        Aides &                                             *
*                       Didacticiels sur http://www.developpez.com             *
*                                        http://www.cppfrance.com              *
*                                        http://www.foosyerdoos.fsnet.co.uk/   *
\******************************************************************************/

