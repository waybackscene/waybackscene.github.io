
NS_ActualWrite=document.write;
document.ignore = new Object();
