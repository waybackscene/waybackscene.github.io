#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  char OriginalSerial[] = "Pbatenghyngvbaf! :)";
  char Serial[20];
  int i;
  
  
  puts("Trouveur de serial - U4N1 - code par mastermatt29\n\n");
  
  for(i=0; i<strlen(OriginalSerial); ++i)
  {
     if((OriginalSerial[i] < 0x41) || ((OriginalSerial[i] > 0x41+0x1A) && (OriginalSerial[i] < 0x41+0x1A+0x6)) || (OriginalSerial[i] > (0x41+0x1A+0x6+0x1A)))
     {
        // Rien � faire, le caract�re a tr�s bien pu ne subir aucune transformation
        Serial[i] = OriginalSerial[i];
     }
     else
     {
          if(OriginalSerial[i] >= 0x61) // A cause du ADD EDX,61 + un nombre inf�rieur � 1A dans la deuxieme routine ou le caractere est modifi�
          {
               Serial[i] = OriginalSerial[i]-0x61; // On r�cup�re le reste de la division euclidienne
               Serial[i] += 0x54;
               
               while(Serial[i]<0x41+0x1A+0x06)   // Etant donn� qu'on a gard� que le reste de la division par 1A, on peut rajouter 1A autant de fois qu'on le souhaite
               {                                 // On rajoute jusqu'� ce qu'il appartienne � l'intervalle pour lequel l'algorithme marche
                  Serial[i] += 0x1A;
               }
          }
          else // Le caract�re est pass� dans la premi�re routine qui modifie le caract�re
          {
               Serial[i] = OriginalSerial[i]-0x41;
               Serial[i] += 0x34;
               
               if(Serial[i]<0x41) // Etant donn� qu'on a gard� que le reste de la division par 1A, on peut rajouter 1A autant de fois qu'on le souhaite
               {
                  Serial[i] += 0x1A;
               } 
          }
     }
  }
  Serial[strlen(OriginalSerial)] = 0;
  
  printf("Le serial original est : \"%s\"", Serial);       
  getch();
  return 0;
}
