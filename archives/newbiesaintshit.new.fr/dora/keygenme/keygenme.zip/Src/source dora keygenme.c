#include <stdio.h>

int main(int argc, char *argv[])
{

char buf[50];
char name[50];
char serial[50];
char string[10]="D0r4";
char final[100]="";
int var=0, i, sum=0;    // d�claration des variables

textcolor(2);  // colore le texte en vert

    printf ("\nDora L'exploratrice Keygenme coded by haiklr, inspired by ++meat\n");
    printf ("========================================\n\n");

    printf("Hello my friend ! What is your name ?\n");
    printf ("--- ");
    scanf("%s", &name);    // enregistre la saisie clavier
    printf ("\n");

       if (strlen(name) < 6)
       {
       printf("String XS ! Trop petit : name > 5 !\n\n");
           system("pause"); // test la longueur du nom
           return 0;
       }

       if (strlen(name) > 49)
       {
       printf("String XXL c'est trop grand pour moi, je nage dedans : name < 50 !\n\n");
           system("pause");   // test la longueur du nom
           return 0;
       }

       printf("And your serial please ?\n");
       printf ("--- ");
       scanf("%s", &serial);  // enregistre la saisie clavier
       printf ("\n");

       for (i=0;i<strlen(name);i++)   // somme des caract�res du nom
       {
       sum += name[i];
       }

       var = ((sum+0x4d2b48) << name[0])^0x6969;   // effectue quelques op�rations

       sprintf(buf, "%lu", var);        // transforme la valeur de var en une cha�ne de caract�res
       sprintf(final,"%s-%s", string, buf);   // concat�nation


       if (!strcmp(serial, final))       // si serial entr� et serial g�n�r� �gaux
       {
       printf("We did it ! C'est gagne !\n\n");
       }

       if (strcmp(serial, final))     // si serial entr� et serial g�n�r� diff�rents
       {
       printf("Oh mince !\n\n");
       }

       system("pause");
       return 0;
}
