#include <stdio.h>

int main(int argc, char *argv[])
{

char name[50];
char final[100]="";
int var=0, i, sum=0;       // d�claration des variables

    printf ("\nKeygen - Dora L'exploratrice Keygenme -\n");
    printf ("========================================\n\n");

    printf("Hello my friend ! What is your name ?\n");
    printf ("--- ");
    scanf("%s", &name);
    printf ("\n");

       if (strlen(name) < 6)
       {
       printf("String XS ! Trop petit : name > 5 !\n\n");
           system("pause");
           return 0;
       }

       if (strlen(name) > 49)
       {
       printf("String XXL c'est trop grand pour moi, je nage dedans : name < 50 !\n\n");
           system("pause");
           return 0;
       }   // test sur la longueur du serial


    for (i=0;i<strlen(name);i++)
    {
    sum += name[i];          // somme d'un caract�re sur deux du nom
    }

    var = ((sum+0x4d2b48) << name[0])^0x6969;  // effectue les op�rations

    sprintf(final, "D0r4-%d", var);
    printf ("SERIAL : %s\n\n", final);      // affiche le serial g�n�r�

    system("pause");
    return 0;
}
