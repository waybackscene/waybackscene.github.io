using System;

namespace DoraWasAPunk
{
	class MainClass
	{
		public static void Main(string[] args)
		{
    		string name;
    		int sum=0;
    		int var;

			Console.Write("\nKeygen - Dora L'exploratrice Keygenme -\n");
			Console.Write("========================================\n\n");

			Console.Write("Hello my friend ! What is your name ?\n");
			Console.Write("--- ");
			name = Console.ReadLine();

			if (name.Length < 6)
			{
				Console.Write("\nString XS ! Trop petit : name > 5 !\n\n");
				Console.Read();
				return;
			}
			else if (name.Length > 49)
			{
				Console.Write("\nString XXL c'est trop grand pour moi, je nage dedans : name < 50 !\n\n");
				Console.Read();
				return;
			}
			
			for (int i = 0; i < name.Length; i++)
			{
				sum += name[i];
			}

			var = ((sum+0x4d2b48) << name[0])^0x6969;

			Console.Write("\nSERIAL : D0r4-" + var + "\n");
			Console.Read();
			return;
		}
	}
}
