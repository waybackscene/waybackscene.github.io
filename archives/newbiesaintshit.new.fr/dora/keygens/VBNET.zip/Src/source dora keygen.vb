Imports System
Imports Microsoft.VisualBasic

Module Main
	Sub Main()

		Dim name As String
		Dim sum As Integer = 0
		Dim var As Integer
		Dim i As Integer = 0

		Console.WriteLine("Keygen - Dora L'exploratrice Keygenme -")
		Console.WriteLine("========================================")
		Console.WriteLine()

		Console.Write("Hello my friend ! What is your name ? ")
		name = Console.ReadLine()

		If name.Length < 6 Then
			Console.WriteLine("name > 5 ! Allez ouste !")
			Return
		ElseIf name.Length > 49 Then
			Console.WriteLine("name < 50 ! Tsss !")
			Return
		End If

		For i = 0 To name.Length-1
			sum = sum + Asc(name.Chars(i))
		Next

		var = ((sum + &H4D2B48) << Asc(name.Chars(0))) xor &H6969

		Console.WriteLine("SERIAL : D0r4-" & var)
		Console.Read()

	End Sub
End Module
