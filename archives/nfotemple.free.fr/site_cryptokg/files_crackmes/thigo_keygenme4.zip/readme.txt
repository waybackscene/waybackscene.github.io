			--== Keygenme 4 by Thigo ==--


Another crackme (working this time, sorry for the buggy one (3rd)).
All (if i can say that...) you have to do is to keygen it.
It's not for newbies but not so hard. I'd say it's level 5 on crackmes website scale :)
roy says 4 but u know him... ;D
Good Luck !