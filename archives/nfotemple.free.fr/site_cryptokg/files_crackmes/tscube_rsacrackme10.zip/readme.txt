This is my RSA crackme : find a correct serial and you'll be able
to say you are a RSA24 cracker ;)

This was coded to test my Bignum library... it works but it's 
toooo slow.

    ________     _______     _______
   /__   __/\   /  ____/\   /  ____/\
   \_/  /\_\/  /  /\___\/  /  /\___\/
    /  / /    /  /_/_     /  / / 
   /  / /    /____  /\   /  / /
  /  / /     \___/ / /  /  / /
 /  / /     ____/ / /  /  /_/_
/  / /     /_____/ /  /______/\
\__\/      \_____\/   \______\/  01/01/2000
               

thx to : egis,ghiribizzo,lucifer48,Acid_Burn