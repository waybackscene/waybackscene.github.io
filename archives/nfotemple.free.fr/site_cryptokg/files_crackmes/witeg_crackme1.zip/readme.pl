                     CrackMe 1
                   -=*********=-

Opis:
*****
Witam w moim pierwszym crackme ... stalo sie :)
Twoim celem jest znalezienie poprawnego seriala dla
wlasnego nicka a potem napisanie keygena. Oczywiscie
procka generujaca jest calkowicie odwracalna.

Crackme nie zawiera zadnych sztuczek skierowanych
przeciw debuggerom, dumperom (heh, nawet nie jest
spakowane), disasemblerom, ani sprawdzen sum kontrolnych.

Zrobilem wszystko co mozna zeby uwidocznic kod, poniewaz
wierze w Twoja inteligencje i mam nadzieje, ze nie
osmieszysz sie patchem lub loaderem ;)
Brute-force takze nie jest tu wlasciwa droga.

Jak juz zlamiesz ten programik przyslij mi rozwiazanie
albo zlap mnie na IRCu. Jesli wyjasnisz co i jak
poinformuje o Twym wyczynie na mojej stronce.

Milego debugowania.
Pozdrowienia dla wszystkich ktorzy nie pytaja o cracki :)

PS.
Tego crackmesa nie polecalbym raczej newbies...

WiteG
WiteG@poczta.fm
www.witeg.cad.pl