                     CrackMe 2
                   -=*********=-

Opis:
*****
Witam w moim drugim crackme. Tym razem cos naprawde
latwego.

Twoim celem jest wygenerowanie poprawnego keyfile'a dla
wlasnego nicka a potem napisanie keygena. Wszystko co
potrzebne jest odwracalne.

Crackme nie zawiera sztuczek anty-d, crc-checkow, nie
jest tez spakowane. Zrobilem wszystko co mozna zeby
uwidocznic kod, poniewaz wierze w Twoja inteligencje i
mam nadzieje, ze nie osmieszysz sie patchem lub
loaderem.

Jak juz zlamiesz ten programik przyslij mi rozwiazanie
albo zlap mnie na IRCu. Jesli wyjasnisz co i jak
poinformuje o Twym wyczynie na mojej stronce.

Milego debugowania.
Pozdrowienia dla wszystkich polskich crackerow.

WiteG
WiteG@poczta.fm
www.witeg.cad.pl