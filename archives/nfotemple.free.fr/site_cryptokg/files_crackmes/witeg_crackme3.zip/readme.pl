                     CrackMe 3
                   -=*********=-

Opis:
*****
Witam w moim trzecim crackme, tym razem na poziomie medium
- nie jest zbyt trudne (tym bardziej ze to wersja LITE).

Twoim celem jest wygenerowanie poprawnego keyfile'a dla
wlasnego nicka a potem napisanie keygena. Patche i loadery 
nie dozwolone.

Jak juz zlamiesz ten programik przyslij mi rozwiazanie
(WiteG@poczta.fm) albo zlap mnie na IRCu. Jesli wyjasnisz
co i jak poinformuje o Twym wyczynie na mojej stronce.
Milej zabawy.

WiteG//xtreeme
www.witeg.prv.pl