                     CrackMe 5
                   -=*********=-

Opis:
*****
Witam w moim piatym crackme.

Twoim celem jest wygenerowanie poprawnego kodu dla wlasnego
nicka a potem napisanie keygena. Jak Ci sie bedzie chcialo
mozesz skrobnac tutka. Patche i loadery nie dozwolone.

Jak juz zlamiesz ten programik przyslij mi rozwiazanie
(witeg@poczta.fm) albo zlap mnie na IRCu. Jesli wyjasnisz
co i jak poinformuje o Twym wyczynie na mojej stronce.

WiteG//xtreeme
www.witeg.prv.pl