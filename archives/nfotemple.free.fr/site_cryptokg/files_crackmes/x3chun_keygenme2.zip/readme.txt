x3chun's cryptokg #2

hi all!

this little keygenme is very very easy to solve
i coded it for 10 minutes by vc++
if u are good reverser, can destroy under 10 minutes :)

x3chun@korea.com

x3chun//tkm!