/*  @(#)tstcrc32.c	1.1  3/16/95  08:20:02  */
/*
   Create test cases for "crc32" program
   efg, 3/12/95

   This program creates 256 files that contain all 256 bytes
   0x00 .. 0xFF.  These files would all have the same checksum,
   but have different CRC-32s.
*/

#include <stdio.h>        /* sprintf, fwrite */
#include <stdlib.h>       /* NULL */
#include "legible.h"      /* readable/portable style */

#define BUFFER_SIZE          256
#define NUMBER_OF_TEST_FILES 256

/**  main  ************************************************************/

INTEGER main()
{
  FILE     *binary;
  BYTE      buffer[BUFFER_SIZE];
  WORD16    filecount;
  CHARACTER filename[25];
  WORD16    i;
  BYTE      save;

  FOR i=0; i < BUFFER_SIZE; i++
  BEGIN
    buffer[i] = (BYTE) i
  END

  FOR filecount=0; filecount < NUMBER_OF_TEST_FILES; filecount++
  BEGIN
    sprintf (filename, "DATA%03d.BIN", filecount);
    printf ("%s\n", filename);

    IF (binary = fopen(filename,"wb")) IS NULL
    THEN
      printf ("Error in creating file %s\n", filename);
      exit (1)
    END

    fwrite (buffer, BUFFER_SIZE, 1, binary);
    fclose (binary);

    save = buffer[0];
    FOR i=1; i < BUFFER_SIZE; i++
    BEGIN
      buffer[i-1] = buffer[i]
    END
    buffer[BUFFER_SIZE-1] = save;

  END

  return 0;
}
