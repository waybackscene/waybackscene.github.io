Checksum32 v 1.3 - for Win9x/NT4+
Right-click checksum utility (copyright) Greg Lorriman 1999

IMPORTANT: uninstall previous version and reboot before installing.
For Win98sp1 install problems update to sp2.
Uninstall from control panel.
Note : Context menu entry is now "CRC32"

Other goodies at http://www.lorriman.demon.co.uk



Installation : run the executable in the zip file. Make sure that the windows 
control panel or control panel applets are NOT running or installation will fail.

Quick guide :

Right-click file(s) or folder(s) in explorer and choose "CRC32".
If a 00000000 value is returned then there will have been an error
such as a file with a an exclusive lock (ie. the swap file). 
This utility doesn't appear until it has finished processing the files;
the explorer window may appear to lock

Note : Explorer may be a tradmark of Microsoft(tm)

