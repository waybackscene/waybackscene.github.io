First of all, CheckMe is not a crackme ;)
As i'm always affraid for my files.. i decided to write this little projet.
The "checkme" program allow you to compute file's crc in a given directory.
The "verifyme" program makes a quick verification (there's no gui).

Lucifer48 [PC]

PS: The checkme.reg will add shell extensions. Edit it to change the program location
(the default is "C:\Program Files\checkme.exe" and "C:\Program Files\verifyme.exe")
Whith these extensions, checkme is really easy and fast to use !
[remark: after entering the registry info, you must close your windows session (or reboot) to apply changes]

Note: Report bugs, comments.. at lucifer48@yahoo.com

What's new ?
------------
v1.50 - 08/21/2001
 * SHA-384/512 added
 * VerifyMe improoved : you can now have multiple checkme files in the same directory,
   and can also change the "checkme" name
v1.40 - 08/18/2001
 * SHA-256 added
 * Computation is now made in a thread
 * Computation time displayed (include: directory browsing + algo + checkme file writing + listbox messages)
v1.30 - 08/16/2001
 * RIPEMD (128 & 160) added
 * Creation date (and time) added inside checkme.xxx files
v1.20 - 08/15/2001
 * MD5 padding bug corrected
 * SHA-1 added
 * Hourglass display ;)
v1.10 - 08/09/2001
 * MD5 added (common directory created)
v1.00 - 08/01/2001
 * First version

TODO
----
 * building a dll (com?)
 * recurse directory option
 * add haval, ...
 * delete all checkme.xxx in one time
 * ...

More to come, if you support me !!!