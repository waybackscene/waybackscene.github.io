    DSS/DSA-Keygenerator (c) 2k by tHE EGOiSTE // TMG

    Introduction
    ------------
    This tool has been coded for  those who're planning to use DSA  signatures
    in their own programs but don't  know how to generate keys which  are safe
    to use. If you are no coder or/and are not at least a little bit  familiar
    with public-key cryptography, this tool  is definately of no use  for you.

    Sorry. Next time I will probably better code some Tetris game. :-))

    1. General stuff
    In  1991  the  Digital Signature  Algorithm(DSA)  has  become the  Digital
    Signature Standard(DSS). DSA is a public-key signature scheme that uses  a
    pair of  transformations to  generate and  verify a  digital value  called
    signature.

    DSA has been  developed by the  US National Security  Agency(NSA) and can 
    -not- be used for encryption or  key distribution. DSA is some variant  of
    the ElGamal signature algorithm and, as defined in the standard, uses  the
    Secure Hash Algorithm(SHA/SHA-1) as one-way hash function.

    2. Parameters
    P = A prime number in range 512 to 1024 bits which must be a multiple of 64
    Q = A 160 bit prime factor of P-1
    G = H^((P-1)/Q) mod P. H is any number < P-1 such that H^((P-1)/Q) mod P > 1
    X = A number < Q
    Y = G^X mod P

    Parameters P, Q, G and  Y are public where Y  is the public key. X  is the
    private key and must be kept secret! To obtain X from Y one needs to solve
    the  Discrete  Logarithm  Problem  which  is  virtually  impossible   for 
    -properly- generated parameters of reasonable size.

    3. Signing a message (M)
    To sign M, carry through the following steps:
    - Generate a -random- number K < Q. NEVER use same K twice or more to sign
      other messages!
    - Compute R = (G^K mod P) mod Q
    - Compute S = (K^-1*(SHA(M) + X*R)) mod Q

    The number pair (R,S) is the signature of M.

    4. Verifying a signature (R,S) of M
    - Compute W = S^-1 mod Q
    - Compute U1 = (SHA(M) * W) mod Q
    - Compute U2 = (R*W) mod Q
    - Compute V = ((G^U1 * Y^U2) mod P) mod Q

    If V == R the signature is verified.

    5. Notes
    The bignumber library used  in this program is  MIRACL 4.43 (c) by  Shamus
    Software Ltd. It can be downloaded incl. Sources in C/CPP and manuals  at:
    http://indigo.ie/~mscott/ Please note that the MIRACL lib is -not- free to
    use in commercial programs. Even  worse, the license fees are  pretty high
    but you  can, of  course, use  any other  bignumber library.  A very  good
    alternative is Freelip (current version 1.1)

    Base60 conversion table (as used by MIRACL):
    0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx

    Base64 conversion table:
    ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/

    Please note that the Base64 format is not supported by MIRACL. I used  own
    routines.  Conversion  starts  at  MSB   and  ends  at  LSB  of   the  hex
    representation of  each number.  This may  be incompatible  with 3rd party
    base64 conversion routines.

    Parameters R  and S  of the  signatures generated  in the  Test Dialog are
    separated by a <space>.

    A small part of the DSA parameter generation uses your passphrase as  seed
    value  for  a  PRNG.  This generator  will  NOT  be  re-initialized during
    runtime. I.e. you  will get different  DSA keys every  time you press  the
    Generate button. This is done on purpose, as it makes abusing this tool to
    recover a  Keypair much  more difficult  (even if  the passphrase  is very
    short).

    Now I wish all of you  good luck implementing this nice and  secure public
    key system in their own programs.
    
    IMPORTANT FINAL NOTE:
    Please never forget that even  the most secure cryptographic algorithm  is
    worthless if  you make  mistakes in  the implementation.  So, if you don't
    know -exactly- what  you're doing, better  use some 3rd  party sourcecodes
    made by people you trust and -never- change the recommended standard(s).
    

    January, 8th 2001
    
    tE! // TMG
  