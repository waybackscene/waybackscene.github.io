/* Copyright (C) 2001 Donald J Bindner.
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 */

var delta = 0x9E3779B9;
var k = new Array;
var r=0;

function add(x, y) {
    /* adds 32bit numbers in arch independent way */
  var lsw = (x & 0xFFFF) + (y & 0xFFFF);
  var msw = (x >>> 16) + (y >>> 16) + (lsw >>> 16);
  return (msw << 16) | (lsw & 0xFFFF);
}

function sub(x, y) {
    /* subtracts 32bit numbers in arch independent way */
  return add( x, -y );
}

function a2l( arr ) {
    /* converts an array of 8 bytes to a long */
    return arr[0] | (arr[1]<<8) | (arr[2]<<16) | (arr[3]<<24);
}

function l2a( l ) {
    /* converts a long to an array of 8 bytes */
    arr = new Array;
    arr[0] = l & 0xFF;
    arr[1] = (l>>>8) & 0xFF;
    arr[2] = (l>>>16) & 0xFF;
    arr[3] = (l>>>24) & 0xFF;
    return arr;
}

function stringToArray( str ) {
    /* converts a string to an array of bytes */
    arr = new Array;

    for( var i = 0; i < str.length; i++ ) {
	arr[i] = str.charCodeAt( i );
    }

    return arr;
}

function arrayToString( arr ) {
    /* converts an array of bytes to a string */
    str = new String;

    for( var i = 0; i < arr.length; i++ ) {
	str += String.fromCharCode( arr[i] );
    }

    return str;
}

function randomArray( n ) {
    /* returns a random array of bytes */
    arr = new Array;

    for( var i = 0; i < n; i++ ) {
	arr[i] = Math.floor( Math.random() * 256 );
    }

    return arr;
}


function tea_setup( key, rounds ) {
    /* sets up the cipher with key and rounds */
    r = rounds;
    k = key;
}

function tea_crypt( arr, flag ) {
    /* encrypts an 8-byte array when flag=0 and decrypts when flag=1 */
    var sum=0;
    var y = a2l( arr.slice(0,4) );
    var z = a2l( arr.slice(4,8) );

    if( flag != 0 ) {	/* decrypt */
	sum = delta * r;
	for( var i = 0; i < r; i++ ) {
	    z = sub( z,
		    add( ((y<<4) ^ (y>>>5)), y ) ^
		    add( sum, k[(sum>>>11) & 3])
		);
	    sum = sub( sum, delta );
	    y = sub( y, 
		    add( ((z<<4) ^ (z>>>5)), z ) ^
		    add( sum, k[sum & 3] )
		);    
	}
    } else {	/* encrypt */
	for( var i = 0; i < r; i++ ) {
	    y = add( y, 
		    add( ((z<<4) ^ (z>>>5)), z ) ^
		    add( sum, k[sum & 3] )
		);    
	    sum = add( sum, delta );
	    z = add( z,
		    add( ((y<<4) ^ (y>>>5)), y ) ^
		    add( sum, k[(sum>>>11) & 3])
		);
	}
    }
    return l2a(y).concat( l2a(z));
}

function tea_encode( arr ) {
    return tea_crypt( arr, 0 );
}

function tea_decode( arr ) {
    return tea_crypt( arr, 1 );
}

function xor( arr1, arr2 ) {
    /* xors two arrays componentwise */
    var arr = new Array;
    for( var i = 0; i < arr1.length; i++ ) arr[i] = arr1[i] ^ arr2[i];
    return arr;
}

function tea_encodeCBC( arr, key ) {
    /* accepts an array of bytes and a key (string)
     * and returns an encrypted array of bytes 
     */

    /* random initial vector */
    var iv = randomArray( 8 );

    var buf = stringToArray( "RandomIV" );
    buf = buf.concat( iv );

    /* initialize TEA with MD5 hash of our key and 32 rounds */
    tea_setup( MD5key(key), 32 );

    /* xor each block with the cipher text from previous round and encode */
    for( var i = 0; i < arr.length - (arr.length%8); i += 8 ) {
	var block = xor( arr.slice(i,i+8), iv );
	iv = tea_encode( block );
	buf = buf.concat( iv );
    }

    /* last block may be a partial block or an extra block */
    var block = arr.slice( arr.length - (arr.length%8), arr.length );
    var plength = 8 - block.length;		/* num padding bytes */
    for( var i = 0; i < plength; i++ ) block = block.concat( plength );

    block = xor( block, iv );
    buf = buf.concat( tea_encode( block ));

    return buf;
}

function tea_decodeCBC( arr, key ) {
    /* accepts an array of bytes and a key (string)
     * and returns an encrypted array of bytes 
     */

    /* random initial vector */
    var iv = arr.slice( 8, 16 );
    var buf = new Array();

    /* initialize TEA with MD5 hash of our key and 32 rounds */
    tea_setup( MD5key(key), 32 );

    /* decrypt each block and xor with the cipher text from previous round */
    for( var i = 16; i < arr.length-8; i += 8 ) {
	var niv = arr.slice(i,i+8);
        var block = tea_decode( niv );
	buf = buf.concat( xor( block, iv ));
	iv = niv;
    }

   /* decrypt last block */
    var block = xor( tea_decode( arr.slice(i,i+8)), iv );
    buf = buf.concat( block.slice( 0, 8-block[7]));

    return buf;
}
