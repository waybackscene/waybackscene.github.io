im32i.lib is a multi-purpose library for TASM5
and has been build from the following Win32 dlls:

kernel32.dll
gdi32.dll
user32.dll
shell32.dll
advapi32.dll
Msvcrt.dll
Comctl32.dll
Comdlg32.dll
winmm.dll

For most Win32 applications this should be enough (?) :-)

wsock32.lib has been build from wsock32.dll Version 4.10.0.1656