I  made  this pack  for  all people  who  still like  Borland's  good old  Turbo
Assembler.

This  package  contains  all  neccessary  tools  to  build  your  first Win32ASM
projects.  tasm32_v5.3_exe.rar   additionally  contains   a  newer   version  of
TASM32.EXE (v5.3). You can  extract this file directly  into the BIN folder  and
overwrite the older (v5.0) version if you like.

In EXAMPLES folder you will find 2 example programs coded for TASM5:

1) mintemplate - A basic Win32 GUI Keygenerator template (Dialog based)
2) contemplate - A console Keygenerator template

Just click on  the MAKE_IT.BAT file  in the corresponding  folder to create  the
executables. Have a look at those .bat  files and the .asm source codes to  find
out more.

--------------------------------------------------------------------------------
Final words:

Well, in my  opinion MASM32 is  for sure the  better Tool for  programming Win32
applications  but  there're still  a  lot of  sourcecodes  for  TASM  available.
Porting sources from  TASM to MASM32  is sometimes a  pain due to  the fact that
TASM allows a very sloppy style of coding... :->

If you are a beginner I recommend you  NOT to start with TASM, but get the  very
nice MASM32v6 package on Hutch's site: http://www.pbq.com.au/home/hutch/masm.htm
which  also  includes the best available Win32ASM tutorials available on the net
written by Iczelion.

Greets,

tE!
