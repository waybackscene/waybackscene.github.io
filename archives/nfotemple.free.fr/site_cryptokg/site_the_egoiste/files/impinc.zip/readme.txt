im32i.lib is a multi-purpose library for TASM5
and has been build from the following Win32 dlls:

kernel32.dll
gdi32.dll
user32.dll
shell32.dll
advapi32.dll
Msvcrt.dll
Comctl32.dll
Comdlg32.dll
winmm.dll

For most Win32 applications this should be enough (?) :-)
