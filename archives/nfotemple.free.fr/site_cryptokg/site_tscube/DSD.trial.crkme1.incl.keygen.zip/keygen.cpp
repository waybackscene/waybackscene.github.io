#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int patch(void);
int level1(void);
int level2(void);
int level3(void);

int main(void)
{
	int choice;

	puts("Keygen for DSD trial crackme by TSCube 18/06/2000");
	puts("1) Patch to enable check buttons");
	puts("2) Level 1");
	puts("3) Level 2");
	puts("4) Level 3\n");
	printf("Choose your destiny : ");
	scanf("%d",&choice);
	getchar();

	switch(choice)
	{
	case 1:
		patch();
		break;
	case 2 :
		level1();
		break;
	case 3 :
		level2();
		break;
	case 4 :
		level3();
		break;
	};

	puts("\n\n<enter> to finish");
	getchar();

	return 0;
}

////////////////////////////////////////////////
/////////////////////////////////////////////////

// This function patches the crackme (packed with UPX) to enable
// the "enable check" menu item : it modifies the byte at memory 
// offset @462241 (or file offset 6183C if you unpack the crackme with procdump)

// Thx to Woody for telling me how to ungray something in a Delphi proggy
// For more infos on "patching a packed proggy", read R!SC tutorials

int patch(void)
{
	int number = 14;
	unsigned int offset[] =
	{
		0x35D,0x35E,0x35F,0x360,0x361,0x362,0x364,0x365,0x366,0x367,
		0x368,0x15CC,0x15CD,0x15CE
	};

	unsigned char patched[] =
	{
		0x90,0xC6,0x05,0x41,0x22,0x46,0x09,0xE9,0xAA,0x79,0x04,0x8D,0x81,0xF9	
	};

	FILE* file = fopen("W-crkm11.exe","rb+");

	if (file==NULL)
	{
		puts("Patch error : I can't open 'W-crkm11.exe' !!!");
		return 1;
	}

	for (int i=0;i<number;i++)
	{
		fseek(file,offset[i],SEEK_SET);
		fputc(patched[i],file);
	}
	
	fclose(file);

	puts("file 'W-crkm11.exe' successfully patched");
	puts("--> Enable check is now enabled");

	return 0;

}

////////////////////////////////////////////////
/////////////////////////////////////////////////

int level1(void)
{
	char name[50];
	char serial[50];


	printf("\nName : ");
	gets(name);

	char buffer[6];
	int magic=0;


	for (unsigned int i=0;i<strlen(name);i++)
	{
		int temp = name[strlen(name)-i-1];
		if (temp<= '9' && temp >= '0') temp = temp - '0';
		else temp=0;
		magic += temp ^ (int) name[i];
	}

	sprintf(buffer,"%05x",magic);
	strcpy(serial,buffer);

	for (i=0;i<strlen(name);i++)
	{
		int temp = name[strlen(name)-i-1];
		if (temp<= '9' && temp >= '0') temp = temp - '0';
		else temp=0;
		magic += temp ^ (int) name[i];
	}

	sprintf(buffer,"%05x",magic);
	strcat(serial,buffer);

	for (i=0;i<strlen(name);i++)
	{
		int temp = name[strlen(name)-i-1];
		if (temp<= '9' && temp >= '0') temp = temp - '0';
		else temp=0;
		magic += temp ^ (int) name[i];
	}

	sprintf(buffer,"%05x",magic);
	strcat(serial,buffer);

	printf("Serial : %s",serial);

	puts("\n\nWarning : if serial doesn't work, exit crackme and start again");

	return 0;
}


////////////////////////////////////////////////
/////////////////////////////////////////////////

// Of course it could be shorter, but it's just to show you
// how the string must be decrypted

int level2(void)
{
	char magic[] = "ig|b}";

	for (unsigned int i=0;i<strlen(magic);i++) magic[i] = magic[i] ^ 0x0E;

	printf("\nWord : %s",magic);
	return 0;
}

////////////////////////////////////////////////
/////////////////////////////////////////////////

int level3(void)
{
	char name[50];
	unsigned char sum;

	printf("\nName : ");
	gets(name);

	sum=0;
	for (unsigned int i=0;i<strlen(name);i++) sum += name[i];

	printf("Magic value : %u",(sum ^ (unsigned char)223));

	return 0;
}

