                                  E0000020 v1.0
                                 ---------------

This tool changes the first section characteristics of a PE file to 0xE0000020

E0000020 = IMAGE_SCN_MEM_EXECUTE | IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_WRITE | IMAGE_SCN_CNT_CODE
           ^^^^^^^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^^^^^   ^^^^^^^^^^^^^^^^^^
                 Executable               Read                 Write             Contains Code

What can I do with that ?
-------------------------

# Sometimes SICE doesn't break on the entrypoint of certain packed/encrypted files : you can use E0000020.exe to solve that problem

# You can use it if you want to use encryption in you own progs (the .text section must have the 'Write' attribute)

    ________     _______     _______
   /__   __/\   /  ____/\   /  ____/\
   \_/  /\_\/  /  /\___\/  /  /\___\/
    /  / /    /  /_/_     /  / / 
   /  / /    /____  /\   /  / /
  /  / /     \___/ / /  /  / /
 /  / /     ____/ / /  /  /_/_
/  / /     /_____/ /  /______/\
\__\/      \_____\/   \______\/ 20/02/2000

Thx to : Matt Pietrick,Miz

(sources on request)
tscube.cjb.net
               

