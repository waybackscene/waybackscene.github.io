// Keygen for CookieCrK trial crackme by TSCube 05/07/2000

// maybe I should start making my keygens in full WIN32ASM ;)

#include <stdio.h>
#include <string.h>
#include <windows.h>

int keygen(void);
int patch(void);
int keyfile(void);
unsigned int chars2dword(unsigned char* array);
void dword2chars(unsigned int dword,unsigned char* array);


int main(void)
{	
	int choice;

	puts("Keygen for CookieCrK trial crackme by TSCube 05/07/2000\n");
	puts("1) Patch to remove SICE detections & Nagscreen");
	puts("2) Keygen");
	puts("3) Keyfile generation");
	printf("\nChoose your destiny (1/2/3) : ");
	scanf("%d",&choice);
	getchar();

	switch(choice)
	{
	case 1:
		patch();
		break;
	case 2 :
		keygen();
		break;
	case 3 :
		keyfile();
		break;
	};

	puts("\n<enter> to finish");
	getchar();

	return 0;
}


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

int keygen(void)
{
	unsigned int serial,ebx,ecx,index;
	unsigned char name[50];

	memset(name,0x00,50);

	printf("\nName : ");
	gets((char*)name);

	ecx=0;
	index=0;
	while(name[index]!=0x00)
	{
		ebx = chars2dword(&name[index]);
		ebx = ~ebx;
		ebx = ebx ^ ((ebx << 8) & 0xFF00); // xor bh,bl
		ebx = _rotl(ebx,3);
		ebx++;
		ebx = _rotr(ebx,7);
		ebx += chars2dword(&name[index]);
		ecx += ebx;
		index += 4;
	}

	serial = 303174162 - ebx - ecx;
	serial = _rotr(serial,3);
	serial++;
	serial = _rotl(serial,7);
	serial = serial ^ 0xDEADDEAD;

	printf("Serial : %010u",serial); // serial must have 10 digits !
	return 0;

}


////////////////////////////////////////////////
/////////////////////////////////////////////////

int patch(void)
{
	int number = 8;
	unsigned int offset[] =
	{
		0x610,0x7B9,0x7BB,0x7BC,0x7BD,0x7BE,0x7BF,0xB34,0xB78	
	};

	unsigned char patched[] =
	{
		0xCC,0xFE,0x14,0x20,0x40,0x00,0xC3,0xEB,0xEB
	};

	FILE* file = fopen("CrcMe.exe","rb+");

	if (file==NULL)
	{
		puts("\nPatch error : I can't open 'CrcMe.exe' !!!");
		return 1;
	}

	for (int i=0;i<number;i++)
	{
		fseek(file,offset[i],SEEK_SET);
		fputc(patched[i],file);
	}
	
	fclose(file);

	puts("\nFile 'CrcMe.exe' successfully patched");

	return 0;

}

////////////////////////////////////////////////
/////////////////////////////////////////////////

int keyfile(void)
{
	unsigned char name[96];
	unsigned char bufmagic1[4];
	FILE* keyfile;
	unsigned int magic1,magic2,magic3,xorvalue,namelength;

	memset(name,0x00,96);
	printf("\nName : ");
	gets((char*)name);
	namelength = strlen((char*)name);
	for (unsigned int i=0;i<namelength;i++) name[i] = 0x00 - name[i];

	magic2=0;
	magic3=0;
	for (i=0;i<namelength;i++)
	{
		magic3 += name[i];
		magic2 ^= name[i];
	}

	magic2 += namelength;
	magic1 = (magic3 << namelength) + 0x39061982;

	xorvalue = magic2 & 0xFF;

	// the following code is very disgusting, but I was in a hurry
	dword2chars(magic1,bufmagic1);
	for (i=0;(i<4) && (xorvalue!=0);i++,xorvalue--)  bufmagic1[i] ^= xorvalue;
	magic1 = chars2dword(bufmagic1);

	keyfile=fopen("crackme.key","w");

	if (keyfile != NULL)
	{
		_putw( 0x21FEDDE7,keyfile);
		_putw(magic1,keyfile);
		fwrite(name,sizeof(unsigned char),96,keyfile);
		_putw(0,keyfile);
		_putw(0,keyfile);
		puts("Keyfile <crackme.key> successfully created !");
	}
	else
	{
		puts("Error while creating keyfile  <crackme.key>");
	}

	fclose(keyfile);
	return 0;

}



//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

// this function converts 4 chars to a DWORD value
//
// example
// argument :     unsigned char array[]={0x12,0x34,0x56,0x78};
// return value : 0x78563412

unsigned int chars2dword(unsigned char* array)
{
	unsigned int dword = 0;
	
	for (int i=3;i>=0;i--) 
	{
		dword = dword << 8;
		dword = dword | (int)array[i];
	}

	return dword;
}


//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////

// this function converts a DWORD value to 4 unsigned chars
//
// example
// argument : 0x78563412
// return value : unsigned char array[]={0x12,0x34,0x56,0x78};

void dword2chars(unsigned int dword,unsigned char* array)
{
	array[0] = dword & 0xFF;
	array[1] = (dword >> 8) & 0xFF;
	array[2] = (dword >> 16) & 0xFF;
	array[3] = (dword >> 24) & 0xFF;
}