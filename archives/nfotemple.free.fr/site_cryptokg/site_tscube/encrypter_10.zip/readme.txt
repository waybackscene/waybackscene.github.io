                                Byte encrypter v1.0
                                -------------------

This little tool can encrypt bytes from a file.

3 types of encryption are available :

# XOR encryption (0x50 XOR 0xFF -> 0xAF)
# ADD encrption (0x50 + 0xFF -> 0x4F)
# SUB encryption (0x50 - 0xFF -> 0x51)

how to use it
-------------

let's say you want to encrypt notepad.exe by using a XOR encryption with the 20 bytes at file offset 50 :

File to encrypt -> notepad.exe
Offset -> 50
Number of bytes to encrypt -> 20
type of encryption -> XOR encryption
Value -> 255 (0xFF)

click on "encrypt" and each byte will be replaced with (original_byte XOR 0xFF)

    ________     _______     _______
   /__   __/\   /  ____/\   /  ____/\
   \_/  /\_\/  /  /\___\/  /  /\___\/
    /  / /    /  /_/_     /  / / 
   /  / /    /____  /\   /  / /
  /  / /     \___/ / /  /  / /
 /  / /     ____/ / /  /  /_/_
/  / /     /_____/ /  /______/\
\__\/      \_____\/   \______\/ 01/02/2000

(sources on request)
               

PS : I decided to do this after W00DY told me he was encrypting his last proggy "by hand".

tscube.cjb.net