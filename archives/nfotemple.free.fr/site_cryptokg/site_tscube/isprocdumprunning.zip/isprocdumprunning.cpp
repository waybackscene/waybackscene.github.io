// Procdump detection by TSCube 13/07/2000

// Nothing very advanced here : I just get all the windows titles and compare
// them with Procdump's window title.

#include <windows.h>
#include <string.h>

BOOL CALLBACK EnumWindowsProc(HWND hwnd,LPARAM lParam );
HINSTANCE hInst;

bool isprocdumprunning = false;

int WINAPI WinMain (HINSTANCE hInstance, 
					HINSTANCE hPrevInstance,
                    PSTR szCmdLine, 
					int iCmdShow)
{
	hInst = hInstance;
	EnumWindows((WNDENUMPROC) EnumWindowsProc,(LPARAM) 0);

	if (isprocdumprunning) MessageBox(NULL,"Procdump detected !","Gotcha !",MB_ICONINFORMATION);
	else MessageBox(NULL,"Procdump NOT detected !","Alles klar !",MB_ICONINFORMATION);

	return 0;
}


BOOL CALLBACK EnumWindowsProc(HWND hwnd,LPARAM lParam )
{
	char windowtitle[100];
	char procdumptitle[] = "ProcDump32 (C) 1998, 1999, 2000 G-RoM, Lorian & Stone";
	GetWindowText(hwnd,windowtitle,100);

	if (strcmp(windowtitle,procdumptitle)==0)
	{
		isprocdumprunning=true;
		return false;
	}

	return true;
}