// Keyfile generator for Krypton crackme #1 by TSCube

#include <stdio.h>

int main(void)
{
	FILE* key;
	unsigned char keyfile[21];
	unsigned char magic[21] =
	{
		0x04,0x21,0x3A,0x27,0x36,0x0A,0x32,0x37,0x3C,0x13,
		0x3B,0x3C,0x27,0x3E,0x32,0x3A,0x3F,0x7D,0x30,0x3C,
		0x3E
	};

	for (int i=0;i<21;i++)
	{ keyfile[i] =  (magic[i] ^ 0x53) ^ 0x60; }

	puts("Keyfile generator for Krypton crackme #1 by TSCube\n");
	key = fopen("ya.do","w");
	if ( key != NULL)
	{
		fwrite(keyfile,sizeof(unsigned char),21,key);
		puts("Keyfile <ya.do> successfully created !\n");
		puts("==> Disable or hide softice before launching the crackme !");
	}
	else
	{
		puts("Error while creating keyfile <ya.do>");
	}

	fclose(key);
	puts("\n<enter> to finish");
	getchar();
	return 0;
}
