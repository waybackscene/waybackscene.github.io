#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
	char serial[] = "VN-XXXX-TbC";
	int random;

	puts("Keygen for Viny's easy crackme by TSCube 15/06/2000\n");

	srand( (unsigned)time( NULL ) ); // initialize pseudo-random number generator

	// serial[3] + serial[4] + serial[5] + serial[6] = 300
	random = (rand() % 27);
	serial[3] = 75 + random;
	serial[4] = 75 - random;
	random = (rand() % 27);
	serial[5] = 75 + random;
	serial[6] = 75 - random;

	printf("Serial : %s\n\n",serial);
	puts("<enter> to finish");
	getchar();


	return 0;
}