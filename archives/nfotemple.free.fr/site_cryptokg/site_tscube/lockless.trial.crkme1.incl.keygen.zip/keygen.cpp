// Keygen for Lockless trial crackme #1 by TSCube 21/06/2000

#include <stdio.h>
#include <string.h>

int generate(const char* name, char* serial1,char* serial2);

int main(void)
{
	char name[50];
	char serial1[50];
	char serial2[50];

	puts("Keygen for Lockless trial crackme #1 by TSCube 21/06/2000\n\n");
	printf("Name (at least 6 letters) : ");
	gets(name);

	if (strlen(name)<6)
	{
		puts("I said : AT LEAST 6 LETTERS !!!");
		return 1;
	}


	generate(name,serial1,serial2);

	printf("Serial #1 : %s\n",serial1);
	printf("Serial #2 : %s",serial2);
	
	puts("\n\n<enter> to finish");
	getchar();

	return 0;
}


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

// this is what I call the "Lazy paster approach" ;)

int generate(const char* name, char* serial1,char* serial2)
{
	int len = strlen(name);
	int magic1 = 0;
	int magic2 = 0;

	__asm
	{
		mov eax, 01h

begin_loop_1 :
		mov edx,name
		movzx edx, byte ptr [edx+eax-01h]
		add magic1, edx
		inc eax
		cmp eax, 07h
		jne begin_loop_1

		mov eax, len
		add magic1,eax
		imul eax, magic1, 15C10Eh
		mov magic1, eax
		mov eax, magic1
		mov ecx, 03h
		cdq
		idiv ecx
		mov magic1, eax
		add magic1, 29Ah
		mov eax, magic1
		mov ecx, 1388h
		cdq
		idiv ecx
		mov magic1, eax
		mov eax, len
		imul magic1
		mov magic1, eax
		mov eax,name
		movzx eax, byte ptr [eax+02]
		imul magic1
		mov magic1, eax
		mov eax,name
		movzx eax, byte ptr [eax+04]
		imul magic1
		mov magic1, eax
		cmp magic1, 05F5E0FFh
		jle begin_loop_2
		cmp magic1, 3B9ACA00h
		jl end_loop_2

begin_loop_2 :

		mov eax,len
		add magic1, eax
		mov eax,name
		movzx eax, byte ptr [eax]
		imul magic1
		mov magic1, eax
		cmp magic1, 00h
		jge next_loop_2
		mov eax, magic1
		mov edx, eax
		neg eax
		mov magic1, eax

next_loop_2 :

		cmp magic1, 05F5E0FFh
		jle begin_loop_2
		cmp magic1, 3B9ACA00h
		jge begin_loop_2

end_loop_2 :

		mov eax, magic1
		mov magic2, eax

begin_loop_3 :

		mov eax, magic2
		mov edx,len
		mov ecx, edx
		cdq
		idiv ecx
		mov magic2, eax
		cmp magic2, 2710h
		jge next_loop_3
		mov eax, magic2
		imul eax
		mov magic1, eax

next_loop_3 :

		cmp magic2, 270Fh
		jle begin_loop_3
		cmp magic2, 186A0h
		jge begin_loop_3

	}

	sprintf(serial1,"%u",magic1);
	sprintf(serial2,"%u",magic2);

	return 0;

}