// Keygen for Lockless trial crackme #2 by TSCube 04/07/2000

#include <stdio.h>
#include <string.h>
#include <windows.h>

int keygen(void);
int patch(void);
int keyfile(void);
unsigned int getvolumeserialnumber(void);

int main(void)
{	
	int choice;

	puts("Keygen for Lockless trial crackme #2 by TSCube 04/07/2000\n");
	puts("1) Patch to remove SICE detection & Nagscreen");
	puts("2) Keygen for Phase 2 & 3");
	puts("3) Keyfile generation");
	printf("\nChoose your destiny (1/2/3) : ");
	scanf("%d",&choice);
	getchar();

	switch(choice)
	{
	case 1:
		patch();
		break;
	case 2 :
		keygen();
		break;
	case 3 :
		keyfile();
		break;
	};

	puts("\n<enter> to finish");
	getchar();

	return 0;
}


/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

// this is what I call the "Lazy paster approach" ;)

int keygen(void)
{
	char name[50];
	unsigned int magic1,magic2,volumenumber;
	int len;

	printf("\nName (at least 6 letters) : ");
	gets(name);

	if (strlen(name)<6)
	{
		puts("I said : AT LEAST 6 LETTERS !!!");
		return 1;
	}

	len = strlen(name);
	magic1 = 0;
	magic2 = 0;
	volumenumber = getvolumeserialnumber();

	__asm
	{
		mov eax, 01h

begin_loop_1 :
		lea edx,name
		movzx edx, byte ptr [edx+eax-01h]
		add magic1, edx
		inc eax
		cmp eax, 07h
		jne begin_loop_1

		mov eax, len
		add magic1,eax
		imul eax, magic1, 15C10Eh
		mov magic1, eax
		mov eax, magic1
		mov ecx, 03h
		cdq
		idiv ecx
		mov magic1, eax
		add magic1, 29Ah
		mov eax, magic1
		mov ecx, 1388h
		cdq
		idiv ecx
		mov magic1, eax
		mov eax, len
		imul magic1
		mov magic1, eax
		lea eax,name
		movzx eax, byte ptr [eax+02]
		imul magic1
		mov magic1, eax
		lea eax,name
		movzx eax, byte ptr [eax+04]
		imul magic1
		mov magic1, eax
		cmp magic1, 05F5E0FFh
		jle begin_loop_2
		cmp magic1, 3B9ACA00h
		jl end_loop_2

begin_loop_2 :

		mov eax,len
		add magic1, eax
		lea eax,name
		movzx eax, byte ptr [eax]
		imul magic1

		mov ecx, volumenumber	// new addition from Lord Anshar for this crackme #2
		imul ecx				// 

		mov magic1, eax
		cmp magic1, 00h
		jge next_loop_2
		mov eax, magic1
		mov edx, eax
		neg eax
		mov magic1, eax

next_loop_2 :

		cmp magic1, 05F5E0FFh
		jle begin_loop_2
		cmp magic1, 3B9ACA00h
		jge begin_loop_2

end_loop_2 :

		mov eax, magic1
		mov magic2, eax

begin_loop_3 :

		mov eax, magic2
		mov edx,len
		mov ecx, edx
		cdq
		idiv ecx
		mov magic2, eax

		mov eax,volumenumber	//
		mov ecx,magic2			// INCREDIBLE !!!
		cdq						// 6 more lines were added to this protection !!! ;)
		idiv ecx				//
		sub ecx,eax				//
		mov magic2, ecx			//

		cmp magic2, 2710h
		jge next_loop_3
		mov eax, magic2
		imul eax
		mov magic2, eax

next_loop_3 :

		cmp magic2, 270Fh
		jle begin_loop_3
		cmp magic2, 186A0h
		jge begin_loop_3

	}

	printf("Phase #2 serial : %u\n",magic1);
	printf("Phase #3 serial : %u",magic2);

	return 0;

}


////////////////////////////////////////////////
/////////////////////////////////////////////////

// This function patches the crackme (which is packed) to disable
// the SICE check and the nagscreen. This is done using caving

// SICE patch -> @435AA6
// Nagscreen patch -> @438517

int patch(void)
{
	int number = 28;
	unsigned int offset[] =
	{
		0x372,0x373,0x374,0x375,0x376,0x378,0x379,0x37A,0x37B,0x37C,0x37D,0x37F,
		0x380,0x381,0x382,0x383,0x384,0x385,0x386,0x387,0x389,0x38A,0x38B,0x38C,
		0x38D,
		0x1599,0x159A,0x159B	
	};

	unsigned char patched[] =
	{
		0xC6,0x05,0xA6,0x5A,0x43,0xEB,0xC7,0x05,0x17,0x85,0x43,0x90,0x90,0x90,0x90,
		0xC6,0x05,0x1B,0x85,0x43,0x90,0xE9,0x41,0x81,0x03,0xD5,0xA1,0xFA
	};

	FILE* file = fopen("register.exe","rb+");

	if (file==NULL)
	{
		puts("\nPatch error : I can't open 'register.exe' !!!");
		return 1;
	}

	for (int i=0;i<number;i++)
	{
		fseek(file,offset[i],SEEK_SET);
		fputc(patched[i],file);
	}
	
	fclose(file);

	puts("\nfile 'register.exe' successfully patched");

	return 0;

}

////////////////////////////////////////////////
/////////////////////////////////////////////////

int keyfile(void)
{
	FILE* key;
	unsigned char magic[4] = { 0x3F,0x82,0x62,0x5E};
	char random[10];
	char keyfile[13];

	printf("\nType any 4 letters : ");
	gets(random);

	if (strlen(random)!=4)
	{
		puts("I said 4 letters !!!");
		return 1;
	}

	for (int i=0;i<4;i++) keyfile[i] = random[i];
	for (i=4;i<8;i++) keyfile[i] = magic[i-4];
	for (i=8;i<12;i++) keyfile[i] = random[i-8];

	key = fopen("lockey.key","w");
	if ( key != NULL)
	{
		fwrite(keyfile,sizeof(unsigned char),12,key);
		puts("Keyfile <lockey.key> successfully created !");
	}
	else
	{
		puts("Error while creating keyfile <lockey.key>");
	}

	fclose(key);
	return 0;
}


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////

unsigned int getvolumeserialnumber(void)
{
	unsigned int number;

	if (!GetVolumeInformation("C:\\",NULL,0,(unsigned long*)&number,NULL,NULL,NULL,0))
	{
		return 0;
	}

	return number;

}