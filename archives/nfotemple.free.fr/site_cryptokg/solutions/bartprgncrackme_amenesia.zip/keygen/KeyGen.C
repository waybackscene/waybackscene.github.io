/*
 *  
 *   Keygen [PRGN crackme by bart/xt]  by Amenesia
 *          
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>   


void main()
{  
    char nom[40];
    unsigned int i,Seed;
    unsigned char RandNumber[64];
    unsigned char magicKey[200];


    miracl *mip=mirsys(200,0);

    big nameBig   =mirvar(0);
    big D         =mirvar(0);
    big P         =mirvar(0);
    big e         =mirvar(65537);
    big phi       =mirvar(0);
    big Q         =mirvar(0);
    big N2        =mirvar(0);
    big N1        =mirvar(0);
    big resultat  =mirvar(0);


    printf("\t KeyGen [PRGN crackme by bart/xt] by Amenesia\n");
    printf("\t --------------------------------------------\n");


      printf("Magic Key: \t");
      scanf("%200s",&magicKey);
      printf("Factorization in progress... \t");

      mip->IOBASE=16;
      cinstr(N1,magicKey);

     /* --------------------PRGN-Brute Forcer ------------------ */
     for( i=0; ((i < 65535) && ( compare(N1,N2) != 0)); i++)
     {
      Seed = i;
                           asm{
 	  			   xor     edi, edi
 	  			   jmp     GenRandNum
  
 
                               LoopGenRandNum:     

 				   mov     eax, 14EF2A01h
 				   mul     [Seed]
 				   mov     [Seed], eax
 				   add     [Seed], 3F5743FAh
 				   mov     eax, [Seed]
 				   xor     eax, 42398544h
 				   mov     edx, eax
 				   mov     [RandNumber+edi], dl
 				   inc     edi
 
 			         GenRandNum:                       
 				   cmp     edi, 64
 				   jb      LoopGenRandNum
 			 }

 				     bytes_to_big(32,RandNumber,P);
 				     nxprime(P,P); 
  			 	     bytes_to_big(32,&(RandNumber[32]),Q);
 				     nxprime(Q,Q);
 				     multiply(Q,P,N2);
        }  


	if ( compare(N1,N2) == 0) { 
                                  /* ---- Compute the Private Key ----- */
                                  
                                   decr(P,1,P);
                                   decr(Q,1,Q);
                                   multiply(P,Q,phi);  
                                   xgcd(e,phi,e,e,D);


                                   /* ---------- RSA -------- */
 				   printf("Name: \t");
   				   scanf("%34s",&nom);
   				   bytes_to_big(strlen(nom),&nom,nameBig);

   				   powmod(nameBig,e,N1,resultat);  

   				   printf("Serial:\t");
   				   mip->IOBASE=16;
   				   cotnum(resultat,stdout);
      	                          }
        else
                                  { 
                                    printf("Error: Check Your Magic Key...\n");
                                  }

      

    /* ---------- END -------- */
    mirkill(nameBig);
    mirkill(D);
    mirkill(resultat);
    mirkill(N1);
    mirkill(N2);
    mirkill(e);
    mirkill(phi);
    mirkill(P);
    mirkill(Q);
    mirexit();
}