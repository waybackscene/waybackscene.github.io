
/*

	Barts PRNG crackme solution by Elessar	
	Sorry for the somewhat messy code =)

 */


#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include <miracl.h>

int			BruteForce(big,big,big);
char		Seed_Func(int*);
HINSTANCE	hInst;
BOOL CALLBACK DialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{	

	int len,i;
	char username[50];
	char magic_key[200];
	char serial[200];
	char test;
	miracl *mip;	
	big key,user,P,Q,E,D,N,result;	

	switch (uMsg)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);		
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{	
		case IDC_GENERATE:			
			mip=mirsys(250,0);
			len = GetDlgItemText(hWnd, IDC_USERNAME, username, 50);
			if(len>0) {

				if((GetDlgItemText(hWnd,IDC_KEY, magic_key, 130)) > 0) {					
					for(i=0;i<(int)strlen(magic_key);i++)  {
						test = magic_key[i];
						if( !  (((test >= 'A') && (test <= 'F')) || ((test >= '0') && (test <= '9'))) ) {							
							SetDlgItemText(hWnd,IDC_SERIAL1,"magic key contains invalid characters");
							return 0;						
						}
					}

					key = mirvar(0);
					user = mirvar(0);
					P	= mirvar(0);
					Q	= mirvar(0);
					E   = mirvar(0);
					D	= mirvar(0);
					N	= mirvar(0);
					result = mirvar(0);
					
					mip->IOBASE=16;
					cinstr(key,magic_key);					
					if(!BruteForce(key,P,Q)) {
						SetDlgItemText(hWnd,IDC_SERIAL1,"couldn't find a serial, please check your magic key");
						return 0;
					}
										
					convert(0x10001,E);
					multiply(P,Q,N); // calculate N from P and Q
					
					decr(P,1,P);	
					decr(Q,1,Q);
					multiply(P,Q,result); //result = (P-1)*(Q-1)

					xgcd(E,result,E,E,E); //calculate inverse modulus of E
					power(E,1,result,D);  //calculate D

					bytes_to_big(len,(char*)&username,user);
					powmod(user,D,N,result);

					cotstr(result,(char*)&serial);
					SetDlgItemText(hWnd,IDC_SERIAL1,(char*)&serial);
					
					mirkill(result);
					mirkill(N);
					mirkill(D);
					mirkill(E);
					mirkill(Q);
					mirkill(P);
					mirkill(user);
					mirkill(key);

				}else SetDlgItemText(hWnd,IDC_SERIAL1,"please input the magic key");

			}else SetDlgItemText(hWnd,IDC_SERIAL1,"please input the username");
			mirexit();
		}//switch (LOWORD(wParam))		
		break;	
	}//switch (uMsg)	
    return 0;
}//DialogProc

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	hInst=hInstance;	
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}


int BruteForce(big key, big P, big Q) {
	char cP[32];
	char cQ[32];
	char temp;	

	int i, x, seed,val, len,valP,valQ;		
	int* ptr;
	
	
	
	len = (key->len)-1;
	val = (*(key->w+len)) & 0xFFFFFFF0; //get first 28 bits of key (N)

	for(i=0;i<65536;i++) { //try all possible solutions
		seed = i;				
		for(x=0;x<32;x++) {			
			cP[x] = Seed_Func(&seed);
		}
		
		for(x=0;x<4;x++) {
			cQ[x] = Seed_Func(&seed);
		}

		temp = cP[0];
		cP[0] = cP[3];
		cP[3] = temp;		// reverse the bytes
		temp = cP[1];
		cP[1] = cP[2];
		cP[2] = temp;

		temp = cQ[0];
		cQ[0] = cQ[3];
		cQ[3] = temp;
		temp = cQ[1];		// reverse the bytes
		cQ[1] = cQ[2];
		cQ[2] = temp;

		ptr = &cP;
		valP = (int)*ptr;
		ptr = &cQ;
		valQ = (int)*ptr;
		
		_asm {
			mov eax, valP
			mov edx, valQ
			mul edx
			and edx, 0xFFFFFFF0
			mov valP,edx
		}
		/*
			We only check the first 28 bits, then do a more thorough test 
			if it passes the first. This way we don't have to create P and Q
			to check if they are the factors of key (N) for every seed value,
			only for those that pass the first test. This will take less
			computing power, since a normal multiply is way faster than a
			bignum (multiply/compare)/divisible test.
		*/

		if (valP == val) { 
			
			seed = i;
			for(x=0;x<32;x++) {			
				cP[x] = Seed_Func(&seed);
			}		
			
			bytes_to_big(32,(char*) &cP,P);
			nxprime(P,P); //find P

			if(divisible(key,P)) { //check if key is divisible by P, thus proving P is a factor in key

				for(x=0;x<32;x++) { 
					cQ[x] = Seed_Func(&seed);
				}

				bytes_to_big(32,(char*) &cQ,Q);
				nxprime(Q,Q); //find Q
				return 1; //found a serial
			}//if divisible

		}//if valP == val
	}//for
	
	return 0; //no serial found
}

char Seed_Func(int* seed) {		//this is the rng
	*seed*=0x14EF2A01;	
	*seed+=0x3F5743FA;
	return (char)((*seed^0x42398544)&0xFF);
}