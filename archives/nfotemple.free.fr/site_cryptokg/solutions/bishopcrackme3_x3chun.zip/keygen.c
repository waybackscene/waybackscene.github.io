/*
 BiSHoP's CrackMe #3 
 Protection : RSA-32 
 KeyGen by x3chun 
 Compiled by Visual C++ 6.0
 ps. if u will use brute-force this crackme, maybe u are fucked!
 ********************
 bpx getdlgitemtexta
 40107c - > szNameVal calculation
 
 RSA-32

 Encryption 
 szNameVal=(szSerial ^ 455h(E) ) mod ( N(EAD2C511))
 Decryption
 szSerial=(szNameVal ^ E6CAF5C5(d)) mod ( N(EAD2C511))

 */



#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include <miracl.h>

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	unsigned char szName[100] = {0};
	unsigned char szSerial[41] = {0};
	unsigned long szNameVal,dtLengthN;
	big M,n,e;
	miracl *mip=mirsys(100,0);

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		
	case IDC_EDITNAME:

			dtLengthN=GetDlgItemText(hWnd, IDC_EDITNAME, szName, 100);
			if (dtLengthN<1) {
				SetDlgItemText(hWnd, IDC_EDITSERIAL, "Pleaz type over 1 chars!");
				break;
			}
	
			// Name Value calculation

			__asm {

						xor	ecx, ecx
						xor	ebx, ebx
						lea esi, szName
						cld

loc_401173:											; CODE XREF: sub_401169+16.j
						inc	ecx
						lodsb
						test	al, al
						jz	short loc_401181
						mul	eax
						rol	eax, cl
						add	ebx, eax
						jmp	short loc_401173
; ���������������������������������������������������������������������������


loc_401181:											; CODE XREF: sub_401169+E.j
						imul	ebx, ebx
						mov	eax, ebx
						shr	eax, 2
						imul	ebx, eax
						bswap	ebx					// for the change the szNameval to bytes_to_big Number 
						mov [szNameVal],ebx			// store ebx to szNameVal
			}
		
			// RSA Decryption 
			// E=455h, N=EAD2C511 , IoBase -> 16
			// P=E003, Q=10C5B, D=E6CAF5C5
			// RSA Encryption �� (szSerial ^ 455h) mod N(EAD2C511) = szNameVal 
			// RSA Decryption �� (szNameVal ^ D(E6CAF5C5) ) mod N(EAD2C511) = szSerial 

			// RSA IOBASE( use character 0-9,A-F )

			mip->IOBASE=16;

			// RSA buffer alloc

			M=mirvar(0);
			n=mirvar(0);
			e=mirvar(0);
		
			// change the szNameVal  to Big Number 

			bytes_to_big(0x4,&szNameVal,M);

			// change the RSA N,E value to  Big Number 

			cinstr(n,"EAD2C511");
			cinstr(e,"E6CAF5C5");

			// RSA Encryption

			powmod(M,e,n,M);
			
			// use character (0-9) IOBASE=10 ( need to Show serial)

			mip->IOBASE=10;
			cotstr(M, szSerial); 			
			SetDlgItemText(hWnd, IDC_EDITSERIAL, szSerial);

			// RSA Buffer Unlock

			mirkill(M);
			mirkill(n);
			mirkill(e);
			mirexit(); 
			break;
		case IDC_ABOUT:
		MessageBox(hWnd, "BiSHoP's CrackMe #3\nProtection : RSA-32\nKeyGen by x3chun", "About", MB_ICONINFORMATION);
			break;
		}
		break;
	case WM_INITDIALOG:
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
