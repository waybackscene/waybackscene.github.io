/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Bishop's Lockless Crackme #4
 Author:		figugegl
 Version:		1.0
 Date:			21.10.2002

 NOTES
 -----

 * LCC-Win32 and Miracl

   Miracl Version 4.5 can be included directly without compiling.
   Include ms32.lib in the linker settings (c:\programme\lcc\lib\ms32.lib)
   Other versions than 4.5 are supposed to NOT work properly.

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include <miracl.h>
#include "keygen.h"
#include "md5.c"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	// fill and register wndclass-structure
	memset (&wc, 0, sizeof (wc));
	wc.lpfnWndProc		= MainDlgProc;
	wc.cbWndExtra		= DLGWINDOWEXTRA;
	wc.hInstance		= hInst;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU));
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName	= szAppName;
	RegisterClass (&wc);

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid
                Protection = rsa 130
 Input:         hWnd : handle of the dialog window
 Output:        None.
 Errors:        None.
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	MD5_CTX context;
    big     bigSerial, bigHash, bigPrExp, bigModulus;
    int     iNameLen, iCompLen;
	char    szName[64], szCompany[32], szSerial[34] = "", cHash[16] = "";

	// get input
	iNameLen = GetDlgItemText (hWnd, EDF_NAME, szName, 32);
	iCompLen = GetDlgItemText (hWnd, EDF_COMPANY, szCompany, 32);

	// check input lengths
	if ((iNameLen < 1) || (iCompLen < 1))
	{
		SetDlgItemText (hWnd, EDF_SERIAL, NULL);
		return;
	}

	// initialize miracl: 100 digits per big, base 16
    miracl *mip = mirsys (100, 16);

	// initialize big numbers
    bigSerial  = mirvar (0);
    bigModulus = mirvar (0);
    bigPrExp   = mirvar (0);
    bigHash    = mirvar (0);

	// initialize constants
	instr (bigModulus, "24DFDA27FA14D3F27DDF62CEA5D2381F9");
	instr (bigPrExp,   "1E2D9B52ADCBC20DCCDE3C721AA740E83");

	// hash: md5 on name/company
	lstrcat (szName, szCompany);
	iNameLen = lstrlen (szName);
	MD5Init (&context);
	MD5Update (&context, szName, iNameLen);
	MD5Final (cHash, &context);
	bytes_to_big (16, cHash, bigHash);

	// calculate serial
	// rsa: serial = hash ^ d % n
	powmod (bigHash, bigPrExp, bigModulus, bigSerial);

	// show serial
	otstr (bigSerial, szSerial);
	SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);

	// miracl cleanup
	mirkill(bigSerial);
	mirkill(bigModulus);
	mirkill(bigPrExp);
	mirkill(bigHash);
	mirexit();
	return;
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hWnd, EDF_NAME, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		SendDlgItemMessage (hWnd, EDF_COMPANY, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_COMPANY, "[tnp]");
		break;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:
		case EDF_COMPANY:
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
			}
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			break;

		case BUT_EXIT:			// Exit
			SendMessage (hWnd, WM_CLOSE, 0, 0);
			break;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0);
		break;

	default:
		return DefWindowProc (hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

