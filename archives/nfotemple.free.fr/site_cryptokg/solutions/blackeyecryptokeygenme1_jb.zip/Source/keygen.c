/******************************************************
  bLaCk-eye - KeygenMe 1.
  Keygen by jB

  Date: 4/1/2004
  Protection: Modified MD5, discrete logarithm problem

  Solved using the Pollard's rho algorithm
******************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "miracl.h"
#include "md5.h"
#include "global.h"

#define NPRIMES 4

static big p,p1,order,lim1,lim2;

int str2dword(unsigned char *input)
{
  int dword;
  dword = ((int)input[3]) | (((int)input[2]) << 8) |
   (((int)input[1]) << 16) | (((int)input[0]) << 24);
  return dword;
}

void iterate(big x,big q,big r,big a,big b)
{ /* apply Pollards random mapping */
    if (compare(x,lim1)<0)
    {
        mad(x,q,q,p,p,x);
        incr(a,1,a);
        if (compare(a,order)==0) zero(a);
        return;
    }
    if (compare(x,lim2)<0)
    {
        mad(x,x,x,p,p,x);
        premult(a,2,a);
        if (compare(a,order)>=0) subtract(a,order,a);
        premult(b,2,b);
        if (compare(b,order)>=0) subtract(b,order,b);
        return;
    }
    mad(x,r,r,p,p,x);
    incr(b,1,b);
    if (compare(b,order)==0) zero(b);
}

long rho(big q,big r,big m,big n)
{ /* find q^m = r^n */
    long iter,rr,i;
    big ax,bx,ay,by,x,y;
    ax=mirvar(0);
    bx=mirvar(0);
    ay=mirvar(0);
    by=mirvar(0);
    x=mirvar(1);
    y=mirvar(1);
    iter=0L;
    rr=1L;
    do
    { /* Brent's Cycle finder */
        copy(y,x);
        copy(ay,ax);
        copy(by,bx);
        rr*=2;
        for (i=1;i<=rr;i++)
        {
            iter++;
            iterate(y,q,r,ay,by);
            if (compare(x,y)==0) break;
        }
    } while (compare(x,y)!=0);

    subtract(ax,ay,m);
    if (size(m)<0) add(m,order,m);
    subtract(by,bx,n);
    if (size(n)<0) add(n,order,n);
    mirkill(y);
    mirkill(x);
    mirkill(by);
    mirkill(ay);
    mirkill(bx);
    mirkill(ax);
    return iter;
}

int main()
{
    char name[50];
    MD5_CTX context;
    unsigned char digest[16];

    unsigned int cipher;

    char qstring[12];
    int i,id,np=4;
    long iter;
    big pp[NPRIMES],rem[NPRIMES];
    big m,n,Q,R,q,w,x,proot;
    FILE *fp;
    big_chinese bc;
    miracl *mip=mirsys(50,0);

    for (i=0;i<NPRIMES;i++) 
    {
        pp[i]=mirvar(0);
        rem[i]=mirvar(0);
    }

    pp[0]=mirvar(2);
    pp[1]=mirvar(157);
    pp[2]=mirvar(2503);
    pp[3]=mirvar(0);
    cinstr(pp[3],"78454615079");

    proot=mirvar(0);
    cinstr(proot,"3592208548749201");
    q=mirvar(0);
    Q=mirvar(0);
    R=mirvar(0);
    w=mirvar(0);
    m=mirvar(0);
    n=mirvar(0);
    x=mirvar(0);
    p=mirvar(0);
    p1=mirvar(1);
    order=mirvar(0);
    lim1=mirvar(0);
    lim2=mirvar(0);

    printf("Crypto KeygenMe 1 - bLaCk-eye\nKeygen by jB\n\nName:\t");
    gets(name);
    if(!strlen(name) || strchr(name,'#'))
	printf("Invalid Name\n");
    else {

    MD5Init (&context);
    MD5Update (&context, name, strlen(name));
    MD5Final (digest, &context);

    cipher=((str2dword(digest) ^str2dword(digest+12)) & str2dword(digest+4)) * str2dword(digest+8);

    for (i=0;i<np;i++) multiply(p1,pp[i],p1);
    incr(p1,1,p);

    subdiv(p,3,lim1);
    premult(lim1,2,lim2);
    sprintf(qstring, "%lu",cipher);
    cinstr(q,qstring);

    crt_init(&bc,np,pp);
    for (i=0;i<np;i++)
    { /* accumulate solutions for each pp */
        copy(p1,w);
        divide(w,pp[i],w);
        powmod(q,w,p,Q);
        powmod(proot,w,p,R);
        copy(pp[i],order);
        iter=rho(Q,R,m,n);
        xgcd(m,order,w,w,w);
        mad(w,n,n,order,order,rem[i]);
    }
    crt(&bc,rem,x);   /* apply Chinese remainder thereom */
    mip->IOBASE=16;
    printf("Serial:\t%s#",name);
    cotnum(x,stdout);
    crt_end(&bc);
    }
    getchar();
    return 0;
}

