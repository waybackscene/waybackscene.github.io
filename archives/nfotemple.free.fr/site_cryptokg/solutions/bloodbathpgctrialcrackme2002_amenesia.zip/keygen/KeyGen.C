/*
 *  
 *   Keygen pour le PGC OFFiCiAL KEYGENME par Amenesia
 *          
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>   
#include "md5c.c"


void main()
{  
    char chaine[15] ="[PGCTRiAL/2oo2]";
    char nom[40];
    unsigned char szHash[41] = {0};
    MD5_CTX context;
    miracl *mip=mirsys(50,0);  /* base 0, 50 digits par big  */


    big BigHash   =mirvar(0);
    big modulo    =mirvar(0);
    big D         =mirvar(0);
    big resultat  =mirvar(0);

    mip->IOBASE=16;
    cinstr(D,"10001");
    cinstr(modulo,"8E701A4C793EB8B739166BB23B49E421");


    printf("\t KeyGen [PGC OFFiCiAL KEYGENME] by Amenesia\n");
    printf("\t ------------------------------------------\n");

    printf("Name: \t");
    scanf("%17s",&nom);
    strcat( nom,chaine);

    MD5Init(&context);
    MD5Update(&context, nom, strlen(nom));
    MD5Final(szHash, &context);
  
    bytes_to_big(16,szHash,BigHash);     
    powmod(BigHash,D,modulo,resultat);  


    printf("Serial:\t");
    mip->IOBASE=16;
    cotnum(resultat,stdout);

    mirkill(BigHash);
    mirkill(D);
    mirkill(resultat);
    mirkill(modulo);
    mirexit();
}





