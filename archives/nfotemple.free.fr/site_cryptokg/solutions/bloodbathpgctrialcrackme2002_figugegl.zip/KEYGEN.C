/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for PGC Trial Crackme 2002
 Author:		figugegl
 Version:		1.0
 Date:			20.10.2002

 NOTES
 -----

 * LCC-Win32 and Miracl

   Miracl Version 4.5 can be included directly without compiling.
   Include ms32.lib in the linker settings (c:\programme\lcc\lib\ms32.lib)
   Other versions than 4.5 are supposed to NOT work properly.

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include <miracl.h>
#include "md5c.c"
#include "keygenres.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	// fill and register wndclass-structure
	memset (&wc, 0, sizeof (wc));
	wc.lpfnWndProc		= MainDlgProc;
	wc.cbWndExtra		= DLGWINDOWEXTRA;
	wc.hInstance		= hInst;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU));
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName	= szAppName;
	RegisterClass (&wc);

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
                Protection = MD5 / RSA 128 (WRONG implementation!)
 Input:         hWnd : handle of the dialog window
 Output:        None.
 Errors:        None.
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	MD5_CTX context;
    big     bigSerial, bigHash, bigPubExp, bigModulus;
    int     i, iNameLen;
	char    szName[32], szSerial[34] = "", szHash[42] = "", szPgc[] = "[PGCTRiAL/2oo2]";

	// get input and check length
	iNameLen = GetDlgItemText (hWnd, EDF_NAME, szName, 17);
	if (iNameLen == 0)
	{
		SetDlgItemText (hWnd, EDF_SERIAL, NULL);
		return;
	}

	// bigHash: md5 on name + "[PGCTRiAL/2oo2]"
	// original verfsion of md5, not the same as roy's
	lstrcat (szName, szPgc);
	iNameLen = lstrlen (szName);
	MD5Init (&context);
	MD5Update (&context, szName, iNameLen);
	MD5Final (szHash, &context);

	// initialize miracl: 200 digits per big, base 16
    miracl *mip = mirsys (200, 16);

	// initialize big numbers
    bigSerial  = mirvar (0);
    bigModulus = mirvar (0);
    bigPubExp  = mirvar (65537);
    bigHash    = mirvar (0);

	// set bignums
	instr (bigModulus, "8E701A4C793EB8B739166BB23B49E421");
	bytes_to_big (16, szHash, bigHash);

	// calculate serial
	// rsa: serial = hash ^ d % n
	powmod (bigHash, bigPubExp, bigModulus, bigSerial);

	// show serial
	otstr (bigSerial, szSerial);
	SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);

	// miracl cleanup
	mirkill(bigSerial);
	mirkill(bigModulus);
	mirkill(bigPubExp);
	mirkill(bigHash);
	mirexit();
	return;
}


/*------------------------------------------------------------------------
 Procedure:     AboutDlgProc
 Purpose:       Handles the messages of the about dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK AboutDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
     switch (uMsg)
     {
     case WM_INITDIALOG:
          return 0;

     case WM_COMMAND:
          if (LOWORD (wParam) == BUT_OK)
          {
               EndDialog (hWnd, 0) ;
               return 0;
          }
          break ;
     }
     return FALSE ;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hWnd, EDF_NAME, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		break;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:
			if (HIWORD (wParam) == EN_CHANGE)
				CalculateSerial (hWnd);
			break;

		case BUT_ABOUT:			// About
			DialogBox (NULL, MAKEINTRESOURCE (DLG_ABOUT), hWnd, (DLGPROC) AboutDlgProc);
			break;

		case BUT_EXIT:			// Exit
			SendMessage (hWnd, WM_CLOSE, 0, 0);
			break;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0);
		break;

	default:
		return DefWindowProc (hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

