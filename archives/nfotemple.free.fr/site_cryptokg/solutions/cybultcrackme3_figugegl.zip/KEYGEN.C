/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for Cybult Crackme #3
 Author:		figugegl
 Version:		1.0
 Date:			9.8.2003

 NOTES
 -----

 * Miracl: Include ms32.lib in the linker settings

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include <miracl.h>
#include "keygen.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	// fill and register wndclass-structure
	memset (&wc, 0, sizeof (wc));
	wc.lpfnWndProc		= MainDlgProc;
	wc.cbWndExtra		= DLGWINDOWEXTRA;
	wc.hInstance		= hInst;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU));
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName	= szAppName;
	RegisterClass (&wc);

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial, protection = rsa 160
 Input:         hWnd : handle of the dialog window
 Output:        None.
 Errors:        None.
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	// initialize: 200 digits per big, base 16
    miracl *mip = mirsys (200, 16);
    big           bigSerial, bigHash, bigPrExp, bigModulus;
    int           i, j, iNameLen, iCompName;
	unsigned char szName[32], szCompany[32], szSerial[80] = "",cHash[32] = "";

	// get input
	iNameLen = GetDlgItemText (hWnd, EDF_NAME, szName, 32);
	iCompName = GetDlgItemText (hWnd, EDF_COMPANY, szCompany, 32);

	// check input lengths
	if ((iNameLen == 0) || (iCompName == 0))
	{
		SetDlgItemText (hWnd, EDF_SERIAL, NULL);
		return;
	}

	// hash, code taken from ida
	__asm
	{
		// save registers
		pushad

		// namehash
		xor eax, eax
		xor ebx, ebx
		xor edx, edx
		lea edi, dword ptr cHash
		mov j, 4
	loc_401808:
		lea esi, dword ptr szName
		mov ecx, iNameLen
	loc_401811:
		lodsb
		dec al
		imul eax, 1983h
		or  eax, 7F524182h
		bswap eax
		xor eax, edx
		sub eax, 827166DCh
		rol eax, 2
		xor edx, ebx
		add eax, 0FFFFFFFFh
		xchg ah, al
		bswap eax
		neg eax
		imul ebx, eax, 92h
		add edx, eax
		imul eax, 8271h
		add eax, 726Fh
		ror eax, cl
		sub eax, ebx
		dec ecx
		jnz loc_401811
		stosd
		dec j
		jnz loc_401808

		// append companyhash
		xor eax, eax
		xor ebx, ebx
		xor edx, edx
//		lea edi, dword ptr cHash+16
		mov j, 4
	loc_401877:
		lea esi, dword ptr szCompany
		mov ecx, iCompName
	loc_401880:
		lodsb
		or  ah, al
		rol eax, 10h
		bswap eax
		add ebx, eax
		imul eax, 524FCh
		xor eax, 101155Ah
		or  eax, 81771FFCh
		imul eax, 716666CAh
		rcl eax, cl
		add eax, ecx
		xor edx, eax
		sub edx, ebx
		shrd eax, ebx, 2
		bswap ebx
		not eax
		rol eax, 6
		sub eax, edx
		add eax, 826FF14Ah
		imul eax, ebx, 21h
		bswap eax
		rol ebx, 1
		or  edx, 71626h
		bswap ebx
		sub ebx, edx
		xor edx, 15273811h
		imul eax, ebx, 2
		imul edx, eax, 235h
		bswap eax
		ror eax, 3
		sub dh, dl
		imul eax, 832h
		imul eax, edx, 7
		xor eax, ebx
		ror eax, 1Fh
		not ebx
		bswap ebx
		add eax, ebx
		xor eax, edx
		dec ecx
		jnz loc_401880
		stosd
		dec j
		jnz loc_401877

		// modify hash
		lea eax, dword ptr cHash
		push eax
		push eax
		pop esi
		pop edi
		push 8
		pop ecx
	loc_40191C:
		lodsd
		bswap eax
		ror eax, cl
		xor eax, 63796221h
		stosd
		dec ecx
		jnz loc_40191C

		// restore registers
		popad
	}

	// initialize big numbers
    bigSerial  = mirvar (0);
    bigModulus = mirvar (0);
    bigPrExp   = mirvar (0);
    bigHash    = mirvar (0);

	// initialize constants
	instr (bigModulus, "86FB5DDE8CD21295AE5024AFD6571B4A28F76C0B48A072F46F041E7DD75AD5C9");
	instr (bigPrExp,   "2DCA27D5CF3F943E629B9D566907B3A1BCFABEA05C01567F4A9E6388D6BC6F61");

	// convert hash to big
	bytes_to_big (32, cHash, bigHash);

	// calculate serial
	// rsa: serial = hash ^ d % n
	powmod (bigHash, bigPrExp, bigModulus, bigSerial);

	// show serial
	otstr (bigSerial, szSerial);
	SetDlgItemTextA (hWnd, EDF_SERIAL, szSerial);

	// miracl cleanup
	mirkill(bigSerial);
	mirkill(bigModulus);
	mirkill(bigPrExp);
	mirkill(bigHash);
	mirexit();
	return;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hWnd, EDF_NAME, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		SendDlgItemMessage (hWnd, EDF_COMPANY, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_COMPANY, "[tnp]");
		break;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:
		case EDF_COMPANY:
			if (HIWORD (wParam) == EN_CHANGE)
			{
				CalculateSerial (hWnd);
			}
			break;

		case BUT_EXIT:			// Exit
			SendMessage (hWnd, WM_CLOSE, 0, 0);
			break;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0);
		break;

	default:
		return DefWindowProc (hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

