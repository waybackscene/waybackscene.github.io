#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include "tiger.c"
#include "tigersboxes.c"
#include "blowfish.c"
#include "sha1.c"

extern procB64encode(long,long,long);
extern modifytigerhash(long);

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	unsigned char bfName[100] = {0};
	unsigned char bfSystemCode[49] = {0};
	unsigned char bfSerial[100] = {0};
	unsigned char x[10];
	long dtLength;
	long tigerhash[6];
	long shahash[5];
	BLOWFISH_CTX blowfish;
	SHA1_CTX sha1;

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:

			__asm{
				lea esi,x
				mov dword ptr [esi],00h
				mov dword ptr [esi+4],095a19207h
				mov word ptr [esi+8],02322h
			}

			dtLength=GetDlgItemText(hWnd, IDC_CODE, &bfSystemCode, 49);

			SHA1Init(&sha1);
			SHA1Update(&sha1, &bfSystemCode, dtLength);
			SHA1Final(&shahash, &sha1);

			// modify sha1 hash
			__asm{
				mov	bl,10
				lea esi,shahash
_loopadd:		mov al,byte ptr [esi+10]
				add byte ptr [esi],al
				inc esi
				dec	bl
				jnz	_loopadd
			}

			// xor sha1 hash with x
			__asm{
				mov	bl,10
				lea esi,shahash
				lea edi,x
_loopxor:		mov	al,byte ptr [esi]
				xor	byte ptr [edi],al
				inc	esi
				inc	edi
				dec	bl
				jnz	_loopxor
			}

			dtLength=GetDlgItemText(hWnd, IDC_NAME, &bfName, 100);

			tiger(&bfName,dtLength,&tigerhash);

			modifytigerhash(&tigerhash);

			Blowfish_Init(&blowfish,&tigerhash,6);

			// convert to big endian
			swapbytes(&x[0]);
			swapbytes(&x[4]);

			Blowfish_Decrypt(&blowfish,&x[0],&x[4]);

			// convert to little endian
			swapbytes(&x[0]);
			swapbytes(&x[4]);

			// xor 2 last bytes
			__asm{
				lea esi,x
				xor	byte ptr [esi+8],067h
				xor byte ptr [esi+9],04fh
			}

			procB64encode(&bfSerial,&x,10);

			SetDlgItemText(hWnd, IDC_SERIAL, &bfSerial);

			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "keygenerator for electric camel crackme\nprotection: tiger, sha-1, blowfish and elgamal", "about", MB_OK);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}

swapbytes(long *value) {
	__asm{
		mov ebx,dword ptr [value]
		mov eax,dword ptr [ebx]
		xchg ah,al
		rol eax,16
		xchg ah,al
		mov dword ptr [ebx],eax
	}
}
