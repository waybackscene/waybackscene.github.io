//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by keygen.rsrc.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON                        103
#define IDC_EDITNAME                    1000
#define IDC_EDITCODE                    1000
#define IDC_EDITUSERNAME                1000
#define IDC_CODE                        1000
#define IDC_EDITSERIAL                  1001
#define IDC_EDITNAME2                   1001
#define IDC_NAME                        1001
#define IDC_ABOUT                       1002
#define IDC_GENERATE                    1003
#define IDC_EDITSERIAL2                 1004
#define IDC_SERIAL                      1004
#define IDC_EDIT2                       1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
