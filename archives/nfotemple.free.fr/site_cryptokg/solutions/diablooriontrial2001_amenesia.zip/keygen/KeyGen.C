/*
 *  
 *   Keygen pour ORION Trial 2001[Hard]  par Amenesia
 *          
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>   


void main()
{  
    char nom[40];
    int tailleNom;
    unsigned char Clef[20]={0};


    miracl *mip=mirsys(50,0);  /* base 0, 50 digits par big  */


    big BigHash   =mirvar(0);
    big modulo    =mirvar(0);
    big D         =mirvar(0);
    big resultat  =mirvar(0);

    mip->IOBASE=16;
    cinstr(D,"C54FA32297BB5458257BEEA22442F8A320963FAD");
    cinstr(modulo,"E8A1276B2AB94FEA3BF1410603600B43E2010A99");


    printf("\t KeyGen [ORION Trial 2001 - HARD] by Amenesia\n");
    printf("\t --------------------------------------------\n");

    printf("Name: \t");
    scanf("%34s",&nom);

   tailleNom = strlen(nom);

   asm{

		xor	eax, eax
		xor	ebx, ebx
		xor	ecx, ecx
		mov	ebx, [tailleNom]
		movzx	eax, [ecx+nom]

        LoopClef:
		imul	eax, 11001100h
		rol	ax, cl
		imul	eax, ebx
		xor	eax, 110011h
		add	eax, 58392831h
		rcl	eax, cl
		and	eax, 5666AAA5h
		xor	dword ptr [Clef], eax
		imul	eax, 0F34526CAh
		rol	ax, cl
		imul	eax, ebx
		xor	eax, 652324h
		add	eax, 98542312h
		rcl	eax, cl
		and	eax, 5666AAA5h
		xor	dword ptr [Clef+4], eax
		imul	eax, 22553355h
		rol	ax, cl
		imul	eax, ebx
		xor	eax, 22BB44h
		add	eax, 23476CACh
		rcl	eax, cl
		and	eax, 5666AAA5h
		xor	dword ptr [Clef+8], eax
		imul	eax, 0AEBCA011h
		rol	ax, cl
		imul	eax, ebx
		xor	eax, 0E475AFh
		add	eax, 54BEA1CAh
		rcl	eax, cl
		and	eax, 5666AAA5h
		xor	dword ptr [Clef+12], eax
		imul	eax, 8F3A3B3Ch
		rol	ax, cl
		imul	eax, ebx
		xor	eax, 0BA3212h
		add	eax, 0CAFECAFEh
		rcl	eax, cl
		and	eax, 5666AAA5h
		xor	dword ptr [Clef+16], eax
		inc	ecx
		movzx	eax, [nom+ecx]
		cmp	eax, 0
		jnz	LoopClef
    }
  
    bytes_to_big(20,Clef,BigHash);     
    powmod(BigHash,D,modulo,resultat);  

    printf("Serial:\t");
    mip->IOBASE=16;
    cotnum(resultat,stdout);

    mirkill(BigHash);
    mirkill(D);
    mirkill(resultat);
    mirkill(modulo);
    mirexit();
}





