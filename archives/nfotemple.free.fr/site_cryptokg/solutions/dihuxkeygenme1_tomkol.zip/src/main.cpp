/*
e=10001
p=970E1A438A10E069571BDCCBB
q=EB3FFE9F5C761995147C7A28B
n=8ACFB4D27CBC8C2024A30C9417BBCA41AF3FC3BD9BDFF97F89
d=32593252229255151794D86C1A09C7AFCC2CCE42D440F55A2D
*/
#include <windows.h>
#include <miracl.h>
#include "resource.h"

HINSTANCE hInst;
unsigned int len;
char uname[25]={0},serial[100]={0};
big c,d,m,n,x;

void generate()
{			miracl *mip=mirsys(200,0);
			mip->IOBASE=16;
			c=mirvar(0);
			d=mirvar(0);
			m=mirvar(0);
			n=mirvar(0);
			x=mirvar(0);
			cinstr(d,"32593252229255151794D86C1A09C7AFCC2CCE42D440F55A2D");
			cinstr(n,"8ACFB4D27CBC8C2024A30C9417BBCA41AF3FC3BD9BDFF97F89");
			cinstr(x,"1337");
			bytes_to_big(len,uname,c);
			multiply(c,x,c);
			powmod(c,d,n,m);
			cotstr(m,serial);
			mirkill(c);
			mirkill(d);
			mirkill(m);
			mirkill(n);
			mirkill(x);
			mirexit();
}

int CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		SendMessage(hWnd,WM_SETICON,0,(LPARAM)LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON1)));
		SendDlgItemMessage(hWnd,IDC_EDIT1,EM_LIMITTEXT,20,0);
		break;
	case WM_CLOSE:
	case WM_DESTROY:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDGEN:
			ZeroMemory(uname,25);
			ZeroMemory(serial,100);
			len=GetDlgItemText(hWnd,IDC_EDIT1,uname,25);
			if (len<5)
			{MessageBox(hWnd,"Name min 5 letters","Error",MB_OK);
			break;}
			generate();
			SetDlgItemText(hWnd,IDC_EDIT2,serial);
			break;
		case IDEXIT:
			PostQuitMessage(1);
			break;
		}
		break;
	}
	return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),0,DlgProc,0);
	return 0;
}