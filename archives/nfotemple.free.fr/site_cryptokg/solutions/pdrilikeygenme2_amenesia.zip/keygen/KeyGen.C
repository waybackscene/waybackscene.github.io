/*
 *  
 *   Keygen pour le Crypto keygenMe #2 de pDriLi par Amenesia  ( compilation: bcc32/Tasm32 )
 *          
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>   



void main()
{  
    char clef_s[20] ="FHCF0";
    char nom[30];
    int i;
    int clef = 0;
    miracl *mip=mirsys(500,16);  /* base 0, 50 digits par big  */


    big clef_b   =mirvar(0);
    big modulo   =mirvar(0);
    big D        =mirvar(0);
    big resultat =mirvar(0);

    mip->IOBASE=16;
    cinstr(D,"3FC69E031A914000E925FC61F2BF888F410EB07D");
    cinstr(modulo,"7E2BDC8ED8856EE745A9D6F93E143B7ACE202999");


    printf("\t KeyGen [pDili KeygenMe #2] par Amenesia\n");
    printf("\t ---------------------------------------\n");

    printf("Nom: \t");
    scanf("%30s",&nom);


     for (i=0; i < strlen(nom);i++)
     {
        clef += nom[i] * 43690;
     }

     sprintf(&(clef_s[5]), "%0x",clef);
     bytes_to_big(strlen(clef_s),clef_s,clef_b);  
     powmod(clef_b,D,modulo,resultat);  


    printf("Serial:\t");
    mip->IOBASE=60;
    cotnum(resultat,stdout);

 

}





