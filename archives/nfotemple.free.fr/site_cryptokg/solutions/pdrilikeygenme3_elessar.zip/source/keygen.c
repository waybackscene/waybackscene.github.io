#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include <miracl.h>

BOOL IsKeyGood(int);
HINSTANCE	hInst;
BOOL CALLBACK DialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{	

	int len,key;
	char username[30];
	char serial_a[50];
	char serial_b[50];
	miracl *mip=mirsys(100,0);
	big a,g,k,p;
	big M,x,kinv;	

	switch (uMsg)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);		
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{	
		case IDC_GENERATE:			

			len = GetDlgItemText(hWnd, IDC_USERNAME, username, 30);
			if(len>0) {
				
				key = (int)rand();
				while(!IsKeyGood(key)) //make sure k is relatively prime to p-1
					key = (int)rand();			
				
				FillMemory(username+len,30-len,'*'); //fills the rest of the username with *'s
				
				a=mirvar(0);
				g=mirvar(0);
				k=mirvar(key);
				p=mirvar(0);
				M=mirvar(0);
				x=mirvar(0);
				kinv=mirvar(0);				

					mip->IOBASE=16;
					cinstr(g,"2E0C2DB4FEC8C6299A0C");
					cinstr(p,"B54F430648C6B2A10FFB");
					powmod(g,k,p,a);//a = g^k mod p
				
					bytes_to_big(30,username,M);
					//re-use of the g variable, this is not g
					cinstr(g,"AC2DB4FEC8C62992DB4F");
					//M = username^2 mod AC2DB4FEC8C62992DB4F
					power(M,2,g,M);

					cinstr(x,"9A0CD8235134E88BEFD0");				
					//from now on we will only use (p-1)
					decr(p,1,p);
					multiply(x,a,x);
					//x = M-x*a
					subtract(M,x,x); 
					//kinv = inverse modulo of k
					xgcd(k,p,kinv,kinv,g);
					//x = kinv * M-x*a
					multiply(x,kinv,x);
					//x = (kinv * M-x*a) mod (p-1)
					power(x,1,p,x);
					//to avoid negative numbers
					add(x,p,x);

					mip->IOBASE=60;

					cotstr(a,serial_a);
					cotstr(x,serial_b);

					SetDlgItemText(hWnd,IDC_SERIAL1,serial_a);
					SetDlgItemText(hWnd,IDC_SERIAL2,serial_b);

				mirkill(kinv);
				mirkill(x);
				mirkill(M);
				mirkill(p);
				mirkill(k);
				mirkill(g);
				mirkill(a);

			}else SetDlgItemText(hWnd,IDC_SERIAL1,"Did you forget something, eh?");
		}//switch (LOWORD(wParam))		
		break;	
	}//switch (uMsg)	
    return 0;
}//DialogProc

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	hInst=hInstance;
	srand( (unsigned)time( NULL ) );	
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}

BOOL IsKeyGood(int key)
{	
	if(igcd(key,2) != 1) return 0;
	if(igcd(key,7) != 1) return 0;
	if(igcd(key,17) != 1) return 0;
	if(igcd(key,137) != 1) return 0;
	if(igcd(key,613) != 1) return 0;
	return 1;
}