/*************************************************************************

 Filename:		Keygen.c
 Purpose:		Keygen for pDriLl's Crypto Keygenme #3
 Author:		figugegl
 Version:		1.0
 Date:			26.6.2003

*************************************************************************/


/*------------------------------------------------------------------------
	Include files
------------------------------------------------------------------------*/
#include <windows.h>
#include <stdio.h>
#include <miracl.h>
#include "keygen.h"


/*------------------------------------------------------------------------
	Prototypes
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc	(HWND, UINT, WPARAM, LPARAM) ;


/*------------------------------------------------------------------------
	Global variables
------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
 Procedure:     WinMain
 Purpose:       Application entry point. Registers a class of the same
                type than the dialog class,calls DialogBox and then exits
 Input:         Standard
 Output:        None
 Errors:        None
------------------------------------------------------------------------*/
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hPrevInst, PSTR szCmdLine, int CmdShow)
{
	static TCHAR	szAppName[] = TEXT ("keygen") ;
	WNDCLASS		wc ;

	// fill and register wndclass-structure
	memset (&wc, 0, sizeof (wc));
	wc.lpfnWndProc		= MainDlgProc;
	wc.cbWndExtra		= DLGWINDOWEXTRA;
	wc.hInstance		= hInst;
	wc.hIcon			= LoadIcon (hInst, MAKEINTRESOURCE (ICO_FIGU));
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground	= (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName	= szAppName;
	RegisterClass (&wc);

	return DialogBoxParamA (hInst, MAKEINTRESOURCE (DLG_MAIN), NULL, (DLGPROC) MainDlgProc, 0);
}


/*------------------------------------------------------------------------
 Procedure:     CalculateSerial
 Purpose:       Calculate a valid serial
                Protection = ElGamal (80bit)
 Input:         hWnd : handle of the dialog window
 Output:        None.
 Errors:        None.
------------------------------------------------------------------------*/
void CalculateSerial (HWND hWnd)
{
	// initialize miracl: 100 digits per big, base 16
	miracl *mip = mirsys (100, 16);

    big     bigA, bigB, bigG, bigX, bigHash, bigP;
    int     i, iStrLen, iVarK;
    char    szName[32] = "", szSerial[16] = ""; // szSerial1[] = "1drmL9dBJgRSLW"; // == 2E0C2DB4FEC8C6299A0Ch base60 encoded

	// get input and check length
	iStrLen = GetDlgItemText (hWnd, EDF_NAME, szName, 32);
	if (iStrLen == 0)
	{
		SetDlgItemText (hWnd, EDF_SERIAL1, NULL);
		SetDlgItemText (hWnd, EDF_SERIAL2, NULL);
		return;
	}

	// adjust namelength
	for (i = iStrLen; i < 30; i++)
		szName[i] = '*';
	iStrLen = i;

	// initialize big numbers
	bigA    = mirvar (0);
	bigB    = mirvar (0);
	bigG    = mirvar (0);
	bigP    = mirvar (0);
	bigX    = mirvar (0);
	bigHash = mirvar (0);

	// bigHash ^ 2 % AC2DB4FEC8C62992DB4Fh
	bytes_to_big (iStrLen, szName, bigHash);
	instr (bigP, "AC2DB4FEC8C62992DB4F");
	power (bigHash, 2, bigP, bigHash);

	// const bignums g, p, x, y
	instr (bigG, "2E0C2DB4FEC8C6299A0C");
	instr (bigP, "B54F430648C6B2A10FFB");
	instr (bigX, "3F6536A02CD18F3B67D3");
//	instr (bigY, "4E0F2ACAD51C4CCDFB51");

	// ElGamal 80bit: hash = (x*a + k*b) % (p-1)
	// a = (g ^ k)     %  p     (with k = 1 --> a = g % p)
	// b = (hash - xa) % (p-1)
	multiply (bigX, bigG, bigX);
	decr (bigP, 1, bigP);
	divide (bigX, bigP, bigP);

	// hash += p if hash < xa
	if (compare (bigHash, bigX) == -1)
		add (bigHash, bigP, bigHash);
	subtract (bigHash, bigX, bigB);
	divide (bigB, bigP, bigP);

	// show serial
	mip->IOBASE = 60;
	iStrLen = cotstr (bigG, szSerial);
	SetDlgItemTextA (hWnd, EDF_SERIAL1, szSerial);
	iStrLen = cotstr (bigB, szSerial);
	SetDlgItemTextA (hWnd, EDF_SERIAL2, szSerial);

	// miracl cleanup
	mirkill (bigA);
	mirkill (bigB);
	mirkill (bigG);
	mirkill (bigP);
	mirkill (bigX);
	mirkill (bigHash);
	mirexit ();
	return;
}


/*------------------------------------------------------------------------
 Procedure:     MainDialogProc
 Purpose:       It handles all messages of the main dialog
 Input:         Standard
 Output:        TRUE if the message was processed
 Errors:        None
------------------------------------------------------------------------*/
LRESULT CALLBACK MainDlgProc (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage (hWnd, EDF_NAME, EM_SETLIMITTEXT, 31, 0);
		SetDlgItemTextA (hWnd, EDF_NAME, "figugegl");
		break;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case EDF_NAME:
			if (HIWORD (wParam) == EN_CHANGE)
				CalculateSerial (hWnd);
			break;

		case BUT_EXIT:			// Exit
			SendMessage (hWnd, WM_CLOSE, 0, 0);
			break;
		}
		break;

	case WM_CLOSE:
		PostQuitMessage (0);
		break;

	default:
		return DefWindowProc (hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

