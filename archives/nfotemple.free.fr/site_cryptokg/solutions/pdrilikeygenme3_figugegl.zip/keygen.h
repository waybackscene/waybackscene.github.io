/* Weditres generated include file. Do NOT edit */
#define	DLG_MAIN	100
#define	EDF_NAME	101
#define	EDF_SERIAL1	102
#define	EDF_SERIAL2	103
#define	BUT_EXIT	104
#define	ICO_FIGU	300
