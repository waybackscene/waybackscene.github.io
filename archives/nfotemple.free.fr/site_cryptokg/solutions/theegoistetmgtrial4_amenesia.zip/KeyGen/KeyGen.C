/*
 *  
 *   Keygen [TMG Official Trial Keygenme No.4] by Amenesia 
 * 
 */

#include <stdio.h>
#include <string.h>
#include <miracl.h>
#include "Hash.asm"



void main()
{  

    miracl *mip=mirsys(100,0); 

    /* -------------- Hash ---------------  */
    unsigned char Name[70] = {0};
    unsigned char Hashbuf[24];
    unsigned char Hash[16];
    int nameLength;

    big HashedName     =mirvar(0);
    big modulo         =mirvar(0);


    /* -------------- Elliptic Curve ---------------  */
    big A   =mirvar(4294967293);
    big B   =mirvar(0);
    big p   =mirvar(0);

    big Ax   =mirvar(0);
    big Ay   =mirvar(0);
    epoint*  pointA = epoint_init();

    big Bx   =mirvar(0);
    big By   =mirvar(0);
    epoint*  pointB = epoint_init();

    epoint*  pointRslt = epoint_init();

    big Serial   =mirvar(0);
    int VCode;


    mip->IOBASE=16;
    cinstr(B,"ADF85458A2BB4A9AAFDC5620273D3CF1D8B9C841");
    cinstr(p,"C90FDAA22168C234C4C6628B80DC1CD129024E1F");

    cinstr(Ax,"1c341c34e32d5ec8f3dc83e7da1a9dac84e26624");
    cinstr(Ay,"902166ccf366300faf8b1cca939c1280e5450f40");

    cinstr(Bx,"5A3884AF3E676F49470F441CBEEBE7C0B1D9DF66");
    cinstr(By,"12C34484F6C34BB886EEE052ACC6247098BEDC3C");
    
    cinstr(modulo,"AB6853BDD1100F57");



    /* -------------- In ---------------  */
    printf("Keygen [TMG Official Trial Keygenme No.4] by Amenesia\n"); 
    printf("-----------------------------------------------------\n"); 
    printf("Nom: \t");
    scanf("%65s",&Name);
    nameLength = strlen(Name);

  
    if (nameLength<5)
        {
          printf("Error: Name size < 5\n");
        }
    else
        {
           asm{

               lea     eax, [Hashbuf]
               push    eax
               call    HashInit
               add     esp, 4

               mov     ecx, [nameLength]
               lea     edx, [Name]
               lea     eax, [Hashbuf]
               push    ecx
               push    edx
               push    eax
               call    HashUpdate
               add     esp, 0Ch

               lea     ecx, [Hashbuf]
               lea     edx, [Hash]
               push    ecx
               push    edx
               call    HashFinal
              }

            bytes_to_big(16,&Hash,HashedName);
            power(HashedName,3,modulo,HashedName);  
    

            ecurve_init(A,B,p,MR_EPOINT_NORMALIZED);
            epoint_set(Bx,By,0,pointB);
            epoint_set(Ax,Ay,0,pointA);

            ecurve_mult(HashedName,pointA,pointRslt);
            ecurve_sub(pointB,pointRslt);
            ecurve_add(pointA,pointA);

            ecurve_sub(pointA,pointRslt);
            VCode = epoint_get(pointRslt,Serial,Serial);


            /* -------------- Out ---------------  */
            printf("VCode %0x\n",VCode);
            printf("Serial:\t");
            mip->IOBASE=16;
            cotnum(Serial,stdout);
        }

    /* -------------- End ---------------  */
    epoint_free(pointA);
    epoint_free(pointB);
    mirkill(HashedName);
    mirkill(modulo);
    mirkill(A);
    mirkill(B);
    mirkill(p);
    mirkill(Ax);
    mirkill(Ay);
    mirkill(Bx);
    mirkill(By);
    mirexit();

}



