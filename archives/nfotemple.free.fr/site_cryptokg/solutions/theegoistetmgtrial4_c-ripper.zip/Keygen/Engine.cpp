#include <Windows.h>
#include <Stdio.h>
#include "Resource.h"
#include "md5.h"
#include "Miracl.h"

BOOL CALLBACK MainWndProc(HWND hWindow, UINT uMsg, WPARAM wParam, LPARAM lParam);

void Generate();

HINSTANCE hInst;
HWND hWnd;

char lpAbout[] = "Cracked by\t: C-ripper / [ORiON]\nProtection\t: EC math";

BOOL CALLBACK MainWndProc(HWND hWindow, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	hWnd = hWindow;

	switch(uMsg)
    {
		case WM_INITDIALOG:
			SetDlgItemText(hWnd,IDC_NAME,"C-ripper / [ORiON]");
			Generate();
			return TRUE;
		
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_GENERATE:
					Generate();
					break;
				case IDC_ABOUT:
					MessageBox(hWnd, lpAbout, "About", MB_OK);
					break;
			}
		return TRUE;

		case WM_CLOSE:
			EndDialog(hWnd, 0);
		return TRUE;
			
		default:
            return FALSE;
    }
    return TRUE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	hInst = hInstance;
	DialogBoxParamA(hInstance, MAKEINTRESOURCE(IDD_MAIN_DLG), 0, MainWndProc, 0);

	return 0;
}

void Generate()
{
	
	char szRegCode[50];
char Temp[4];
unsigned char MD5_bytes[30]="";
char Name[100]="";
char Buffer[50]="";
MD5_CTX MD5;

miracl *mMiracl;
big a,b,c,p,h,t,eP_X,eP_Y,eQ_X,eQ_Y;
epoint *eP,*eQ,*eS;

mMiracl = mirsys(512, 0);

a = mirvar(-3);
b = mirvar(0);
c = mirvar(3);
p = mirvar(0);
h = mirvar(0);
t = mirvar(0);
eP_X = mirvar(0);
eP_Y = mirvar(0);
eQ_X = mirvar(0);
eQ_Y = mirvar(0);

	mMiracl->IOBASE = 16;

	GetDlgItemText(hWnd, IDC_NAME, Name, 100);
	if(strlen(Name)<5)
	{
		SetDlgItemText(hWnd, IDC_REGCODE, "Name must be at least 5 chars");
		return;
	}
	MD5_Init(&MD5);
	MD5_Update(&MD5, (unsigned char*)Name, strlen(Name));
	MD5_Final((unsigned char*)MD5_bytes, &MD5);

	for(int i=0; i<16; i++)
		{
		sprintf(Temp, "%.2X", MD5_bytes[i]&0xFF);
		strcat(Buffer, Temp);
		}

	cinstr(b, "ADF85458A2BB4A9AAFDC5620273D3CF1D8B9C841");
	cinstr(p, "C90FDAA22168C234C4C6628B80DC1CD129024E1F");
	cinstr(t, "AB6853BDD1100F57");
	cinstr(eP_X,"1C341C34E32D5EC8F3DC83E7DA1A9DAC84E26624");
	cinstr(eP_Y,"902166CCF366300FAF8B1CCA939C1280E5450F40");
	cinstr(eQ_X,"5A3884AF3E676F49470F441CBEEBE7C0B1D9DF66");
	cinstr(eQ_Y,"12C34484F6C34BB886EEE052ACC6247098BEDC3C");
	cinstr(h, Buffer);

	powmod(h, c, t, h);	// h = h^3 (mod t )
	ecurve_init(a,b,p,MR_AFFINE);
	eP = epoint_init();
	epoint_set(eP_X,eP_Y,0,eP);
	eQ = epoint_init();
	epoint_set(eQ_X,eQ_Y,1,eQ);
	eS = epoint_init();
	ecurve_mult(h,eP,eS);
	ecurve_sub(eQ,eS);
	ecurve_add(eP,eP);
	ecurve_sub(eP,eS);
	i=epoint_get(eS,eP_X,eP_Y);
	if (i==1) SetDlgItemText(hWnd, IDC_VCODE, "1");
	else SetDlgItemText(hWnd, IDC_VCODE, "0");
	cotstr(eP_X,szRegCode);
	mirkill(a);
	mirkill(b);
	mirkill(c);
	mirkill(h);
	mirkill(p);
	mirkill(t);
	epoint_free(eP);
	epoint_free(eQ);
	epoint_free(eS);
	SetDlgItemText(hWnd, IDC_REGCODE, szRegCode);	
	return;
}