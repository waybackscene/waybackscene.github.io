//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource.rc
//
#define IDD_MAIN_DLG                    101
#define IDI_MAIN_ICN                    102
#define IDC_NAME                        1000
#define IDC_LBL1                        1001
#define IDC_VCODE                       1002
#define IDC_LBL2                        1003
#define IDC_REGCODE                     1004
#define IDC_LBL3                        1005
#define IDC_GENERATE	                1007
#define IDC_ABOUT                       1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
