#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include "md5c.c"

char serial[50];
unsigned char progname[]="unknown.CRACKME-SERiALBRUTER",protection[]="MD5";

BOOL CALLBACK DlgProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{	

	unsigned char hash[32];
	int i;
	MD5_CTX ctx;

	switch (Message)
	{    
	    case WM_CLOSE:
		  EndDialog(hWnd,0);
		break;
		
		case WM_INITDIALOG:
			SetDlgItemText(hWnd,IDC_PROTECTION,protection);
			SetWindowText(hWnd,progname);
			SetDlgItemText(hWnd,IDC_NAME,"solved by dihux");
		break;
	
		
		case WM_LBUTTONDOWN:
			PostMessage(hWnd,WM_NCLBUTTONDOWN,HTCAPTION,lParam);
		break;

	    	case WM_COMMAND:
		   switch (LOWORD(wParam))
		   {		
				case IDC_GENERATE:

					for(i=0;i<0xffffffff;i++){
					MD5Init(&ctx);
					sprintf(serial,"%d",i);
					MD5Update(&ctx,serial,strlen(serial));
					MD5Final(hash,&ctx);
						__asm{
							mov eax,dword ptr [hash+12]
							cmp eax,09668baa5h
							jz ok
						}
					}
ok:
									
					SetDlgItemText(hWnd,IDC_SERIAL,serial);

				break;
				

				case IDC_EXIT:
					EndDialog(hWnd,0);
				break;

				
					}
				
	}
return 0;

}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow)
{
  DialogBox(hInstance, MAKEINTRESOURCE(IDD_DLG), NULL, (DLGPROC)DlgProc);
  return 0;
}
