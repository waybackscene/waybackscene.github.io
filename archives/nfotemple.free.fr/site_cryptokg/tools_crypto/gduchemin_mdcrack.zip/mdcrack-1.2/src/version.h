
#define RELEASE "1.2"
#define NAME "MDcrack"


