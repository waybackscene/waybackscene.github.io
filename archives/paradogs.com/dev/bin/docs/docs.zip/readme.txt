Here are some docs that most of you won't have!!!

The dev-guide has some VERY useful info - including how to use buildcd!!!

The texture cache document is quite rare, it explains how the texture cache
works (another Cat exclusive ehh?)!!!

-Cat!

cat-house@usa.net
www.bigfoot.com/~cat-house
