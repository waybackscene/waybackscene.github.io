/* xasample.c - Playing of .XA at it's most basic, for use in conjunction
*	with the developer conference 98 technical article:
*	'Using .XA In PlayStation Development'
*	
*	NOTES   This sample uses .XA files that have only one channel of audio
*			data.
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	05/06/98	Mike Kav		Created
*/
#include <sys/types.h>
#include <rand.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libsnd.h>
#include <libsn.h>
#include <stdio.h>

// .XA file structure, this example uses two of these
typedef struct {
	char*	filename; 
	int		startpos;
	int		endpos;
} XAFILE;

XAFILE theXAFile[2] =
{
	"\\BREATH.XA;1",	// File name
	0,					// File start position, filled in by CdSearchFile
	0,					// File end position filled in by CdSearchFile
	"\\RE2.XA;1",		// File name
	0,					// File start position, filled in by CdSearchFile
	0,					// File end position filled in by CdSearchFile
};

// CD buffer, don't really need this as we are not interested in the data
// itself coming in
u_char buffer[2340];

// Function Prototypes
void	PlayXAChannel(int startPos,int endpos);
void	cbready(int intr, u_char *result);
CdlCB	PrepareXA(void);
void	UnprepareXA(CdlCB oldCallback);
int		main(void);

int currentPos=0;       // current position of CD
int fileNo=0;           // file number we wish to play

int main(void)
{

	CdlFILE fp;				// CD file details
	CdlCB Oldcallback; 		// keep any old CdCallback 
	int padd	= 0;
	int opadd	= 0;
	int i;		// Pad buffers and loop indexes

	CdInit();
	PadInit(0);
	ResetGraph(0);
	CdSetDebug(0);
	FntLoad(960,256);
	SetDumpFnt(FntOpen(32, 32, 320, 200, 0, 512));

	for(i=0;i<2;i++)
	{
		if(CdSearchFile(&fp,theXAFile[i].filename) == 0)
		{
			printf("%s: not found\n", theXAFile[fileNo].filename);
			return 1;
		}
        // get XA file start position
		theXAFile[i].startpos = CdPosToInt(&fp.pos);

        // get XA file end position, start pos + number of sectors -1
        theXAFile[i].endpos = theXAFile[i].startpos + (fp.size/2048) -1;
	}

// Set up for XA playing
	Oldcallback = PrepareXA();

// main loop ... 
	while (((padd = PadRead(1))&PADk) == 0)
	{
		balls(); // draw some graphics whilst playing XA

// When pressed up on controller play selected sample
		if (opadd == 0 && padd&PADLup)
			PlayXAChannel(theXAFile[fileNo].startpos,theXAFile[fileNo].endpos);

// To cancel sample push down
		if (opadd == 0 && padd&PADLdown)
		{
			CdControlF(CdlPause,0);
			VSync(3);
		}
// toggle between the two files
		if (opadd == 0 && padd&(PADLright|PADLleft))
		{
			fileNo = !fileNo;
		}

// show info...
		FntPrint("\t\t XA-AUDIO TEST\n\n");
		FntPrint("Filename:   %s\n",theXAFile[fileNo].filename);
		FntPrint("StartPos:   %d\n",theXAFile[fileNo].startpos);
		FntPrint("ENDPOS:     %d\n",theXAFile[fileNo].endpos);
		FntPrint("CURRENTPOS: %d\n",currentPos);
		FntPrint("\n~c444CD Status:~c888%x",CdStatus());
		FntFlush(-1);

		opadd = padd;
	}

// stop the CD-ROM when quitting
	UnprepareXA(Oldcallback);

// shut down...
	CdSync(0, 0);
	StopCallback();
	PadStop();

	return(0);	
}

/*
*
*       NAME            void PlayXAChannel(int startPos, int endpos)
*
*       FUNCTION        Plays channel zero of an .XA file
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void PlayXAChannel(int startPos, int endpos)
{

	CdlLOC  loc;
	CdlFILTER theFilter;

    // set volume to max
    SsSetSerialVol(SS_SERIAL_A,127,127);

	// set up .XA filter
	theFilter.file=1;
	theFilter.chan=0;
	CdControlF(CdlSetfilter, (u_char *)&theFilter);

	// Starting position on CD
	CdIntToPos(startPos, &loc);
	currentPos=startPos;

	// begin playing
	CdControlF(CdlReadS, (u_char *)&loc);

	return;
}


/*
*
*       NAME            CdlCB PrepareXA(void)
*
*       FUNCTION        Set CD mode and hook in callback for XA playing
*
*       NOTES           Returns the current callback if required
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
CdlCB PrepareXA(void)
{
	u_char param[4];

// setup for XA playback
	param[0] = CdlModeSpeed|CdlModeRT|CdlModeSF|CdlModeSize1;
	CdControlB(CdlSetmode, param, 0);
	CdControlF(CdlPause,0);

	return CdReadyCallback((CdlCB)cbready);
}

/*
*
*       NAME            void UnprepareXA(CdlCB oldCallback)
*
*       FUNCTION        Sets the CD back to double speed mode
*						ready for reading data
*
*       NOTES           Returns the current callback if required
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void UnprepareXA(CdlCB oldCallback)
{
	u_char param[4];

// Reset any Callback that we replaced
	CdControlF(CdlPause,0);
	CdReadyCallback((void *)oldCallback);

// clear XA mode
	param[0] = CdlModeSpeed;
	CdControlB(CdlSetmode, param, 0);

	return;
}

/*
*
*       NAME            void cbready(int intr, u_char *result)
*
*       FUNCTION        Callback used to monitor when to stop
*						playing the .XA channel
*
*       NOTES           With one channel .XA files the data callback
*						will occur at least 7 times for every one
*						audio sector
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void cbready(int intr, u_char *result)
{

	if (intr == CdlDataReady)
	{
		CdGetSector((u_long*)buffer,585);
		currentPos = CdPosToInt((CdlLOC *)buffer);
		if(currentPos >= theXAFile[fileNo].endpos)
		{
		        SsSetSerialVol(SS_SERIAL_A,0,0);
		        CdControlF(CdlPause,0);
		}
	}
	else
		FntPrint("UnHandled Callback Occured\n");	
}