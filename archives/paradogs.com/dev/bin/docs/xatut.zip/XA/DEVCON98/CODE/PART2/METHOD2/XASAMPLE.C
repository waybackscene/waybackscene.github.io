/* xasample.c - Playing of multi channel .XA, for use in conjunction
*	with the developer conference 98 technical article:
*	'Using .XA In PlayStation Development' Part 2 Method 2
*	
*	NOTES   This sample uses .XA files that have all the available
*			multiple channels filled with audio data.
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	05/06/98	Mike Kav		Created
*/
#include <sys/types.h>
#include <rand.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libsnd.h>
#include <libsn.h>
#include <stdio.h>

// .XA file structure
#define NUMCHANNELS 8

typedef struct {
	char*	filename; 
	int		startpos;
	int		endpos;
	char*	channelName[NUMCHANNELS];
} XAFILE;

XAFILE theXAFile[0] =
{
	"\\8TUNES.XA;1",			// File name
	0,							// File start position, filled in by CdSearchFile
	0,							// File end position filled in by CdSearchFile
	"PRODIGY    - BREATH",		// channel description, not needed for playing the .XA
	"LEFTFIELD  - OPEN UP",		// channel description, not needed for playing the .XA
	"ORBITAL    - SATAN",		// channel description, not needed for playing the .XA
	"UNDERWORLD - BORN SLIPPY",	// channel description, not needed for playing the .XA
	"PRODIGY    - BREATH",		// channel description, not needed for playing the .XA
	"LEFTFIELD  - OPEN UP",		// channel description, not needed for playing the .XA
	"ORBITAL    - SATAN",		// channel description, not needed for playing the .XA
	"UNDERWORLD - BORN SLIPPY",	// channel description, not needed for playing the .XA
};

// CD buffer, don't really need this as we are not interested in the data
// itself coming in
u_char buffer[2340];
u_long *cAddress=(u_long *)&buffer[0];

// Function Prototypes
void	PlayXAChannel(int channel, int startPos, int endpos);
void	cbready(int intr, u_char *result);
CdlCB	PrepareXA(void);
void	UnprepareXA(CdlCB oldCallback);
int		main(void);

int currentPos=0;       // current position of CD
int fileNo=0;           // file number we wish to play

int currentChannel;		// Channel number of video header
int ID;					// ID of sector, 352 for video
int gChannel;			// Channel number we are currently playing

int main(void)
{

	CdlFILE fp;				// CD file details
	CdlCB Oldcallback; 		// keep any old CdCallback 
	int padd			= 0;
	int opadd			= 0;
	int channelNumber	= 0;
	int i				= 0;

	CdInit();
	PadInit(0);
	ResetGraph(0);
	CdSetDebug(0);
	FntLoad(960,256);
	SetDumpFnt(FntOpen(32, 32, 320, 200, 0, 512));

		if(CdSearchFile(&fp,theXAFile[0].filename) == 0)
		{
			printf("%s: not found\n", theXAFile[0].filename);
			return 1;
		}
        // get XA file start position
		theXAFile[0].startpos = CdPosToInt(&fp.pos);

        // get XA file end position, start pos + number of sectors -1
        theXAFile[0].endpos = theXAFile[0].startpos + (fp.size/2048) -1;

// Set up for XA playing
	Oldcallback = PrepareXA();

// main loop ... 
	while (((padd = PadRead(1))&PADk) == 0)
	{
		balls(); // draw some graphics whilst playing XA

// When pressed up on controller play selected sample
		if (opadd == 0 && padd&PADLup)
			PlayXAChannel(channelNumber,theXAFile[fileNo].startpos,theXAFile[fileNo].endpos);

// To cancel sample push down
		if (opadd == 0 && padd&PADLdown)
		{
			CdControlF(CdlPause,0);
			VSync(3);
		}
// toggle between the channels
		if (opadd == 0 && padd&PADLright)
		{
			channelNumber=(channelNumber+1)%NUMCHANNELS;
		}

		else if (opadd == 0 && padd&PADLleft)
		{
			channelNumber=(channelNumber+(NUMCHANNELS-1))%NUMCHANNELS;
		}

// show info...
		FntPrint("\t\t XA-AUDIO TEST\n\n");
		FntPrint("Filename:   %s\n",theXAFile[fileNo].filename);
		for(i=0;i<NUMCHANNELS;i++)
			FntPrint("Channel  %2d %s\n",i,theXAFile[0].channelName[i]);
		FntPrint("StartPos:   %d\n",theXAFile[fileNo].startpos);
		FntPrint("ENDPOS:     %d\n",theXAFile[fileNo].endpos);
		FntPrint("\nchannel=");
		for (i=0; i<NUMCHANNELS; i++)
			FntPrint("~c%s%d",(i==channelNumber) ? "888":"444", i);
		FntPrint("\n~c444CD Status:~c888%x",CdStatus());
		FntFlush(-1);

		opadd = padd;
	}

// stop the CD-ROM when quitting
	UnprepareXA(Oldcallback);

// shut down...
	CdSync(0, 0);
	StopCallback();
	PadStop();

	return(0);	
}

/*
*
*       NAME            void PlayXAChannel(int startPos, int endpos)
*
*       FUNCTION        Plays channel zero of an .XA file
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void PlayXAChannel(int channelNum, int startPos, int endpos)
{

	CdlLOC  loc;
	CdlFILTER theFilter;

    // set volume to max
    SsSetSerialVol(SS_SERIAL_A,127,127);

	// set up .XA filter
	theFilter.file=1;
	theFilter.chan=channelNum;
	gChannel=channelNum;
	CdControlF(CdlSetfilter, (u_char *)&theFilter);

	// Starting position on CD
	CdIntToPos(startPos, &loc);
	currentPos=startPos;

	// begin playing
	CdControlF(CdlReadS, (u_char *)&loc);

	return;
}


/*
*
*       NAME            CdlCB PrepareXA(void)
*
*       FUNCTION        Set CD mode and hook in callback for XA playing
*
*       NOTES           Returns the current callback if required
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
CdlCB PrepareXA(void)
{
	u_char param[4];

// setup for XA playback
	param[0] = CdlModeSpeed|CdlModeRT|CdlModeSF|CdlModeSize1;
	CdControlB(CdlSetmode, param, 0);
	CdControlF(CdlPause,0);

	return CdReadyCallback((CdlCB)cbready);
}

/*
*
*       NAME            void UnprepareXA(CdlCB oldCallback)
*
*       FUNCTION        Sets the CD back to double speed mode
*						ready for reading data
*
*       NOTES           Returns the current callback if required
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void UnprepareXA(CdlCB oldCallback)
{
	u_char param[4];

// Reset any Callback that we replaced
	CdControlF(CdlPause,0);
	CdReadyCallback((void *)oldCallback);

// clear XA mode
	param[0] = CdlModeSpeed;
	CdControlB(CdlSetmode, param, 0);

	return;
}

/*
*
*       NAME            void cbready(int intr, u_char *result)
*
*       FUNCTION        Callback used to monitor when to stop
*						playing the .XA channel
*
*       NOTES           With one channel .XA files the data callback
*						will occur at least 7 times for every one
*						audio sector
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/06/98        Mike Kav        Created
*
*/
void cbready(int intr, u_char *result)
{

	if (intr == CdlDataReady)
	{

		CdGetSector((u_long *)buffer,8);

//                ID = *(unsigned short *)(buffer+3);
		ID = *(unsigned short *)(cAddress+3);
		// video sector channel number format = 1CCCCC0000000001
		currentChannel = *((unsigned short *)(cAddress+3)+1);
		currentChannel = (currentChannel&31744)>>10;

		// If this is a video sector then check that this is the channel
	 	// you want then stop playing the .XA sample
		if( (ID == 352) && (currentChannel == gChannel) )
		{
		        CdControlF(CdlPause,0);
		        SsSetSerialVol(SS_SERIAL_A,0,0);
		}
	}
	else
		FntPrint("UnHandled Callback Occured\n");	
}
