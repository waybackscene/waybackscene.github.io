/* Code demonstrating use of playing XA samples.
*
*	This sample requires the .XA to contain a data channel to track the current
*	file position.
*
*	CONTROLS
*			LEFT/RIGHT    - SELECT XA CHANNEL
*			LEFT/RIGHT    - SELECT XA CHANNEL
*			L1            - PLAY CHANNEL FROM\n\t\t\t\tSTARTPOS
*			L2            - STOP PLAY
*			R1            - PLAY CHANNEL FROM\n\t\t\t\tSECTOR NUM
*			R2            - STOP PLAY\n");
*			SQUARE/CIRCLE - MOVE SECTOR NUM DIGIT
*			TRIANGLE      - SECTOR NUM DIGIT++
*
*	NOTES   
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	11/10/98	Mike Kav		Created
*
*/									

#include <sys/types.h>
#include <stdio.h>
#include <rand.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libsn.h>
#include <kernel.h>
#include "xaplay.h"
#include "balls.h"

CdlLOC startpos;						// Used for displaying file's position
CdlLOC stoppos;							// Used for displaying file's position and for playing whole .XA track
CdlLOC currentpos;						// Used for displaying current position
CdlLOC startCalcPos;
CdlLOC stopCalcPos;

XAFILE theXAFile =
{
        "\\TEST.XA;1",               // File name
//        "\\TRACK1.IXA;1",               // File name
	0,				   		// File start position, filled in by CdSearchFile
	0,				   		// File stop position, filled in by CdSearchFile
	0,						// current position
    {
    	"",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	    "",						// Channel Description
	}
};

// function prototypes
int power(int base, int exponent);

#define	START 0
#define STOP 1
#define DIGITS 6

int sectorMode = START;

int main(void)
{
	int		startSectorNum	=0;
	int		stopSectorNum	=0;
	int		startSectorDisplay[6] = { 0,0,0,0,0,0 };
	int		stopSectorDisplay[6] = { 0,0,0,0,0,0 };
	int		channelNo=0;	// Channel number we wish to play
	CdlFILE	fp;				// .XA file details
	CdlCB	Oldcallback; 	// used keep any old CdCallback 
	int		padd = 0;		// Pad buffer handling
	int		opadd = 0;		// Pad buffer handling
	int 	i = 0;			// loop index
	int		temp;
	int		numberHighlight	=0;

	CdInit();
	PadInit(0);
	ResetGraph(0);
	SetVideoMode(MODE_PAL);
	CdSetDebug(0);
	FntLoad(960,256);
	SetDumpFnt(FntOpen(16, 16, 320, 256, 0, 800));

	if(CdSearchFile(&fp, theXAFile.filename) == 0)
	{
		printf("%s: not found\n", theXAFile.filename);
		return 1;
	}
	else
	{
		printf("%s: found\n", theXAFile.filename);
		// calculate end file position (size of file divided by data sector size)
		theXAFile.stoppos = (fp.size/2048);
	}

	theXAFile.startpos	= CdPosToInt(&fp.pos);
	startSectorNum		= theXAFile.startpos;
	stopSectorNum		= theXAFile.startpos;

	CdIntToPos(theXAFile.startpos,&startpos);
	CdIntToPos(theXAFile.stoppos,&stoppos);

	// set up the display sector number
	temp = startSectorNum;
	for(i=0;i<DIGITS;i++)
	{
		startSectorDisplay[i] = temp%10;
		stopSectorDisplay[i] = temp%10;
		temp /=10;
	}

//	Set up for XA playing
	Oldcallback = PrepareXA();

//	main loop ...
	while (((padd = PadRead(1))&PADk) == 0)
	{
		balls(); // draw some graphics whilst playing XA

//	Select other channels
		if (opadd == 0 && padd&(PADLright|PADLleft))
		{
			channelNo = (padd&PADLright)?(channelNo+1)%NUMCHANNELS:(channelNo+(NUMCHANNELS-1))%NUMCHANNELS;
		}

//	When pressed L1 on controller play selected sample from start of file to end
		if (opadd == 0 && padd&PADL1)
			PlayXAChannel(theXAFile.startpos,theXAFile.stoppos,channelNo);
//	To cancel sample push L2
		if (opadd == 0 && padd&PADL2)
			StopXAChannel();

//	Play sample from Start sector to Stop Sector
		if (opadd == 0 && padd&PADR1)
			PlayXAChannel(startSectorNum,stopSectorNum,channelNo);
		if (opadd == 0 && padd&PADR2)
			StopXAChannel();

//	Increment highlighted digit
		if (opadd == 0 && padd&PADRup)
		{
			// loop from 0-9 for each digit
			if(sectorMode==START)
			{
				if(startSectorDisplay[numberHighlight] == 9)
				{
					startSectorDisplay[numberHighlight] = 0;
					startSectorNum -=(9*power(10,numberHighlight));
				}
				else
				{
					startSectorDisplay[numberHighlight]++;
					startSectorNum += power(10,numberHighlight);
				}

				CdIntToPos(startSectorNum,&startCalcPos);
			}
			else
			{
				if(stopSectorDisplay[numberHighlight] == 9)
				{
					stopSectorDisplay[numberHighlight] = 0;
					stopSectorNum -=(9*power(10,numberHighlight));
				}
				else
				{
					stopSectorDisplay[numberHighlight]++;
					stopSectorNum += power(10,numberHighlight);
				}

				CdIntToPos(stopSectorNum,&stopCalcPos);
			}
		}
		else if (opadd == 0 && padd&PADRdown)
		{
			// loop from 0-9 for each digit
			if(sectorMode==START)
			{
				if(startSectorDisplay[numberHighlight] == 0)
				{
					startSectorDisplay[numberHighlight] = 9;
					startSectorNum +=(9*power(10,numberHighlight));
				}
				else
				{
					startSectorDisplay[numberHighlight]--;
					startSectorNum -= power(10,numberHighlight);
				}

				CdIntToPos(startSectorNum,&startCalcPos);
			}
			else
			{
				if(stopSectorDisplay[numberHighlight] == 0)
				{
					stopSectorDisplay[numberHighlight] = 9;
					stopSectorNum +=(9*power(10,numberHighlight));
				}
				else
				{
					stopSectorDisplay[numberHighlight]--;
					stopSectorNum -= power(10,numberHighlight);
				}

				CdIntToPos(stopSectorNum,&stopCalcPos);
			}
		}

//	Move highlighted digit left/right 
		if (opadd == 0 && padd&(PADRleft))
		{
			if((numberHighlight+1)==DIGITS)
			{
				// switch to stop sector values
				if(sectorMode==STOP)
				{
					sectorMode=START;
				}
				else
				{
					sectorMode=STOP;
				}
			}
			numberHighlight = (numberHighlight+1)%DIGITS;
		}

		if (opadd == 0 && padd&(PADRright))
		{
			if(numberHighlight == 0)
			{
				if(sectorMode==STOP)
				{
					sectorMode=START;
				}
				else
				{
					sectorMode=STOP;
				}
			}

			numberHighlight = (numberHighlight+(DIGITS-1))%DIGITS;
		}

// show info...
		FntPrint("\t\tXA-AUDIO TEST\n");
// file details
//		FntPrint("Filename:%s\nStartPos:%d\n",theXAFile.filename,theXAFile.startpos);
//		for(i=0;i<NUMCHANNELS;i++)
//		{
//			FntPrint("Channel  %2d %s\n",i,theXAFile.channelName[i]);
//		}

		FntPrint("\nchannel=");
		for (i = 0; i < NUMCHANNELS; i++)
			FntPrint("~c%s%d",i==channelNo? "888":"444", i);

		FntPrint("\n~c444CD Status:~c888%x\n",CdStatus());
		FntPrint("Playing=%d",PlayingXA());

		// cnt and datacnt defined in xaplay.c
		FntPrint("\nCDCALLBACKS:%d,DATACALLBACKS:%d\n",cnt,datacnt);

		FntPrint("\nStartPos  :%6d",theXAFile.startpos);
		FntPrint(" :%2x,%2x,%2x\n",startpos.minute,startpos.second,startpos.sector);

		FntPrint("StopPos   :%6d",theXAFile.stoppos);
		FntPrint(" :%2x,%2x,%2x\n",stoppos.minute,stoppos.second,stoppos.sector);

		FntPrint("\nCurrentPos:%6d",theXAFile.currentpos);
		CdIntToPos(theXAFile.currentpos,&currentpos);
		FntPrint(" :%2x,%2x,%2x\n",currentpos.minute,currentpos.second,currentpos.sector);

		FntPrint("\n~c444Start Sec:");
		for(i=(DIGITS-1);i>-1;i--)
			FntPrint("~c%s%d~c444",((i==numberHighlight)&&(sectorMode==START))? "888":"444",startSectorDisplay[i]);

		FntPrint(" Stop Sec:");
		for(i=(DIGITS-1);i>-1;i--)
			FntPrint("~c%s%d",((i==numberHighlight)&&(sectorMode==STOP))? "888":"444",stopSectorDisplay[i]);

		FntPrint("\n~c888START SECTOR:%6d : %2x,%2x,%2x\n",startSectorNum,startCalcPos.minute,startCalcPos.second,startCalcPos.sector);
		FntPrint("STOP SECTOR :%6d : %2x,%2x,%2x\n",stopSectorNum,stopCalcPos.minute,stopCalcPos.second,stopCalcPos.sector);

		FntPrint("\n~c888CONTROLS:\n");
		FntPrint("LEFT/RIGHT    - SELECT XA CHANNEL\n");
		FntPrint("L1            - PLAY CHANNEL FROM\n\t\t\t\tSTARTPOS\n");
		FntPrint("L2            - STOP PLAY\n");
		FntPrint("R1            - PLAY CHANNEL FROM\n\t\t\t\tSECTOR NUM\n");
		FntPrint("R2            - STOP PLAY\n");
		FntPrint("SQUARE/CIRCLE - MOVE SECTOR NUM DIGIT\n");
		FntPrint("TRIANGLE      - SECTOR NUM DIGIT++");

		FntFlush(-1);
		opadd = padd;
		pollhost();

	}

// reset from .XA playback, set back to double speed data reading
	UnprepareXA(Oldcallback);
// shut down...
	CdSync(0, 0);
	StopCallback();
	PadStop();

	return(0);
}

/*
*
*       NAME            int power(int base, int exponent)
*
*       FUNCTION        So we don't need libmath included
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
int power(int base, int exponent)
{
	int ret,i;

	ret = 1;
	for(i = 1; i <= exponent; ++i) {
		ret *= base;
	}
	return ret;
}

