/* Controlling code for .XA playback routines
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	07/12/98	Mike Kav		Created
*
*/									
#include <sys/types.h>
#include <rand.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libsn.h>
#include <kernel.h>
#include "xaplay.h"

// Global Variables
int		gPlayingXA;						// flag to test to see if .XA is currently playing
int		gStopPos;						// position for stopping case
u_char	gbuffer[2336];
u_long	*cAddress = (u_long*)gbuffer;	// buffer to read CD data into to get current sector number
int		errflag=0;						// increments when CD callback returns anything other than CdlDataReady
extern	XAFILE theXAFile;

/*
*
*       NAME            void PlayXAChannel(int startPos,int stopPos,int channel)
*
*       FUNCTION        Plays .XA channel from start to stop positions passed in
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
void PlayXAChannel(int startPos,int stopPos,int channel)
{
	CdlLOC		loc;
	CdlFILTER	theFilter;

	gPlayingXA = 1;

	theFilter.file=1;
	theFilter.chan=channel;

	gStopPos = stopPos;
	// Note: If you are using buildcd less than v2.43 then you have to use the following 
	// theFilter.file=0;
	// theFilter.chan=channel+1;
	CdControlF(CdlDemute,0);

//	printf("File:%d,Channel:%d.\n",theFilter.file,theFilter.chan);
	CdControlF(CdlSetfilter, (u_char *)&theFilter);
	CdIntToPos(startPos, &loc);
//	printf("%d,%d,%d,%d,%d\n",startPos,loc.minute,loc.second,loc.sector,loc.track);
	CdControlF(CdlReadS, (u_char *)&loc);
	return;
}

/*
*
*       NAME            void StopXAChannel(void)
*
*       FUNCTION        Stops .XA channel if it is playing
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
void StopXAChannel(void)
{
	if(PlayingXA())
	{	
		CdControlF(CdlMute,0);
		CdControlF(CdlPause,0);
		gPlayingXA = 0;
	}
	return;
}

/*
*
*       NAME            CdlCB PrepareXA(void)
*
*       FUNCTION        Initialises .XA playback
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
CdlCB PrepareXA(void)
{
	u_char param[4];

	// setup for XA playback...
	param[0] = CdlModeSpeed|CdlModeRT|CdlModeSF|CdlModeSize1;
	CdControlB(CdlSetmode, param, 0);
	CdControlF(CdlPause,0);
	gPlayingXA = 0;
	CdDataCallback(DataReadyCallBackFunc);

	return CdReadyCallback((CdlCB)CdReadyCallBackFunc);
}

/*
*
*       NAME            void UnprepareXA(CdlCB oldCallback)
*
*       FUNCTION        Resets Cd system to usual data reading
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
void UnprepareXA(CdlCB oldCallback)
{
	u_char param[4];

	CdControlF(CdlDemute,0);
	// Reset any Callback that we replaced
	CdReadyCallback((void *)oldCallback);
	CdControlF(CdlPause,0);

	param[0] = CdlModeSpeed;
	CdControlB(CdlSetmode, param, 0);
	return;
}

/*
*
*       NAME            int PlayingXA(void)
*
*       FUNCTION        Returns whether .XA is playing or not
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
int PlayingXA(void)
{
        return gPlayingXA;
}

/*
*
*       NAME            void CdReadyCallBackFunc(int intr, u_char *result)
*
*       FUNCTION        CD callback occurs only when data sector read, when
*						this happens read sector into buffer to get current position
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       07/12/98        Mike Kav        Created
*
*/
void CdReadyCallBackFunc(int intr, u_char *result)
{

	if (intr == CdlDataReady)
	{
		CdGetSector(cAddress,584);
		cnt++;
	}
	else
		errflag++;
}


void DataReadyCallBackFunc(void)
{
	theXAFile.currentpos = (CdPosToInt( (CdlLOC *)cAddress));
	datacnt++;

// check for end of sample
				if((theXAFile.currentpos > gStopPos)||(theXAFile.currentpos < theXAFile.startpos))
				{
					StopXAChannel();
				}
        return;
}
