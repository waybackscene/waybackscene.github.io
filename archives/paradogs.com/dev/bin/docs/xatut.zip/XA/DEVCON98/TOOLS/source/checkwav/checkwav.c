/*
	CheckWav.exe
	Program to display .WAV file properties

  Notes:
	.WAV file headers contain the amount of sample data they use,
	some programs add their own specific information at the end of
	the file, such as copyright holder.

WAVE header information
=======================
Description			Size (bytes) - Data Type (Windows)	Usual contents
"RIFF" file
description header	4 bytes - FOURCC					The ascii text string "RIFF".
														mmsystem.h provides the macro
														FOURCC_RIFF for this purpose
size of file		4 bytes - DWORD						The file size LESS the size of
														the "RIFF" description (4 bytes)
														and the size of file description
														(4 bytes). This is usually file
														size - 8
"WAVE" description
header				4 bytes - FOURCC					The ascii text string "WAVE".
"fmt " description
header				4 bytes - FOURCC					The ascii text string "fmt "
														(note the trailing space).
size of WAVE
section chunk		4 bytes - DWORD						The size of the WAVE type format
														(2 bytes) + mono/stereo flag (2
														bytes) + sample rate (4 bytes) +
														bytes/sec (4 bytes) + block
														alignment (2 bytes) + bits/sample
														(2 bytes). This is usually 16 (or
														0x10)
WAVE type format	2 bytes - WORD						Type of WAVE format. This is a
														PCM header, or a value of 0x01
mono/stereo			2 bytes - WORD						mono (0x01) or stereo (0x02)
sample rate			4 bytes - DWORD						Sample rate
bytes/sec			4 bytes - DWORD						Bytes/Sample
Block alignment		2 bytes - WORD						Block alignment
Bits/sample			2 bytes - WORD						Bits/Sample
"data" description
header				4 bytes - FOURCC					The ascii text string "data".
size of data chunk	4 bytes - DWORD						Number of bytes of data is
														included in the data section
Data				Unspecified data buffer				Actual sample data.

  Usage:
	CheckWav <input file>
*/

#include <stdio.h>
#include <string.h>
#include <io.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <windows.h>

#define WAVE_HEADER 44

unsigned char	loadbuf[WAVE_HEADER];
unsigned long	*cAddress = (unsigned long *)loadbuf;	// used to get buffer details
FILE			*in;
DWORD			inFileSize;

int		main(int argc, char *argv[]);
void	CheckWav(void);
void	CloseFiles(void);

int main (int argc, char *argv[])
{
	struct _finddata_t c_file;
    long hFile;

	// parse arguments
	if(argc!=2)
	{
		printf("** CheckWav Version 1.0                                                 **\n");
		printf("** Author: Mike Kavallierou                                             **\n");
		printf("**                                                                      **\n");
		printf("** Usage:                                                               **\n");
		printf("**       CheckWav <infile>                                              **\n");
		printf("**                                                                      **\n");
		printf("** Displays .WAV file properties                                        **\n\n");
		return 0;
	}
	
	// Check file and ensure that it exists
	if( (hFile = _findfirst( argv[1], &c_file )) == -1L )
	{
		printf( "File (%s) Not Found, Quitting\n",argv[1]);
		return 0;
	}
	else
		printf( "File (%s) Found..\n",argv[1]);

	// store input file size
	inFileSize = c_file.size;

	// open all files
	if(!(in = fopen(argv[1], "rb")))
	{
		printf("Error Opening argv[1]\n");
		return 1;
	}

	CheckWav();
	CloseFiles();

	return 0;
}

/*
*
*       NAME            int CheckWav(void)
*
*       FUNCTION        Displays .WAV file properties
*
*       NOTES           
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       26/11/98        Mike Kav        Created
*
*/
void CheckWav(void)
{
	char	riffString[5]	= "\0\0\0\0\0";
	char	wavString[5]	= "\0\0\0\0\0";
	char	fmtString[5]	= "\0\0\0\0\0";
	DWORD	size;
	DWORD	wavChunk;
	WORD	wavType;
	WORD	monoStereo;
	DWORD	sampleRate;
	DWORD	bytesSample;
	WORD	blockAlign;
	WORD	bitsSample;
	char	dataString[5] = "\0\0\0\0\0";
	DWORD	dataSize;
	float	mediaLength;

	fread(loadbuf, 1, WAVE_HEADER, in);

	printf("WAV File Properties - File Size:%d\n",inFileSize);
	printf("================================================\n");
	
	strncpy(riffString,(char *)cAddress,4);
	printf("Field 01: Bytes 00-03:%s\tShould be 'RIFF'\n",riffString);

	size=*(DWORD *)(cAddress+1);
	printf("Field 02: Bytes 04-07:%08d\tFile size -8 according to header\n",size);
	
	strncpy(wavString,(char *)(cAddress+2),4);
	printf("Field 03: Bytes 08-11:%s\tShould be 'WAVE'\n",wavString);

	strncpy(fmtString,(char *)(cAddress+3),4);
	printf("Field 04: Bytes 12-15:%s\tShould be 'fmt '\n",fmtString);

	wavChunk=*(DWORD *)(cAddress+4);
	printf("Field 05: Bytes 16-19:%d\tWAV data chunk size (following %d bytes)\n",wavChunk,wavChunk);

	wavType=*(WORD *)(cAddress+5);
	printf("Field 06: Bytes 20-21:%d\t\tWAV type \n",wavType);

	monoStereo=*((WORD *)(cAddress+5)+1);
	printf("Field 07: Bytes 22-23:%d\t\tMono/Stereo (%s)\n",monoStereo,((monoStereo==0x01) ? "Mono" : "Stereo"));

	sampleRate=*(DWORD *)(cAddress+6);
	printf("Field 08: Bytes 24-27:%d\tSample Rate\n",sampleRate);

	bytesSample=*(DWORD *)(cAddress+7);
	printf("Field 09: Bytes 28-31:%d\tBytes/Sample\n",bytesSample);

	blockAlign=*(WORD *)(cAddress+8);
	printf("Field 10: Bytes 32-33:%d\t\tBlock Alignment \n",blockAlign);

	bitsSample=*((WORD *)(cAddress+8)+1);
	printf("Field 11: Bytes 34-35:%02d\tBits/Sample \n",bitsSample);

	strncpy(dataString,(char *)(cAddress+9),4);
	printf("Field 12: Bytes 36-39:%s\tShould be 'data'\n",dataString);

	
	dataSize=*(DWORD *)(cAddress+10);
	printf("Field 13: Bytes 40-43:%08d\tSize Of Data Chunk\n",dataSize);
	printf("================================================\n");
	mediaLength = (float)dataSize/(float)bytesSample;
	printf("Media Length         :%.3f Seconds\n",mediaLength);
	printf("================================================\n");
	dataSize+=44;
	printf("Field 13 + 44 bytes should equal filesize,%d %s %d\n",dataSize,((dataSize==inFileSize) ? "==":"!="),inFileSize);
	
	if(dataSize == inFileSize)
		printf("WAV file size equals reported size in header\n");
	else
		printf("WAV file size does not equal reported size in header,\n\tfile may contain extended information\n");

	return;
}

/*
*
*       NAME            void CloseFiles(void)
*
*       FUNCTION        Closes all files used
*
*       NOTES           
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       26/11/98        Mike Kav        Created
*
*/
void CloseFiles(void)
{
	fclose(in);
	return;
}