/*
	StrLink.exe
	Program to link together two stream files.

  Operation:
	Program checks file1 matches file2 in height / width
	settings, takes final frame number from first file and then
	changes all frame numbers in file2 before linking together

  Can be used for files without audio:
									strlink in in out
	Or with audio
									strlink in in out -a

*/

#include <stdio.h>
#include <string.h>
#include <io.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>

#define DATA_SECTOR	2048
#define XA_SECTOR	2336
#define XA			0
#define DATA		1

int				sectorSize = DATA_SECTOR;
int				strType = DATA;
unsigned char	loadbuf[2336];
unsigned long	*cAddress = (unsigned long *)loadbuf;	// used to get buffer details
unsigned long	lastFrame=0;							// last frame number from first file
FILE			*in1;
FILE			*in2;
FILE			*out;

int		main(int argc, char *argv[]);
int		CheckStr(char *inFile1, char *inFile2);
void	GetLastFrame(void);
void	OutputFile(void);
void	CloseFiles(void);

int main (int argc, char *argv[])
{

	struct _finddata_t c_file;
    long hFile;

	int ctr;

	// parse arguments
	if((argc<4)||(argc>5))
	{
		printf("** StrLink Version 1.0                                                  **\n");
		printf("** Author: Mike Kavallierou                                             **\n");
		printf("**                                                                      **\n");
		printf("** Usage:                                                               **\n");
		printf("**       StrLink <file1> <file2> <file3> [-a]                           **\n");
		printf("**                                                                      **\n");
		printf("** Links two stream files together. Currently the files are checked     **\n");
		printf("** to make sure that they are the same height and width settings        **\n");
		printf("** before linking to produce <file3>. The audio interleave is also      **\n");
		printf("** checked to ensure that the streams match audio propertiesif -a is    **\n");
		printf("** specified                                                            **\n\n");

		return 0;
	}
	

	// Check fourth parameter, if it exists and it's -a then assume the files contain
	// audio and are therefore 2336 bytes per sector and have .XA header
	if(argc==5)
	{
			if(strncmp(argv[4],"-a",2)!=0)
			{
				printf("Invalid Parameter\n");
				return 1;
			}
			else
			{
				// Setup for XA files
				strType		= XA;
				sectorSize	= XA_SECTOR;
			}
	}

	// Check file1 and file2, ensure they exist
	for(ctr=1;ctr<3;ctr++)
	{
		if( (hFile = _findfirst( argv[ctr], &c_file )) == -1L )
		{
			printf( "File (%s) Not Found, Quitting\n",argv[ctr]);
			return 0;
		}
		else
			printf( "File (%s) Found\n",argv[ctr]);


		// Test that .STR file is divisible by 2048 or 2336, if not, have a moan
		if(c_file.size%sectorSize !=0)
		{
			printf("File does not appear to be the correct size (multiple of %d)\n",sectorSize);
			return 0;
		}
	}

	// Check that file 3 doesn't exist
	if( (hFile = _findfirst( argv[3], &c_file )) != -1L )
	{
		printf( "Output File (%s) Found, Quitting\n",argv[3]);
		return 0;
	}
	else
		printf( "Output File (%s) ..\n",argv[3]);

	// open all files
	if(!(in1 = fopen(argv[1], "rb")))
	{
		printf("Error Opening argv[1]\n");
		return 1;
	}
	if(!(in2 = fopen(argv[2], "rb")))
	{
		printf("Error Opening argv[2]\n");
		return 1;
	}

	out = fopen(argv[3], "wb");

	// Check that both input files have same height and width and audio settings
	if(!CheckStr(argv[1],argv[2]))
	{
		CloseFiles();
		_unlink(argv[3]);
		return 1;
	}

	// Get the last frame value and write first file to output
	GetLastFrame();

	// Output second file with modified frame numbers
	OutputFile();

	CloseFiles();

	return 0;
}

/*
*
*       NAME            void CloseFiles(void)
*
*       FUNCTION        Closes all files used
*
*       NOTES           
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       27/10/98        Mike Kav        Created
*
*/
void CloseFiles(void)
{
	fclose(out);
	fclose(in1);
	fclose(in2);
	return;
}

/*
*
*       NAME            int CheckStr(char *inFile1, char *inFile2)
*
*       FUNCTION        Checks input file properties
*
*       NOTES           If the input files don't match then 0 is returned
*						otherwise if the stream properties match then 1 is
*						returned to indicate success
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       27/10/98        Mike Kav        Created
*
*/
int CheckStr(char *inFile1, char *inFile2)
{

	int in1Width,in1Height;
	int in2Width,in2Height;

	if(strType==DATA)
	{
		// check height and width, read in first sector from both input files and test
		fread(loadbuf, 1, DATA_SECTOR, in1);
		in1Width=*(unsigned short *)(cAddress+4);
		in1Height=*((unsigned short *)(cAddress+4)+1);
		printf("Width and Height of %s = %d*%d\n",inFile1,in1Width,in1Height);

		fread(loadbuf, 1, DATA_SECTOR, in2);
		in2Width=*(unsigned short *)(cAddress+4);
		in2Height=*((unsigned short *)(cAddress+4)+1);
		printf("Width and Height of %s = %d*%d\n",inFile2,in2Width,in2Height);

		if( (in1Width!=in2Width) || (in1Height!=in2Height) )
		{
			printf("Movie properties do not match, Quitting\n");
			return 0;
		}
	}
	else
	{
		// check height and width, read in first sector from both input files and test
		fread(loadbuf, 1, XA_SECTOR, in1);
		in1Width=*(unsigned short *)(cAddress+6);
		in1Height=*((unsigned short *)(cAddress+6)+1);
		printf("Width and Height of %s = %d*%d\n",inFile1,in1Width,in1Height);

		fread(loadbuf, 1, XA_SECTOR, in2);
		in2Width=*(unsigned short *)(cAddress+6);
		in2Height=*((unsigned short *)(cAddress+6)+1);
		printf("Width and Height of %s = %d*%d\n",inFile2,in2Width,in2Height);

		if( (in1Width!=in2Width) || (in1Height!=in2Height) )
		{
			printf("Movie properties do not match, Quitting\n");
			return 0;
		}

		// Check audio properties, read in both buffers, and loop until audio sector found
		fseek(in1,0,SEEK_SET);
		fseek(in2,0,SEEK_SET);
		while(fread(loadbuf, 1, XA_SECTOR, in1)!=0)
		{
			// If audio sector
			if(loadbuf[2]&4)
			{
				fread(loadbuf, 1, XA_SECTOR, in2);
				if(loadbuf[2]&4)
				{
					printf("Audio Properties match\n");
					return 1;
				}
				else
				{
					printf("Audio properties do not match, Quitting\n");
					return 0;
				}
			}
			else
				fread(loadbuf, 1, XA_SECTOR, in2);
		}

		printf("Unable to find audio in Stream, Quitting\n");
		return 0;
	}

	return 1;
}


/*
*
*       NAME            void GetLastFrame(void)
*
*       FUNCTION        Gets last frame value from first stream file,
*						whilst writing first file to new file
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       27/10/98        Mike Kav        Created
*
*/
void GetLastFrame(void)
{
		// seek back to start of file
		fseek(in1,0,SEEK_SET);

		// If we are looking at a stream with audio, we need to ensure that
		// we are looking at a video sector and to ignore the .XA subheader information
		if(strType == XA)
		{
			// for each sector, write out to new file, at end get frame number we are on
			while( fread(loadbuf, 1, XA_SECTOR, in1) !=0)
			{
				fwrite(loadbuf,1,XA_SECTOR,out);

				// Check for both video or data bit
				if(loadbuf[2]&2 || loadbuf[2]&8)
				{
					lastFrame=*(cAddress+4);
				}
			}
			

		}
		else
		{
			// for each sector, write out to new file, at end get frame number we are on
			while( fread(loadbuf, 1, DATA_SECTOR, in1) !=0)
			{
				fwrite(loadbuf,1,DATA_SECTOR,out);
			}
			
			lastFrame=*(cAddress+2);
		}
		printf("Got last frame from first file:%d\n",lastFrame);
}

/*
*
*       NAME            void OutputFile(void)
*
*       FUNCTION        appends input file 2 onto output file
*						whilst modifying the frame number accordingly
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       27/10/98        Mike Kav        Created
*
*/
void OutputFile(void)
{
	unsigned long cnt=0;
	unsigned long currentFrame;

	// seek back to start of file
	fseek(in2,0,SEEK_SET);

	// for each sector, append onto new output file.
	// Need to add lastFrame onto frame number, if the sector is an audio
	// sector then do not test the frame count value
	if(strType == XA)
	{
		while( fread(loadbuf, 1, XA_SECTOR, in2) !=0)
		{
			if(loadbuf[2]&2 || loadbuf[2]&8)
			{
				currentFrame = *(cAddress+4);
				if(currentFrame > cnt)
					cnt++;
				*(cAddress+4)=lastFrame+cnt;
			}

			fwrite(loadbuf,1,XA_SECTOR,out);
		}
	}
	else
	{
		while( fread(loadbuf, 1, DATA_SECTOR, in2) !=0)
		{
			currentFrame = *(cAddress+2);
			if(currentFrame > cnt)
				cnt++;
			*(cAddress+2)=lastFrame+cnt;
			fwrite(loadbuf,1,DATA_SECTOR,out);
		}
	}
	return;
}