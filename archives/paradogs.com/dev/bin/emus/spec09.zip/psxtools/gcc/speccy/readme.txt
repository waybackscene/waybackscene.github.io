              _______________________  ____________                       
              \____    __________    \/      _____/                       
       /\       Mb/    \ |    _|/    /    __/_____                        
      /  \  ___ _/      \|    \_     \    \___    | _ _ _ /\              
          \/   _/        \     |\     \     _/    |         \  _|\        
               \_________/_____| \     \____\  ___|          \/ |/        
----------------------------------\_____/----\/-------------------------
                         Speculator v0.9b
      - Sinclair Spectrum Emulator for the Sony Playstation -


December 10th, 1997.

WHAT IT IS:

Speculator is a Sinclair ZX Spectrum emulator for the PSX. It currently emulates 
only the 48K model at full speed.
It was written over a period a two weeks, mainly to test my knowledge of the
playstation's HW registers and as a small tribute to one of the best 8 bit
computers ever made.
Please note that this program does not contain any part of the official developers
libraries (which I don't have BTW... so don't bother asking ;-) , but it was made
"hitting the hardware" directly.
Mainly for this reason, sound emulation is not implemented at the moment, even
though from the spectrum side everything needed to implement sound has already
been coded (i.e. I only need to dig up some more informations on the PSX SPU).
The Z80 core is based on Marat Fayzullin's Z80 portable emulator, heavily
modified to reach a decent speed on the poor 33Mhz R3000. I am actually working
on a complete new Z80 core for the R3000 processor completely written in
assembler... this will probably be available in the next version of Speculator.

Almost everything of the original Spectrum has been emulated, with a few
exceptions :

- A few undocumented behaviours of the Z80 cpu are not emulated yet and this could
lead to a few problems with some games (Sabre Wulf to say one), but of the many
I tried all of them worked flawlessly.

- Hi res color border is not available in this version. I am planning to rewrite
the video display generation to use DMA's instead of handling everything with the
cpu. This should free some cpu time that I'll be able to use to do a few more nice
things I have in mind.

At the moment a complete emulation of one frame of the ZX Spectrum (including
video generation and 69888 cycles of Z80 execution) takes an average of 250 PAL
scan lines (this means that I have about 60 left to do some other stuff).
Unfortunatly some Z80 instructions are relatively slower to execute than others,
so some games in certain situations can increase that value to 290-295 scan lines
(one example of this is Manic Miner, when the air indicator goes to zero after a
level is completed), but this seems to happen only during unusual situations and
doesn't affect gameplay anyway, since the program still runs full frame... so no
need to worry at the moment.

This version of Speculator contains 20 different games in .sna format. I just
picked up some from the ones I used to play when I was younger, so I am not
sure you will like all of them ;-)
Unfortunatly this version doesn't let you use any other game apart those
compiled in. You can of course hack the games directly in the main executable
and replace some you don't like, if you know how to do that.
I was planning to add a PC<->PSX transfer tool to load games directly from your
computer, but had no time, so this will probably be available with the next
release.



WHAT YOU WILL NEED:

. Sony Playstation
. Datel Pro Action Replay with Comm Link interface and cable
. EZ-O-RAY action replay rom replacement (available at http://www.blackbag.org/psx)

It might be possible also to use the emulator by burning a CD with the main
executable file (you will of course need a "chipped" playstation), but this
has not been tested yet.



HOW TO USE IT:

Simply send the program to the PSX as usual (ez run <whatever>) or try to burn a cd
with the emulator (if you do it, please let me know if it works).
When the program is first run, it will "boot" just like a normal Spectrum, leaving
you with the usual "(c)1982 Sinclair Research Ltd" on screen.

At this point you have two choices :

1. Hold down the START button and then press SELECT. A small keyboard will appear.
You can move the flashing square around to select the key you want to press and
simulate a keypress with the X button. This is particulary useful, for example, to
quickly select the kempston joystick and to start a game, without having to redefine
the keyboard.
For example to start "jetpac" after it has been loaded from the main menu, just use
the emulated keyboard to press '4' and then '5', then play as usual with the psx
joypad as a kempston joystick.
If you are feeling really brave, you could also try to write small(?) basic programs
that way. Just don't blame me if you then spend the next 5 years locked in a
madhouse ;-)
BTW, for convenience of use, in this mode other keys on the pad ar mapped to the
spectrum keyboard. These are :

- L1 = CAPS SHIFT
- R1 = SYMBOL SHIFT
- CIRCLE = ENTER
- TRIANGLE = '0'

So, for example, to delete a character in basic, just press L1 + TRIANGLE, or to reach
extended mode, press L1 + R1.


2. Press the SELECT button to reach the main menu. I think all of the voices in the menu
should be self explanatory, so I won't bother telling you about them ;-)
Just a quick note on redefining the keyboard. This option lets you associate a spectrum
key to a pad button. All pad buttons are selectable in this way with the exception of
SELECT. Just move the flashing square to the key you want to link to the pad, press SELECT
once (the square will stop flashing) and then press any pad button.
To go back to the main menu, press SELECT twice.
Most of the games include an option for the Kempston Joystick anyway, so you'll probably
find it easier to just use the simulated keyboard to select it and start the game.



CONCLUSIONS:

This release of the emulator should work fine with most games. I will keep working on it
according to my spare time and interest on the project. If you would like to contribute
to the development of the emulator and you have a good collection of games (preferably
in .sna format) and a CD burner, I wouldn't mind receiving a copy of those so that I can
test Speculator with as much programs as I can.
BTW, I have assumed that all the games I inserted in the emulator are now in the public
domain (they were all downloaded from several 'official' sites, and I have seen ads for
public domain CDs with 3000 or so spectrum games).
If you own the rights of any program currently in the emulator, just send me an email
telling me if you would like to have it removed or if you would like to have your
copyright notice added somewhere.

I would like to thank all the people around that gave me the inspiration to work on such
a project, expecially to all the guys that are currently working on the PSX.
Greetz in alphabetical order go to : DANZiG, Ez-O-Ray (Snake & McBain), Hitmen/PSX, Nagra
and all the guys in #psxdev.
Some special greetings to all the good ol'guys from the Amiga scene we all miss so much
and to all The Roncler Gang's friends and members around the globe.

Feel free to contact me should you want to discuss anything technical on the PSX. Just
don't email me asking for new versions of the emulator or development kits (which, as I
have already stated, don't have and wouldn't give away if I had).

Take care...
The Roncler Gang

---
Gabriele Roncolato.
Email: ronco@mmm.it
