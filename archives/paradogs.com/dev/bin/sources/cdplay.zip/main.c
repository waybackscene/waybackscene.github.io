/**
	this is a VERY simple cd  player
	I made it simple so that you can see just how easy it is to play a cd
	just copy the technique for playing cd tracks, but implement your own cd player
*/

#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libsnd.h>
#include <libcd.h>
#include "pad.h"

#define OT_LENGTH	10                    // depth of OT
GsOT myOT[2];
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];

#define PACKETMAX	300
PACKET GPUPacketArea[2][PACKETMAX*24];

#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT	240

int cdVol=127;
int tracks[99];
int numTracks;
CdlLOC	myLOC;				//this needs tobe a global variable

/******** prototypes **********/
int main(void);
void InitAll(void);
void DisplayAll(int);
int GetTotalTracks(void);

/******* functions ***********/
int main(void) {
	u_long pad, oldPad;				//variable used for reading pad values
	int currentTrack=0, i, activeBuffer;

	ResetCallback();
	
	CdInit();				//inits cd system
	
	numTracks=GetTotalTracks();

	for(i=1; i<100; i++) 			//this sets up an array containing the numbers 1 to 99
		tracks[i-1]=i;			//as a cd can only ever hold 99 tracks at most
	
	SetVideoMode(MODE_PAL);
//	SetVideoMode(MODE_NTSC);
	
	InitAll();
	
	SsSetMVol( 127, 127 );				//sets main vol (left and right channels) vol can be 0 to 127
	SsSetMute(SS_MUTE_OFF);				//make sure mute is not on
	SsSetSerialAttr(SS_SERIAL_A, SS_MIX, SS_SON);	//sets serial sound attributes (serial_a is music direct from cd player)
	SsSetSerialVol( SS_SERIAL_A, cdVol, cdVol );	//sets serial volume

	CdPlay( 1, tracks, currentTrack);		//plays tracks[currentTrack] of cd

//	printf("\nplaying song: %d\n", tracks[currentTrack]);

	while(1) {
		oldPad=pad;
		pad=PadRead(0);
		
		if (pad&Pad1x) {
			CdPlay( 1, tracks, currentTrack);		//plays currentTrack
		}
		
		if (pad&Pad1crc) {
			CdPlay( 0, tracks, currentTrack);		//stops play
		}
		
		if ((pad&Pad1Left)&&(oldPad!=pad)) {
			if (currentTrack > 0) {
				currentTrack--;
				CdPlay( 1, tracks, currentTrack);		//plays tracks[currentTrack] of cd
			}
		}
		
		if ((pad&Pad1Right)&&(oldPad!=pad)) {
			if (currentTrack < numTracks-1) {
				currentTrack++;
				CdPlay( 1, tracks, currentTrack); //plays tracks[currentTrack] of cd
			}
		}
		
		if ( pad&Pad1Up ) {
			if (cdVol<127) cdVol++;
			SsSetSerialVol( SS_SERIAL_A, cdVol, cdVol ); //sets serial volume
//			printf("Volume=%d\n", cdVol);
		}
		
		if ( pad==Pad1Down ) {
			if (cdVol>1) cdVol--;
			SsSetSerialVol( SS_SERIAL_A, cdVol, cdVol ); //sets serial volume
//			printf("Volume=%d\n", cdVol);
		}
		activeBuffer=GsGetActiveBuff();
		GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);
		GsClearOt(0, 0, &myOT[activeBuffer]);
		FntPrint("playing %d of %d\n",currentTrack+1, numTracks);
		FntPrint("\n\nvolume %d\n",cdVol);
		DisplayAll(activeBuffer);
	}
}//main

void DisplayAll(int activeBuffer) {
	//this method contains all the functions needed to display the contents of the OT
	FntFlush(-1);				//flushes font buffers contents from buffer so that they can be printed to screen
	DrawSync(0);
	//this waits till the GPU has finished drawing, as GsSwapDispBuff will not work correctly if drawing is in progress
	VSync(0);					//gsswapdispbuff should be called after beginning a v-blank
	GsSwapDispBuff();				//swap display buffer
	GsSortClear(0,0,0,&myOT[activeBuffer]);		//clears screen to color (0,0,0) and sorts OT ready for drawing
	GsDrawOt(&myOT[activeBuffer]);			//draws the contents of OT to screen
}

int GetTotalTracks(void) {
	int tracks=0;
	
	printf("about to get toc\n");
	tracks=CdGetToc(&myLOC);
	printf("got toc\n");	
	return tracks;
}

void InitAll(void) {
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 0,0);
	GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
	myOT[0].length=OT_LENGTH;
	myOT[1].length=OT_LENGTH;
	myOT[0].org=myOT_TAG[0];
	myOT[1].org=myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]);
	GsClearOt(0,0,&myOT[1]);
	printf("\ngraphics inited\n");
	
	PadInit(0);

	FntLoad(960, 256);
	FntOpen(10,10,SCREEN_WIDTH-10,SCREEN_HEIGHT-20,0,512);
	SetDispMask(1);  /* start display */
	printf("\nall initialised \n");
}
