making dual shock controllers vibrate - loser

*each pad has two actuators (things that make it vibrate)
*actuator 0 for each pad has an on and an off setting equal to 0 or 1 respectivly
	this is the way the vibration in porsche challenge is done
*actuator 1 for each pad has a setting between 0 and 255, where 0 is off, and 255 is most vibration
	this is the way the vibration was done for tekken 3
(note: you can use both types of vibration at once)