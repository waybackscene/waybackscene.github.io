/* $PSLibId: Runtime Library Release 3.7$ */
/*			tuto0
 *			
 *
 *      GunCode for the Namco and Konami Guns.
 *              Author: Kevin Thompson.
 *              Date 2/4/97.
 *
 *		Copyright (C) 1994 by Sony Corporation
 *			All rights Reserved
 */

#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include "ctrller.h"

#define SCR_Z           1024                    // screen projection
#define OTSIZE          1024                    // depth of OT 
#define MAX_POLY        500                     // maximum amount of polygons 
#define MODELADDR       ((u_long *)0x80100000)  // TMD address 
#define TIM_1           ((u_long *)0x80140000)  // TIM address 

ControllerPacket buffer1,buffer2;               // initalise the controller buffers

typedef struct{                                 // declair the double buffer data structure
        u_long          ot[OTSIZE];             // declair the ordering table
        DRAWENV         draw;                   // declair the drawing environment
        DISPENV         disp;                   // declair the display environment
} DB;

typedef struct {                                // declair the poly coords
        SVECTOR n0, n1, n2;                     // declair the polygon normals 
        SVECTOR v0, v1, v2;                     // declair the polygon vertex 
} VERT_FT3;

typedef struct {                                // declair the TMD obj struct
        int              n;                     // primitive number 
        VERT_FT3         vert[MAX_POLY];        // vertex 
        CVECTOR          colour[MAX_POLY];      // colour 
        POLY_FT3         prim[2][MAX_POLY];     // primitive 
} OBJ_FT3;

typedef struct {
        u_short         v;                      // vertical count for the Konami GUN
        u_short         h;                      // Horizontal count for the Konami GUN
}HV_CNT;

typedef struct {                                // decalir the PAD buffer for IniGUN
        char            result;
        char            id;
        char            data[32];
}PAD;

typedef struct {
        char            dummy;
        char            count;
        HV_CNT          hv[20];
}GUN;


static GUN              gun[2];
static PAD              controller[2];
static u_short          v_count[2];
static u_short          h_count[2];

static int loadTMD_FT3(u_long *tmd, OBJ_FT3 *obj);

static SVECTOR  ang   = {0, 0, 0};        /* rotate angle */
static VECTOR   vec   = {0,     0, SCR_Z}; 
static MATRIX   m;
static int      scale = ONE/4;
	
VECTOR  svec;
RECT    screen;
// general wortking varibles
int c,time;
int speed = 10;
int dir = 1;
int i;


long dummy,flg,otz,p;
int ScreenDivide,gunX,gunY,shotX,shotY;
int middleX,middleY,rotX,rotY;
int XX,YY;
int dif;
int rotation,a;
int lowX = 1000 ,highX,lowY = 1000,highY;
int highspeed = 75;
int init,fired;


main()
{
        DB              db[2];
        DB              *cdb;

        static OBJ_FT3  obj;           /* object */

        static u_long   otbuf[2][OTSIZE];       /* OT */
        u_long          *ot;                    /* current OT */
        int             id = 0;                 /* primitive buffer ID */
        VERT_FT3         *vp;                    /* work */
        POLY_FT3         *pp;                    /* work */

        int		nprim;			/* work */

        ResetGraph(0);
        InitGeom();

        SetGeomOffset(256,120);    // half width and half height
                 
        SetGeomScreen(1024);

        setRECT(&screen,0,0,512,240);

        SetDefDrawEnv(&db[0].draw,0,0,512,240);
        SetDefDrawEnv(&db[1].draw,0,240,512,240);

        SetDefDispEnv(&db[0].disp,0,240,512,240);
        SetDefDispEnv(&db[1].disp,0,0,512,240);

        db[0].draw.isbg = db[1].draw.isbg = 1;

        setRGB0(&db[0].draw, 60,60,255);
        setRGB0(&db[1].draw, 60,60,255);

        FntLoad(960, 256);
        SetDumpFnt(FntOpen(10,10,320,250,0,512));


InitPAD(&buffer1,MAX_CONTROLLER_BYTES ,&buffer2, MAX_CONTROLLER_BYTES);
StartPAD();

        loadTIM(TIM_1);

        loadTMD_FT3(MODELADDR, &obj);

        SetDispMask(1);  /* start display */                

        do
        {

               cdb = (cdb==db)?db+1 : db;

                if(GoodData(&buffer1))
                       {

                           switch(GetType(&buffer1))
                                  {

                                  case 3:
                                        


                                        if(init == 0)
                                            {

                                            // Kill The Controller and initalise the gun

                                                StopPAD();
                                                InitGUN((char *)&buffer1, 34, (char *)&buffer2, 34, (char *)&gun[0], (char *)&gun[1],20);
                                                StartGUN();
                                                init = 1;
                                            }

                                        Konami_Gun(cdb);  //Send to the Konami gun reading function
                                        break;

                                  case 6:

                                        Namco_Gun(cdb);   //Send to the Namco gun reading function
                                        break;

                                  default:
                                        FntPrint("Please Insert a\nNamco or Konami gun\n ");
                                        break;
                                  }
                       }
                       else
                       {
                           if (init == 1)
                               {
                               // kill the gun and init the controller 

                                    // reset the call back stops the gun interupt
                                    ResetCallback();
                                    StopGUN();
                                    RemoveGUN();

                                    InitPAD(&buffer1,MAX_CONTROLLER_BYTES ,&buffer2, MAX_CONTROLLER_BYTES);
                                    StartPAD();
                                    init = 0;
                               }
                   
                       FntPrint("Please Insert a\nNamco or Konami gun\n ");

                       }
                   

                setVector(&svec, scale, scale, scale);
                RotMatrix(&ang, &m); 
                TransMatrix(&m, &vec); 
                ScaleMatrix(&m, &svec);
                SetRotMatrix(&m);
                SetTransMatrix(&m);

                /* swap primitive buffer ID */

                id = id? 0: 1;
                ot = otbuf[id];

                // Clear the ordering table
                ClearOTagR(cdb->ot, OTSIZE);


                /* 3D operation */

                /* set primitive vertex */
                vp = obj.vert;
                pp = obj.prim[id];

                /*
                 * Note this has been hard coded to do 360 polys
                 * normaly nprim will have been used.  this has looked at the
                 * data structure and checked for amount of polys.
                 */

                for (i = 0; i < 360; i++, vp++, pp++) {

                    dummy = RotAverageNclip3(
                            &vp->v0,         
                            &vp->v1,         
                            &vp->v2,         
                            (long *)&obj.prim[id][i].x0,
                            (long *)&obj.prim[id][i].x1, 
                            (long *)&obj.prim[id][i].x2, 
                            &p,
                            &otz,
                            &flg); 

                          otz = otz/4;

                        if (dummy>0 && otz>0 && otz< OTSIZE) 
                                {
                                addPrim(cdb->ot+otz,&obj.prim[id][i]);

                                 // gather the highest and lowest X/Y for colision detection
                                 if(obj.prim[id][i].x0 < lowX)  lowX  = obj.prim[id][i].x0;
                                 if(obj.prim[id][i].x0 > highX) highX = obj.prim[id][i].x0;

                                 if(obj.prim[id][i].y0 < lowY)  lowY  = obj.prim[id][i].y0;
                                 if(obj.prim[id][i].y0 > highY) highY = obj.prim[id][i].y0;
                                 }
                }


               // is the gun shot within the bounderies of the globe

               if(shotX > lowX && shotX < highX &&
                   shotY > lowY && shotY < highY)
                        {
                        highspeed++;
                        rotX = 100;
                        rotY = 100;
                        dir = 1;

                        }

               FntPrint("\n X = %d Y = %d\n ",gunX,gunY);

               Move_Obj();

               PutDrawEnv(&cdb->draw);
               PutDispEnv(&cdb->disp);
               DrawSync(0);
               time = VSync(0);

               DrawOTag(cdb->ot+OTSIZE-1);

               FntPrint("time = %d\n",time );

               FntFlush(-1);


         }while(1);



        PadStop();
	StopCallback();
	return;
}

/*
 * load TMD
 */
static int loadTMD_FT3(u_long *tmd, OBJ_FT3 *object)
{
        VERT_FT3        *vert;
        POLY_FT3        *prim0, *prim1;

        TMD_PRIM	tmdprim;
	int		col, i, n_prim = 0;

        /* open TMD */
	if ((n_prim = OpenTMD(tmd, 0)) > MAX_POLY)
		n_prim = MAX_POLY;

        vert  = object->vert;
        prim0 = object->prim[0];
        prim1 = object->prim[1];

	/*
	 * Set unchanged member of primitive here to deliminate main
	 * memory write access
	 */	 

	for (i = 0; i < n_prim && ReadTMD(&tmdprim) != 0; i++) {
		
                /* initialize primitive */
                SetPolyFT3(prim0);


                /* copy normal and vertex */
                copyVector(&vert->n0, &tmdprim.n0);
                copyVector(&vert->n1, &tmdprim.n1);
                copyVector(&vert->n2, &tmdprim.n2);
                       

                copyVector(&vert->v0, &tmdprim.x0);
		copyVector(&vert->v1, &tmdprim.x1);
		copyVector(&vert->v2, &tmdprim.x2);

                col = (tmdprim.n0.vx+tmdprim.n0.vy)*128/ONE/2+128;

                setRGB0(prim0, col, col, col);


                setUV3(prim0,
                       tmdprim.u0, tmdprim.v0,
                       tmdprim.u1, tmdprim.v1,
                       tmdprim.u2, tmdprim.v2);

                prim0->tpage = tmdprim.tpage;
                prim0->clut = tmdprim.clut; 

                /* duplicate primitive for primitive double buffering
		 */  

                memcpy(prim1, prim0, sizeof(POLY_FT3));
		vert++, prim0++, prim1++;

        }
        return(object->n = i);
}



loadTIM(u_long *addr)
{


TIM_IMAGE       image;

OpenTIM(addr);

        while(ReadTIM(&image))
        {
           if(image.caddr);
           {
                LoadImage(image.crect,image.caddr);
           }


           if(image.paddr)
           {
                LoadImage(image.prect,image.paddr);
           }
       }

}  // End of the load tim function

/*
 * Function to move the Globe
 */

Move_Obj()
{
        if(dir == 1)
        {
             vec.vz += speed;
             speed -= 1;

                 if(speed < 10)
                    {
                        dir = 2;
                    }
        }

        if(dir == 2)
        {
             vec.vz -= speed;
             speed += 1;

                 if(vec.vz < 800)
                    {
                        dir = 1;
                        speed = highspeed;
                    }
        }

       ang.vx += rotY;     // set the rotation angle
       ang.vy -= rotX;     // set the rotation angle


       if(rotX > 0)      // If needed reduce the X rotarion speed
          {
              rotX--;
          }

       if(rotY > 0)      // If needed reduce the Y rotarion speed 
          {
              rotY--;
          }

       if(rotX < 0)      // If needed increase the X rotarion speed 
          {
              rotX++;
          }

       if(rotY < 0)      // If needed increase the Y rotarion speed
          {
              rotY++;
          }
              

       shotX = 0;   // reset the X shot
       shotY = 0;   // reset the Y shot
       lowX = 1000; // reset the lowX
       lowY = 1000; // reset the lowY

       highX = 0;   // reset the highX
       highY = 0;   // reset the highY




}


/*
 * Function for the Namco Gun
 */

Namco_Gun(DB *db)
{


//ang.vy += rotation;


if(PadKeyIsPressed(&buffer1,GUNCON_TRIGER)!=0)
{

            if(fired == 0)
                 {
                        ClearImage(&screen,250,250,255); // flash the screen
                        DrawSync(0);             // wait for the flash to be drawn
                        VSync(0);                // wait for the flash to be drawn

                        gunX          = GunConX(&buffer1);         // Read the Guncon's X figure
                        gunY          = GunConY(&buffer1);         // Read the Guncon's Y figure
                        ScreenDivide  = GunConScreenDiv(&buffer1); // which sector of the screen 0/1?

                        if(ScreenDivide == 0)
                              {
                                   dif = (255-gunX);
                                   gunX = gunX - (dif / 2);
                              }

                        if(ScreenDivide == 1)
                              {   
                                   gunX = gunX + 255;
                                   gunX = gunX + (gunX / 2);
                                   gunX = (gunX - 10);
                              }


                        gunY = (gunY - 40);

                        shotX = gunX;
                        shotY = gunY;
                        fired = 1;
                 }
}
else
{
fired = 0;
}


}


/*
 *  Function to read the Konami Gun
 */
Konami_Gun(DB *db)
{

SelectGUN(0,1);


if(PadKeyIsPressed(&buffer1,KONAMI_TRIGGER)!=0)
    {
        if(fired == 1)
           {

                // Flash The screen bright Blue

                ClearImage(&db->draw.clip,250,250,255); // flash the screen

                DrawSync(0);             // wait for the flash to be drawn
                VSync(0);                // wait for the flash to be drawn

                gunX = (gun->hv[0].h - 140);

                        if(gunX > 0)
                        {
                                gunX = gunX/3;
                        }

                gunY = gun->hv[0].v;

                gun->hv[0].h = 0;        // reset the horizontal figure
                gun->hv[0].v = 0;        // reset the vertical figure

                shotX = gunX;
                shotY = gunY;

           fired = 0;                    // so the if loop is only entered once while button pressed
           }
    }
    else
    {
    fired = 1;
    }
}
