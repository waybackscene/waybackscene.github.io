/*
	after all i release this little source for all newbies.
	i hope it helps u to learn something about psxcoding.
	if u think this source is lame and can be made 1000x times better and faster,
	then u are a lucky man and dont need it...
	but if u think it helps u then plz let it me know...
	im not sure if it compiles ok, coz i dont have the yarouze stuff installed anymore,
	if u have probs to get it compiled plz contact me...
	
	Brainwalker / Hitmen
	Brainwalker@gmx.de
	
*/
#include <libps.h>

extern char ballgfx[];
extern int cosinus[];
extern int sinus[];
extern char pixelgfx[];
extern char logogfx[];
extern char fontdata[];
extern char VH_Addr[];
extern char VB_Addr[];
extern char SEQ_Addr[];

// #define Init3D
 #define DEBUG

#define OT_LENGTH  10
GsOT WorldOT[2];
GsOT_TAG OTTags[2][1<<OT_LENGTH];

#define PACKETMAX 2000
PACKET GpuPacketArea[2][PACKETMAX*24];     /* warum 24 ? */

#define SpritesMax 100
#define Spr_w 26
#define Spr_h 26

#define anz_stars 800
#define star_w 8000

GsSPRITE Sprites[SpritesMax];
GsSPRITE Font[64],Scroll[44];
GsSPRITE Pixel,Stars[anz_stars];
GsSPRITE Logo;

char ScrollTxt[]=
"                                          "\
"after years of decay im back in buisness ...       "\
"done this little intro in one day just to say hello to the psx scene "\
"and to bring back the glory days of amiga to the psx ...  "\
"group hihos to ezoray blackbag and k-comm    "\
" banging hihos to jihad, segmond, silpheed, tratax and all at #psxdev "\
"   ... look out for more "\
"new brainwalker and hitmen releases ..."\
"  === (c) 01/01/1998 BY BRAINWALKER ===             e.vil n.ever d.ies";

struct scroll {
	char	*ptr;
	int		time;
	int		speed;
    int     jump;
} scroll;

#define Frame_w 384
#define Frame_h 240
#define Fnt_x 320
#define Fnt_y 256

#define RAND_MAX 32768
#define random(num)(int)(((long)rand()*(num))/(RAND_MAX+1))
#define randomize()     srand()

GsIMAGE SpriteInfo,FontInfo;
RECT rect;

int activeBuff;
int i,cnt,cnt2,area,Xangle,Yangle,depth;

struct star{int x,y,z;};
struct star sky[anz_stars];

short vab,seq;

// **** Function declare ****

void Init_System();
void Init_Sprite_Data();
void Init_Font();
void Init_Scroll();
void Init_Pixel();
void Init_Sky();
void Move_Sky(int activeBuff);
void Print_Debug();
void Draw_World(int activeBuff);
void Move_Sprites(int activeBuff);
void Move_Scroll(int activeBuff);
void Init_Logo();
void Init_Sound();
void Play_Sound();

// **************** MAIN Programm ****************

main()
{
	Init_System();
    Init_Font();
    Init_Scroll();
    Init_Sprite_Data();
    Init_Pixel();
    Init_Sky();
    Init_Logo();
    Init_Sound();
    Play_Sound();

    Xangle=Yangle=1;
    depth=8;

	/* main loop */
   	while (-1)
    {
    	activeBuff=GsGetActiveBuff();
    	GsSetWorkBase((PACKET*)GpuPacketArea[activeBuff]);
    	GsClearOt(0, 0, &WorldOT[activeBuff]);

        GsSortSprite(&Logo,&WorldOT[activeBuff],0);

        Move_Sky(activeBuff);
        Move_Scroll(activeBuff);
    	Move_Sprites(activeBuff);
        Draw_World(activeBuff);

        Print_Debug();
    }

    ResetGraph(0);
    return(0);
}

void Init_Sky()
{
    randomize();
    for(i=1;i<anz_stars;i++)
    {
        sky[i].x=star_w-random(2*star_w);
        sky[i].y=star_w-random(2*star_w);
        sky[i].z=random(80)+1;
    }
}
void Move_Sky(int activeBuff)
{
    int x,y,z;

    for(i=1;i<anz_stars;i++)
    {
        if (sky[i].z==1) sky[i].z=100;
        x=(sky[i].x) / (sky[i].z);
        y=(sky[i].y) / (sky[i].z)--;
        Stars[i]=Pixel;
        Stars[i].x=x+160;
        Stars[i].y=y+100;
        if (sky[i].z>80) Stars[i].u=10;
        else if (sky[i].z>60) Stars[i].u=8;
        else if (sky[i].z>40) Stars[i].u=6;
        else if (sky[i].z>20) Stars[i].u=4;
        
        GsSortFastSprite(&Stars[i],&WorldOT[activeBuff],0);
    }
}

void Init_Logo()
{
    int i;
    GsIMAGE Info;
    u_short tPage;
    u_long *ptr;

    ptr=((u_long*)logogfx);
    ptr++;
    GsGetTimInfo(ptr,&Info);
    // Copy FontData to Framebuffer
    rect.x=Info.px;		rect.y=Info.py;
    rect.w=Info.pw;		rect.h=Info.ph;
    LoadImage(&rect,Info.pixel);
    tPage=GetTPage(0,0,Info.px,Info.py);

	    Logo.attribute=((Info.pmode&0x03)<<24);  // pattern bit mode: 15bitdirect
        Logo.x=45;
        Logo.y=100;
        Logo.w=Info.pw;
        Logo.h=Info.ph;
        Logo.tpage=tPage;

        Logo.u=0;
        Logo.v=0;
    // CLUTs = Colors
        Logo.cx=Info.cx;
        Logo.cy=Info.cy;
        Logo.r=Logo.g=Logo.b=0x80;      // brightness

        Logo.mx=0;
        Logo.my=0;
        Logo.scalex=ONE;
        Logo.scaley=ONE;
        Logo.rotate=ONE*0;
}
void Init_Pixel()
{
    int i;
    GsIMAGE Info;
    u_short tPage;
    u_long *ptr;

    ptr=((u_long*)pixelgfx);
    ptr++;
    GsGetTimInfo(ptr,&Info);
    // Copy FontData to Framebuffer
    rect.x=Info.px;		rect.y=Info.py;
    rect.w=Info.pw;		rect.h=Info.ph;
    LoadImage(&rect,Info.pixel);
    tPage=GetTPage(0,0,Info.px,Info.py);

	    Pixel.attribute=((Info.pmode&0x03)<<24);  // pattern bit mode: 15bitdirect
        Pixel.x=0;
        Pixel.y=50;
        Pixel.w=1;
        Pixel.h=1;
        Pixel.tpage=tPage;

        Pixel.u=0;
        Pixel.v=0;
    // CLUTs = Colors
        Pixel.cx=Info.cx;
        Pixel.cy=Info.cy;
        Pixel.r=Pixel.g=Pixel.b=0x80;      // brightness

        Pixel.mx=160;
        Pixel.my=120;
        Pixel.scalex=ONE;
        Pixel.scaley=ONE;
        Pixel.rotate=ONE*0;
}

void Init_Scroll()
{
    for(i=0;i<40;i++)
    {
     Scroll[i]=Font['@'];
     Scroll[i].x=i*8;
    }
    scroll.time=0;
    scroll.ptr=ScrollTxt;
    scroll.speed=1;
}

void Move_Scroll(int activeBuff)
{
    char *sp,txt;
    int f=0;

    scroll.jump+=4;
    if(scroll.jump>=360) scroll.jump=0;
    scroll.time+=scroll.speed;

    if (scroll.time>7)
    {
    	scroll.time=0;
        scroll.ptr++;
        if ((*scroll.ptr)==0) scroll.ptr=ScrollTxt;
    };
    sp=scroll.ptr;
    for(i=0;i<42;i++)
    {
     txt=*(sp++);
     if (txt==0) {sp=ScrollTxt; txt=*(sp++);};
     if (txt==' ') txt='@';
     if (txt>=0x61&&txt<0x7b) txt-=0x20;
     f=txt-'!';
     Scroll[i]=Font[f];
     Scroll[i].x=(i*8)-scroll.time;
     Scroll[i].y=((20*sinus[scroll.jump])>>8)+200;

     GsSortFastSprite(&Scroll[i],&WorldOT[activeBuff],0);
    }
}
void Init_Font()
{
//extern char fontdata[];
    int i;
    u_short tPage;
    u_long *ptr;

    ptr=((u_long*)fontdata);
    ptr++;
    GsGetTimInfo(ptr,&FontInfo);
    // Copy FontData to Framebuffer
    rect.x=FontInfo.px;		rect.y=FontInfo.py;
    rect.w=FontInfo.pw;		rect.h=FontInfo.ph;
    LoadImage(&rect,FontInfo.pixel);
    tPage=GetTPage(0,0,FontInfo.px,FontInfo.py);

    // init Font
    for(i=0;i<64;i++)
    {
        Font[i].attribute=((FontInfo.pmode&0x03)<<24);  // pattern bit mode: 15bitdirect
        Font[i].x=0;
        Font[i].y=0;
        Font[i].w=8;
        Font[i].h=8;
        Font[i].tpage=tPage;

        Font[i].u=i*8;
        Font[i].v=(i&32)/4;
    // CLUTs = Colors
        Font[i].cx=FontInfo.cx;
        Font[i].cy=FontInfo.cy;
        Font[i].r=Font[i].g=Font[i].b=0x80;      // brightness

        Font[i].mx=160;
        Font[i].my=120;
        Font[i].scalex=ONE;
        Font[i].scaley=ONE;
        Font[i].rotate=ONE*0;
    }
}


void Init_Sprite_Data()
{
    u_short tPage;
    int i;
    u_long *ptr;

    ptr=((u_long*)ballgfx);
    ptr++;
    GsGetTimInfo(ptr,&SpriteInfo);

    // Copy SpriteData to Framebuffer
    rect.x=SpriteInfo.px;		rect.y=SpriteInfo.py;
    rect.w=SpriteInfo.pw;		rect.h=SpriteInfo.ph;
    LoadImage(&rect,SpriteInfo.pixel);
    tPage=GetTPage(0,0,SpriteInfo.px,SpriteInfo.py);

    // init Sprites
    for(i=0;i<SpritesMax;i++) {
        Sprites[i].attribute=(2<<24);  // pattern bit mode: 15bitdirect
        Sprites[i].x=0;
        Sprites[i].y=0;
        Sprites[i].w=Spr_w;
        Sprites[i].h=Spr_h;
        Sprites[i].tpage=tPage;

        Sprites[i].u=0;
        Sprites[i].v=0;
    // CLUTs = Colors
        Sprites[i].cx=SpriteInfo.cx;
        Sprites[i].cy=SpriteInfo.cy;
        Sprites[i].r=Sprites[i].g=Sprites[i].b=0x80;      // brightness

        Sprites[i].mx=160;
        Sprites[i].my=120;
        Sprites[i].scalex=ONE;
        Sprites[i].scaley=ONE;
        Sprites[i].rotate=ONE*0;
    }
}

void Init_System()
{
	SetVideoMode(MODE_PAL);
   	ResetGraph (0) ;
    GsInitGraph(Frame_w,Frame_h,4,0,0);
    GsDefDispBuff(0,0,0,Frame_h);

#if defined(Init3D)
    GsInit3D();
#endif

	WorldOT[0].length=OT_LENGTH;
	WorldOT[0].org=OTTags[0];
	WorldOT[1].length=OT_LENGTH;
    WorldOT[1].org=OTTags[1];

	FntLoad(Fnt_x,Fnt_y);
	FntOpen(16,16,240,200,0,512);
}


void Print_Debug ()
{
#if defined(DEBUG)
     FntPrint("\nVsync: %d\tDrawSync: %d\n\n",cnt,cnt2);
     FntFlush(-1);
#endif
}

void Draw_World(int activeBuff)
{
    int i;

    // waits for drawing end
    cnt2=DrawSync(0);
    /* waits for vertical retrace */
    cnt=VSync(0);
    // Swap Double Buffer
    GsSwapDispBuff();
    /* registers a CLEARSCREEN command into the OT */
    GsSortClear(0, 0, 0, &WorldOT[activeBuff]);
    // Draw World to Framebuffer
    GsDrawOt(&WorldOT[activeBuff]);
}

void Move_Sprites(int activeBuff)
{
    int i,x,y,xang,yang;

 /*   depth=depth+(8*scale);
    if (depth>(10*8)||depth<(2*8))
    {
        scale*=-1;
        depth=depth+(8*scale);
    }
 */
    if(Xangle>=360)	Xangle=0;
	if(Yangle>=360)	Yangle=0;
    xang=Xangle=Xangle+2;  yang=Yangle=Yangle+4;

    for (i=0;i<SpritesMax;i++) {
        x=(100*sinus[xang]); y=(50*cosinus[yang]);
        xang+=8;    yang+=7;
        if(xang>=360)	xang-=360;
		if(yang>=360)	yang-=360;

        Sprites[i].x=(x>>8)+150; Sprites[i].y=(y>>8)+100;
        GsSortFastSprite(&Sprites[i],&WorldOT[activeBuff],i);
   }
}

void Init_Sound()
{
    vab=SsVabTransfer( (u_char*)VH_Addr, (u_char*)VB_Addr,-1,1);
    seq=SsSeqOpen( (u_long*)SEQ_Addr,vab);
}

void Play_Sound()
{
    SsSetMVol(127,127);
    SsSeqSetVol(seq,127,127);
    SsSeqPlay(seq,SSPLAY_PLAY,SSPLAY_INFINITY);
}

