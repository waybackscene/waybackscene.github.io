#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <kernel.h>
#include <libmath.h>
#include <stdio.h>
#include <sys/file.h>
#include <ctype.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdlib.h>

#include "pkx.h"

#include "mainc.h"
#include "text.h"

#include "wsscanf.h"
