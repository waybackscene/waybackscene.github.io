
#define	PKID(w,x,y,z) ((z<<24)|(y<<16)|(x<<8)|(w))


#define	PKX_ID_TEX	PKID('T','E','X','!')

typedef struct PKX_Texture {
	long	id;
	long	size;
	short	x;
	short	y;
	short	w;
	short	h;
	short	clut;
	short	tpage;
};


#define	PKX_ID_BIN	PKID('B','I','N','!')

typedef struct PKX_Binary {
	long	id;
	long	size;
};

