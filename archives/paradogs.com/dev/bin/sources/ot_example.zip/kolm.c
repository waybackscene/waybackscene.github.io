/* KOLM - Finnish for starfield I think (don't ask :-) )
meant as an example for using OT's..

coded by antiloop
started 1999-01-21
this header must stay as is, and the source *must* be spread along with the exe
antiloop@napalm.intelinet.com

thanks to Twin for the template source

TODO:
* I've only implemented the starfield yet, you could make an intro out of it (be it a lame one ;-) ) by adding a mod,
  some other nice-o effects, a (sine) scroller and a logo.. your imagination is the limit... :-)
(remember this is only meant to explain the working of an OT anyway)

* Bare in mind that this is meant to explain some things, so I haven't optimised anything

PS: sorry for the weird filename, if you're Finnish you might recognize it, 
I first made this for someone (Finnish.. ;-) ) and I decided it could be useful for others to learn from too
I guess I'm just too lazy to change it.. :-)
*/

#include <sys/types.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
// #include <libspu.h>


#define OT_LOGO		0	// index into ordering table, so the stars are the farthest and the logo is the nearest (reverse clear)
#define OT_TEXT		1
#define OT_STARS	2

#define OTSIZE		(4)	// prim table size: 0: logo, 1: text 2: starField 3: terminator
#define OTLENGTH	2	// for shifting

#define FRAME_X    	320	// width
#define FRAME_Y    	256	// height (not the physical TV dimensions, the area of VRAM that is supposed to be visible)
#define SCREEN_X	0	// remember pelpan on pc? hint hint ;-)
#define SCREEN_Y	0

#define PAL_MAGIC	256	// this is the number of scanlines on a (pal/ntsc) tv
#define NTSC_MAGIC	240

#define SF_SIZE		100
#define MAX_TEXT		100	// no text drawing yet... maybe when I'm bored sometime.. heh

typedef struct {
	int x,y,z;
	TILE_1 tile;
}star;

typedef struct {
	DRAWENV	draw;			/* drawing environment */
	DISPENV		disp;			/* display environment */
	u_long		ot[OTSIZE];		/* ordering table */
	star		starField[SF_SIZE];		// add other prims besides this (eg. a SPRT for your logo or a couple of polies for the sine scroller)
} DB;


/* function headers */

void InitPAL(DB *db);
void InitNTSC(DB *db);
int pad_read();
void init_prim(DB *db);
void init_stars(DB* cdb);
void create_star(DB *db,int i);

void InitPAL(DB *db)
{
	SetVideoMode(MODE_PAL);

// set up double buffering, so that the buffers are laid out vertically (buff0 starts at y=0 and buff1 at y=FRAME_Y
// the buffer that is being drawn to is not displayed, the other one (which has been drawn the previous frame) is
	SetDefDrawEnv(&db[0].draw,	0,	0,	FRAME_X, FRAME_Y);
	SetDefDrawEnv(&db[1].draw,	0,	FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[0].disp,	0,	FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[1].disp,	0,	0,	FRAME_X, FRAME_Y);
	
	db[1].disp.screen.x = db[0].disp.screen.x = SCREEN_X;
	db[1].disp.screen.y = db[0].disp.screen.y = SCREEN_Y;
	db[1].disp.screen.h = db[0].disp.screen.h = PAL_MAGIC;
	db[1].disp.screen.w = db[0].disp.screen.w = PAL_MAGIC;
	
	db[0].disp.isinter = db[1].disp.isinter = 0; 	// not interlaced
	db[0].draw.dtd = db[1].draw.dtd = 1; 		// 
	
}

void InitNTSC(DB *db) // see pal for comments
{
	SetVideoMode(MODE_NTSC);
	
	SetDefDrawEnv(&db[0].draw, 0,	0, FRAME_X, FRAME_Y);
	SetDefDrawEnv(&db[1].draw, 0,	FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[0].disp, 0,	FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[1].disp, 0,	0, FRAME_X, FRAME_Y);
	
	db[1].disp.screen.x = db[0].disp.screen.x = SCREEN_X;
	db[1].disp.screen.y = db[0].disp.screen.y = SCREEN_Y;
	db[1].disp.screen.h = db[0].disp.screen.h = 240;
	db[1].disp.screen.w = db[0].disp.screen.w = 256;
	
	db[0].disp.isinter = db[1].disp.isinter = 0;
	db[0].draw.dtd = db[1].draw.dtd = 1;
}



int pad_read()	 // if you can't figure this one out, go away! ;-)
{
	int	ret = 0;
	u_long	padd = PadRead(1);
	
	if (padd & PADk) 	ret = -1;
	
	return(ret);
}



void init_prim(DB *db)
{
	int i=0;
	 
	db->draw.isbg = 1;
	setRGB0(&db->draw, 0, 0, 0);	// clear buffer to black each frame
	
	for(i=0;i<SF_SIZE;i++)
	{
		setTile1(&(db->starField[i].tile)); // intialize the prims to tile1's
	}

	init_stars(db);			// fill in the starting coords for our stars
}

void do_frame(int frame, DB *cdb)
{
	// do starField
	int x,y;
	int clr;
	int i;
	int star=0;

	for (i=0;i<SF_SIZE;i++)
	{
		cdb->starField[i].z-=12; // Move star towards us
		if (cdb->starField[i].z<2) create_star(cdb,i); // If the star is behind us it can't
		// be seen and a new one is to be created
		x=(FRAME_X/2)+(cdb->starField[i].x<<8)/cdb->starField[i].z; // Projection, K = 256
		y=(FRAME_Y/2)+(cdb->starField[i].y<<8)/cdb->starField[i].z; // -------- " --------
		
		if (x<0 || y<0 || x>FRAME_X || y>FRAME_Y) 
			create_star(cdb,i); // If it's not visible, set it to new random values
		else
		{
			star++;
			if(star>SF_SIZE)
				printf("too big");

			cdb->starField[star].tile.x0=x;
			cdb->starField[star].tile.y0=y;
			setRGB0(&(cdb->starField[star].tile),255,255,255);

			AddPrim(cdb->ot+OT_STARS,&(cdb->starField[star].tile));
// this function adds the prim to the specified index of the ordering table, linking it to the prims that were already there
// so you get a structure like this:
// 0 - PRIM - *
// |
// 1 - *
// |
// 2 - PRIM  - PRIM  - PRIM - *
// |
// *
		}
	}
}

main()
{
	DB		db[2];
	DB		*cdb;
	int 		frame=0;
	
	ResetCallback();
	PadInit(0);				/* initialize PAD */
	ResetGraph(0);			/* reset graphic subsystem (0:cold,1:warm) */
	SetGraphDebug(1);		/* set debug mode (0:off, 1:monitor, 2:dump) */
	
//	FntLoad(960,256+128);
//	SetDumpFnt(FntOpen(0,FRAME_Y-16,FRAME_X,FRAME_Y,1/*don't clear bg*/, MAX_TEXT));

	InitPAL(db);

	init_prim(&db[0]);		/* set primitive parameters on buffer #0 */
	init_prim(&db[1]);		/* set primitive parameters on buffer #1 */
	
	SetDispMask(1);			/* enable to display (0:inhibit, 1:enable) */
	
	while (pad_read()!=-1)
	{
		cdb = (cdb==db)? db+1: db;		/* swap double buffer ID */
		ClearOTagR(cdb->ot, OTSIZE);	/* clear ordering table */
		
		do_frame(frame++,cdb);
		
//		FntFlush(-1); // watch out!	clears area specified in fntopen, i think..
	
		DrawSync(0);				/* wait for end of drawing */
		VSync(0);				/* wait for the next V-BLNK */
		PutDrawEnv(&cdb->draw);			/* update drawing environment --> double buffering switch */
		PutDispEnv(&cdb->disp);			/* update display environment */
		DrawOTag(cdb->ot+OTSIZE-1);		// draw the prims added to the OT
		
		//DumpOTag(cdb->ot+OTSIZE-1);		// debugging, if you comment this out, also comment the Fnt related functions out
	}
	
	PadStop();
	return(0);
}


//********************************  STAR CODE ***************************************************//

void init_stars(DB* cdb)
{
	int i;

	for (i=0;i<SF_SIZE;i++) // Initialize stars to random value
	{
		cdb->starField[i].x=((rand()%(2*SF_SIZE))-SF_SIZE);
		cdb->starField[i].y=((rand()%(2*SF_SIZE))-SF_SIZE);
		cdb->starField[i].z=1+(rand()%SF_SIZE);
	}
}

void create_star(DB* cdb,int i)
{
	// Set a star to new random values
	cdb->starField[i].x=((rand()%(2*SF_SIZE))-SF_SIZE);
	cdb->starField[i].y=((rand()%(2*SF_SIZE))-SF_SIZE);
	cdb->starField[i].z=1+(rand()%SF_SIZE);
}
