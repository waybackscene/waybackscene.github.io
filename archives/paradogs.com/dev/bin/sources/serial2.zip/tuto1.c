/* $PSLibId: Run-time Library Release 4.1$ */
/*
 * File:main.c
 *
 * �����ʐM�T���v��
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#include <libapi.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libsn.h>
#include <libcomb.h>
#include "balls.h"

#define	PIH		320
#define	PIV		240
#define	OTLEN		16
#define	BUFFSIZE	256
#define	TIMEOUT_VALUE	99999	/* �E�F�C�g�R�[���o�b�N�ł̃^�C���A�E�g�J�E���g */

static int	side;
static long	ot[2][OTLEN];
static DISPENV	disp[2];
static DRAWENV	draw[2];
static unsigned long fr, fw;
static char recbuf[BUFFSIZE];
static char senbuf[BUFFSIZE];
static long sencnt, reccnt;
static long hcnt = 0;
static long master = 0;
/*************************************************************************/
static int sync_read_write( int mode, char* recbuf, char* senbuf, long size );
static int sync_vsync_trger( int side );
static int sync_wait_call_back( long spec, unsigned long count );
/*************************************************************************/
int main(void)
{
	/* initialize system resource :; �V�X�e���������� */
	SetDispMask(0);
	ResetGraph(0);
	SetGraphDebug(0);
	ResetCallback();
	PadInit(0);
	ExitCriticalSection();

	/*  initialize environment for double buffer :; �`����ݒ� */
	SetDefDrawEnv(&draw[0], 0,   0, PIH, PIV);
	SetDefDrawEnv(&draw[1], 0, PIV, PIH, PIV);
	SetDefDispEnv(&disp[0], 0, PIV, PIH, PIV);
	SetDefDispEnv(&disp[1], 0,   0, PIH, PIV);
	draw[0].isbg = draw[1].isbg = 1;
	setRGB0( &draw[0], 0, 0, 64 );
	setRGB0( &draw[1], 0, 0, 64 );
	PutDispEnv(&disp[0]);
	PutDrawEnv(&draw[0]);

	/* init balls module */
	_make_balls_data();

	/* font system */
	FntLoad(960, 256);		/* load basic font pattern */
	SetDumpFnt(FntOpen(16, 16, 256, 200, 0, 512));
 
	/* �ΐ�h���C�o������  : combat driver initialization */
	AddCOMB();
	_comb_control( 1,3, 2073600 );	/* �ʐM���x�ݒ� : communication speed setting*/
	_comb_control( 1,4, 4 );	/* �ʐM�P�ʕ������ݒ� : setting number of 
					    communication unit letters */
	fw = open("sio:", O_WRONLY);
	fr = open("sio:", O_RDONLY);

	/* �E�F�C�g�R�[���o�b�N�֐���` : waiting for other PlayStation to power on*/
	_comb_control( 4,0,(long)sync_wait_call_back );

	/* ����ǂ̓d���I���҂� : waiting for other PlayStation to power on */
	while((_comb_control( 0,0,0 )&COMB_DSR)!=0 );

	 /* ����ǂƓ������Ƃ�(master,slave�̒���) : (master,slave): synchronize with other */
	if(_comb_control( 3,1,0 )!=0) {
		_comb_control( 3,0,1 );
		_comb_control( 5,0,0 );
		master = 0;
	} else {
		_comb_control( 3,0,1 );
		while(_comb_control( 3,1,0 )==0 );
		_comb_control( 5,0,0 );
		master = 1;
	}
	VSync(0);
	_comb_control( 3,0,0 );
	VSync(0);
	SetDispMask(1);

	side = 0;
	sencnt = reccnt = 0;

	while(1) {
		ClearOTag( ot[side], OTLEN );

		/* �f�[�^�̑���M */
		if( sync_read_write( master, recbuf, senbuf, BUFFSIZE )==0 ) {
			reccnt++;
			sencnt++;
		}

		_draw_balls_data( side, ot[side] );
		hcnt = VSync(0);

		/* ����I�ɑ���ǂƐ������������킹��   
		   : periodically match vertical synchronization with the other PlayStation */
		if( sync_vsync_trger( side )) continue;

		side ^= 1;
		PutDispEnv(&disp[side]);
		PutDrawEnv(&draw[side]);
		DrawOTag( ot[side^1] );
		FntPrint("\nREMOTE CONTROLLER\n\n");
		FntPrint("SYNCRONOUS READ\n");
		FntPrint("SYNCRONOUS WRITE\n\n");
		FntPrint("SEND     %d\nRECEIVE  %d\n", sencnt, reccnt );
		FntPrint("MODE     %s\n", master ? "MASTER":"SLAVE" );
		FntPrint("HSYNC    %d\n", hcnt );
		FntFlush(-1);
	}
	return 0;
}

/* �f�[�^�̑���M */
int sync_read_write( int mode, char* recbuf, char* senbuf, long size )
{
	if( mode ) {
		/* �}�X�^�[���̏��� */
		if( write( fw, senbuf, BUFFSIZE ) != BUFFSIZE ) return(-1);
		if( read( fr, recbuf, BUFFSIZE ) != BUFFSIZE ) return(-1);
	} else {
		/* �X���[�u���̏��� */
		if( read( fr, recbuf, BUFFSIZE ) != BUFFSIZE ) return(-1);
		if( write( fw, senbuf, BUFFSIZE ) != BUFFSIZE ) return(-1);
	}
	return(0);
}

/* �E�F�C�g�R�[���o�b�N�֐� :
  
*/
int sync_wait_call_back( long spec, unsigned long count )
{
	if( count>=TIMEOUT_VALUE ) return(0);
	return(1);
}

/* �R�������ɑ���ǂƐ������������킹�� :
 match vertical synchronization every three minutes with the other PlayStation
*/
#define	_REFRESH_INTERVAL	(3*60*60)
int sync_vsync_trger( int side )
{
	RECT	rect;
	static long refreshcount = _REFRESH_INTERVAL;

	if( refreshcount ) {
		refreshcount--;
		return(0);
	}

	ResetGraph(1);
	_comb_control(3,0,1);
	if( _comb_control( 3,1,0 )==0) {
		while(_comb_control( 3,1,0 )==0);
	}

	SetDispMask(0);
	_comb_control( 5,0,0 );
	setRECT( &rect, 0, 0, PIH, 480 );
	ClearImage(&rect,0,0,0);
	refreshcount = _REFRESH_INTERVAL;
	_comb_control(3,0,0);
	VSync(0);
	SetDispMask(1);

	return(1);
}
