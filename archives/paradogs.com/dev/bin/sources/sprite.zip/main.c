/**
	this source code shows how to use the controller pads to access sprites different values
	it also shows how to use more than 1 sprite at the same time 
*/

#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include "pad.h"

#define OT_LENGTH	10
GsOT myOT[2];
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];

#define PACKETMAX	300
PACKET GPUPacketArea[2][PACKETMAX*24];

#define PLAYER1_TIM	0x80100000		//address to load player 1's sprite to
#define PLAYER2_TIM	0x80140000		//address to load player 2's sprite to

#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT	240

GsIMAGE		myImg[2];			//an array of 2 images, to hold both images
GsSPRITE	mySprite[2];			//an array of 2 sprites, to hold both sprites
//note you do not need to use an arrayof sprites, you can just use 2 different sprites and images
//(initialising of sprites can be done using a for loop if you use an array)

u_long pad, oldPad;
/******** prototypes ********/
void InitAll(void);
void DisplayAll(int);
int main(void);
void InitSprite(GsIMAGE*, GsSPRITE*);
void HandlePads(void);

/******** methods *********/
int main(void) {
	int activeBuffer;
	
	InitAll();

	GsGetTimInfo((u_long *)(PLAYER1_TIM+4), &myImg[0]);		//init player 1's sprite
	InitSprite(&myImg[0], &mySprite[0]);
	
	GsGetTimInfo((u_long *)(PLAYER2_TIM+4), &myImg[1]);		//init player 2's sprite
	InitSprite(&myImg[1], &mySprite[1]);

	while(1) {
		pad=PadRead(0);
		activeBuffer=GsGetActiveBuff();
		GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);
		GsClearOt(0, 0, &myOT[activeBuffer]);
		FntPrint("brightness of player 1 = %3d\n",mySprite[0].r);
		FntPrint("brightness of player 2 = %3d\n",mySprite[1].r);
		GsSortSprite(&mySprite[0], &myOT[activeBuffer], 0);
		GsSortSprite(&mySprite[1], &myOT[activeBuffer], 0);
		DisplayAll(activeBuffer);
		
		HandlePads();
	}
}//main

void HandlePads(void) {
//do stuff for Controller Pad 1
	if (pad&Pad1x) {
		if (mySprite[0].r >0) {
			//this decreases the brightness of a sprite
			mySprite[0].r--;
			mySprite[0].g--;
			mySprite[0].b--;
		}
	}

	if (pad&Pad1crc) {
		if (mySprite[0].r <255) {
			//this increases the brightness of a sprite
			mySprite[0].r++;
			mySprite[0].g++;
			mySprite[0].b++;
		}
	}
		
	if (pad&Pad1L1) mySprite[0].rotate-=ONE;		//rotates image to the left
	if (pad&Pad1R1) mySprite[0].rotate+=ONE;		//rotates image to the right
		
	if (pad&Pad1L2) mySprite[0].scaley=mySprite[0].scalex-=50;	//shrinks sprite
	if (pad&Pad1R2) mySprite[0].scaley=mySprite[0].scalex+=50;	//increases sprite size
	
					
	if (pad&Pad1Up) mySprite[0].y--;			//moves image up
	if (pad&Pad1Down) mySprite[0].y++;			//moves image down
	if (pad&Pad1Left) mySprite[0].x--;			//moves image left
	if (pad&Pad1Right) mySprite[0].x++;			//moves image right


//do stuff for Controller Pad 2
	if (pad&Pad2x) {
		if (mySprite[1].r >0) {
			//this decreases the brightness of a sprite
			mySprite[1].r--;
			mySprite[1].g--;
			mySprite[1].b--;
		}
	}

	if (pad&Pad2crc) {
		if (mySprite[1].r <255) {
			//this increases the brightness of a sprite
			mySprite[1].r++;
			mySprite[1].g++;
			mySprite[1].b++;
		}
	}
		
	if (pad&Pad2L1) mySprite[1].rotate-=ONE;		//rotates image to the left
	if (pad&Pad2R1) mySprite[1].rotate+=ONE;		//rotates image to the right
		
	if (pad&Pad2L2) mySprite[1].scaley=mySprite[1].scalex-=50;	//shrinks sprite
	if (pad&Pad2R2) mySprite[1].scaley=mySprite[1].scalex+=50;	//increases sprite size
	
					
	if (pad&Pad2Up)		mySprite[1].y--;			//moves image up
	if (pad&Pad2Down)	mySprite[1].y++;			//moves image down
	if (pad&Pad2Left)	mySprite[1].x--;			//moves image left
	if (pad&Pad2Right)	mySprite[1].x++;			//moves image right
}

void InitSprite(GsIMAGE *im, GsSPRITE *sp) {
	int bits;
	int widthCompression;
	RECT myRect;
		
	bits=im->pmode&0x03;
	if (bits==0) widthCompression=4;
	else if (bits==1) widthCompression=2;
	else if (bits==2) widthCompression=1;
	else if (bits==3) { printf("\nunsupported file format (24bit tim)!\n"); exit(-1);}
	
	myRect.x = im->px;
	myRect.y = im->py;
	myRect.w = im->pw;
	myRect.h = im->ph;
	LoadImage( &myRect, im->pixel );		//loads image data to frame buffer
	
	printf("\nimage bit type =%d\n",bits);

	sp->attribute = (bits<<24);
	sp->x = SCREEN_WIDTH/2-((im->pw*widthCompression)/2);	//center sprite's x value
	sp->y = SCREEN_HEIGHT/2-im->ph/2;			//center sprite's y value
	sp->w = im->pw*widthCompression;
	sp->h = im->ph;
	sp->tpage=GetTPage(bits, 0, im->px, im->py);
	sp->u=0;
	sp->v=0;
	if (bits==0||bits==1) {
		//checks if image is 4 or 8 bit
		myRect.x = im->cx;
		myRect.y = im->cy;
		myRect.w = im->cw;
		myRect.h = im->ch;
		LoadImage( &myRect, im->clut );		//loads clut to frame buffer if needed
		sp->cx=im->cx;
		sp->cy=im->cy;
	}
	sp->r=128;
	sp->g=128;
	sp->b=128;
	sp->mx=(im->pw*widthCompression)/2;
	sp->my=im->ph/2;
	sp->scalex=ONE;
	sp->scaley=ONE;
	sp->rotate=0*ONE;
}

void InitAll(void) {
	printf("\ngonna try and init\n");
	SetVideoMode(MODE_PAL);
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 0,0);
	GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
	myOT[0].length=OT_LENGTH;
	myOT[1].length=OT_LENGTH;
	myOT[0].org=myOT_TAG[0];
	myOT[1].org=myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]);
	GsClearOt(0,0,&myOT[1]);
	printf("\ngraphics inited\n");
	
	PadInit(0);

	FntLoad(960, 256);
	FntOpen(10,10,SCREEN_WIDTH-10,SCREEN_HEIGHT-20,0,512);
	SetDispMask(1);  /* start display */
	printf("\nall initialised \n");
}

void DisplayAll(int currentBuffer) {
	DrawSync(0);
	VSync(0);
	GsSwapDispBuff();
	GsSortClear(0,0,0,&myOT[currentBuffer]);
	GsDrawOt(&myOT[currentBuffer]);
	FntFlush(-1);

}