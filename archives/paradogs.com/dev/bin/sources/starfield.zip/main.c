/**
	starfield.c  -  makes a starfield which can be used as a background
	many thanks to brainwlkr for his source that helped me out with this :)
*/
#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <libgs.h>
#include "pad.h"

#define OT_LENGTH	10
GsOT myOT[2];
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];

#define PACKETMAX	1000
PACKET GPUPacketArea[2][PACKETMAX*24];

#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT	240

typedef struct{
	int x;					//star structure - has and x, y and z coordinate
	int y;
	int z;
	GsLINE line;				//GsLINE strcuture that make a star pixel
}Star;

#define MAX_STARS	300
#define star_w		8000			//determines the width of the area that stars 'appear' in
Star myStars[MAX_STARS];

#define SHIP_ADDRESS	0x80100000
GsIMAGE		shipImg;
GsSPRITE	ship;

int i;					//integer used for counting
u_long pad;
int speed=2;

/******** prototypes *********/
int main(void);
void InitAll(void);
void DisplayAll(int);
void InitSprite(GsIMAGE *, GsSPRITE *);
void InitStarField(void);
void DoStarField(int);
void HandlePad(void);

/******* methods ************/
int main(void) {
	int activeBuffer;
	
	SetVideoMode(MODE_PAL);
//	SetVideoMode(MODE_NTSC);
	InitAll();						//inits system
	InitStarField();					//inits starfield
	
	GsGetTimInfo((u_long *)(SHIP_ADDRESS+4), &shipImg);	//this prepares the 'ship' sprite for display
	InitSprite(&shipImg, &ship);
	ship.mx=shipImg.px/2;
	ship.my=shipImg.py/2;
	
	ship.scalex=ONE*0.5;
	ship.scaley=ONE*0.5;
	ship.x=190;
	ship.y=110;

	while (1) {
		activeBuffer=GsGetActiveBuff();
		GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);
		GsClearOt(0, 0, &myOT[activeBuffer]);
		GsSortSprite(&ship, &myOT[activeBuffer], 0);
		FntPrint("speed=%d",speed);
		DoStarField(activeBuffer);			//this adds the starfield to the OT and moves the stars
		DisplayAll(activeBuffer);
		HandlePad();					//this handles button presses on the controller pad 1
	}
}

void HandlePad(void) {
	//handles button presses
	pad=PadRead(0);
	if (pad&Pad1Left) ship.x-=2;		//directional buttons move ship sprite
	if (pad&Pad1Right) ship.x+=2;
	if (pad&Pad1Up) ship.y-=2;
	if (pad&Pad1Down) ship.y+=2;
	if ((pad&Pad1R1)||(pad&Pad1L1)) {ship.scalex+=25; ship.scaley+=25;}	//top buttons make ship appear to move
	if ((pad&Pad1R2)||(pad&Pad1L2)) {ship.scalex-=25; ship.scaley-=25;}	//toward and away from screen
	if (pad&Pad1x) if(speed<15) speed++;					//this increases starfield speed
	if (pad&Pad1crc) if(speed>1) speed--;					//this decreases starfield speed
}

void InitStarField(void) {
	//inits starfield
	srand();					//init the randomiser (for creating random star allocations)
	
	for(i=0; i<MAX_STARS; i++) {			//this bit sets up each 'star' (MAX_STARS number of them)
		myStars[i].x=star_w-(rand()*(2*star_w))/(32767+1);	//set stars x-coordinate
		myStars[i].y=star_w-(rand()*(2*star_w))/(32767+1);	//set stars y-coordinate
		myStars[i].z=(rand()*(80))/(32767+1)+1;			//set stars z-coordinate 1-81 (cant be zero since +1)
		myStars[i].line.r=myStars[i].line.g=myStars[i].line.b=255;
	}//for
}

void DoStarField(int activeBuffer) {
	//this is what makes the stars 'move', it also adds the stars to the OT
	int x,y,z;
	
	for(i=1;i<MAX_STARS;i++) {
		if (myStars[i].z<2) myStars[i].z=100;	//if the star has reached you then put it back to come toward you again
		//divide by c so that as star gets closer it seems to move faster past you
		x=(myStars[i].x) / (myStars[i].z);		//sets x value of stars
		y=(myStars[i].y) / (myStars[i].z);		//sets y value of stars
		myStars[i].z-=speed;				//moves stars toward you
		myStars[i].line.x1=myStars[i].line.x0=x+SCREEN_WIDTH/2;			//centres starfields x value onscreen
		myStars[i].line.y1=myStars[i].line.y0=y+SCREEN_HEIGHT/2;		//centres starfields y value onscreen
		
		GsSortLine(&myStars[i].line,&myOT[activeBuffer],0);	//sorts stars into OT)
	}
}

void DisplayAll(int currentBuffer) {
	DrawSync(0);
	VSync(0);
	GsSwapDispBuff();
	GsSortClear(0,0,0,&myOT[currentBuffer]);
	GsDrawOt(&myOT[currentBuffer]);
	FntFlush(-1);
}

void InitAll(void) {
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 0,0);
	GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
	myOT[0].length=OT_LENGTH;
	myOT[1].length=OT_LENGTH;
	myOT[0].org=myOT_TAG[0];
	myOT[1].org=myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]);
	GsClearOt(0,0,&myOT[1]);
	
	PadInit(0);

	FntLoad(960, 256);
	FntOpen(10,10,SCREEN_WIDTH-10,SCREEN_HEIGHT-20,0,512);
	SetDispMask(1);  /* start display */
}

void InitSprite(GsIMAGE *im, GsSPRITE *sp) {
	int bits;
	int widthCompression;
	RECT myRect;
		
	bits=im->pmode&0x03;
	if (bits==0) widthCompression=4;
	else if (bits==1) widthCompression=2;
	else if (bits==2) widthCompression=1;
	else if (bits==3) printf("\nunsupported file format (24bit tim)!\n");
	
	myRect.x = im->px;
	myRect.y = im->py;
	myRect.w = im->pw;
	myRect.h = im->ph;
	LoadImage( &myRect, im->pixel );		//loads image data to frame buffer
	
	printf("\nimage bit type =%d\n",bits);

	sp->attribute = (bits<<24);
	sp->x = SCREEN_WIDTH/2-((im->pw*widthCompression)/2);	//center sprite's x value
	sp->y = SCREEN_HEIGHT/2-im->ph/2;			//center sprite's y value
	sp->w = im->pw*widthCompression;
	sp->h = im->ph;
	sp->tpage=GetTPage(bits, 0, im->px, im->py);
	sp->u=0;
	sp->v=0;
	if (bits==0||bits==1) {
		//checks if image is 4 or 8 bit
		myRect.x = im->cx;
		myRect.y = im->cy;
		myRect.w = im->cw;
		myRect.h = im->ch;
		LoadImage( &myRect, im->clut );		//loads clut to frame buffer if needed
		sp->cx=im->cx;
		sp->cy=im->cy;
	}
	sp->r=128;
	sp->g=128;
	sp->b=128;
	sp->mx=0;//(im->pw*widthCompression)/2;
	sp->my=0;//im->ph/2;
	sp->scalex=ONE;
	sp->scaley=ONE;
	sp->rotate=0;
}