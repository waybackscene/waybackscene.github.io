////////////////////////////////////////////////////////////////////////
// Tutorial 1 - Inits the PSX, sets the video mode and prints a text
//              Message to the screen.
////////////////////////////////////////////////////////////////////////
#include <libps.h>
#include "pad.h"

int InitGraphics(void);                          // INit the graphics
void RenderView(void);                           // render the view 

#define OT_LENGTH       (14)                     // ordering table length
#define PACKETMAX       (10000)                  // normally the max num of objects
                                                 // in your program.
#define PACKETMAX2      (PACKETMAX*24)           // psx voodoo, multiply by 24

#define SCREEN_WIDTH  320                        // screen resolution X
#define SCREEN_HEIGHT 240                        // screen resolution Y

GsOT      WorldOrderingTable[2];                  // ordering table handlers
GsOT_TAG  OrderingTable[2][1<<OT_LENGTH];         // ordering tables
PACKET    GPUOutputPacket[2][PACKETMAX2];     // GPU Packet work area

int main(void)
{
   u_long  PADstatus=0;                 // pad status

   FntLoad(960, 256);                    // Load and set fonts to use
   FntOpen(32, 32, 256, 200, 0, 512);    //specify location for start writing

   PadInit();                            // initialise the joypad

   if (InitGraphics() == 0)                // Init the PSX Video mode and tables
      return 0;

   for (;;)                              // loop till end
   {        
      PADstatus=PadRead();               // read the joypad

      if (PADstatus & Pad1Select)        // check controller for Select
         break;                          // button. 
      RenderView();                      // render the view
   }
   ResetGraph(3);                        // reset original video mode
   return 0;    
}

//////////////////////////////////////////////////////////////////////
// Inits the PSX Video mode and frame buffer
//////////////////////////////////////////////////////////////////////
int InitGraphics(void)
{
   SetVideoMode(MODE_NTSC);      // Set the video mode to NTSC

   // Set the graphics mode resolutions
   GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 1, 0);

   // Set the Top Left Coordinates Of The Two Buffers in video memory
   GsDefDispBuff(0, 0, 0, SCREEN_HEIGHT);

   // init the ordering tables
   WorldOrderingTable[0].length = OT_LENGTH;
   WorldOrderingTable[1].length = OT_LENGTH;
   WorldOrderingTable[0].org = OrderingTable[0];
   WorldOrderingTable[1].org = OrderingTable[1];
   GsClearOt(0,0,&WorldOrderingTable[0]);
   GsClearOt(0,0,&WorldOrderingTable[1]);

   return 1;
}

void RenderView(void)
{
   int CurrentBuffer;                   // double buffer

   CurrentBuffer=GsGetActiveBuff();     //get the current buffer
      
   GsSetWorkBase((PACKET*)GPUOutputPacket[CurrentBuffer]);// set GPU scratchpad area

   // clear the ordering table
   GsClearOt(0, 0, &WorldOrderingTable[CurrentBuffer]);

   // Draw the text to the CurrentBuffer
   FntPrint("PSX Developer's Connection\n\n");
   FntPrint("Tutorial #1 - PSX Text\n");
   FntPrint("\n\nPress [Select] to end\n");
   FntFlush(-1);                        // push message to buffer

   DrawSync(0);                         // wait for end of drawing   
   VSync(0);                            // wait for V_BLANK interrupt
   
   GsSwapDispBuff();                    // flip double buffers

   // Clear the Ordering Table for the CurrentBuffer
   GsSortClear(0, 0, 0,&WorldOrderingTable[CurrentBuffer]);

   // Draw the ordering table for the CurrentBuffer
   GsDrawOt(&WorldOrderingTable[CurrentBuffer]);
}
