#include <libps.h>
#include "pad.h"

// globals
volatile u_char *bb0, *bb1;

// Function Prototypes
void PadInit (void);
u_long PadRead (void);

////////////////////////////////////////////////////////////
// Inits the Controllers
////////////////////////////////////////////////////////////
void PadInit (void)
{
   GetPadBuf(&bb0, &bb1);
}

////////////////////////////////////////////////////////////
// Reads the Controllers and buffers the info
////////////////////////////////////////////////////////////
u_long PadRead(void)
{
   return(~(*(bb0+3) | *(bb0+2) << 8 | *(bb1+3) << 16 | *(bb1+2) << 24));
}
	


