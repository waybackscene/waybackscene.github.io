/////////////////////////////////////////////////////////////////////
// Tutorial 2 - Inits the PSX, sets the video mode and displays
//              one sprite, loaded from a tim file, to the screen
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <libps.h>
#include "dumpaddr.h"
#include "pad.h"

#define OT_LENGTH       14                       // Ordering Table length
#define PACKETMAX       (10000)                  // normally the max num of objects
                                                 // in your program.
#define PACKETMAX2      (PACKETMAX*24)           // psx voodoo, multiply by 24

#define SCREEN_WIDTH  320                        // screen width and height
#define	SCREEN_HEIGHT 240

GsOT      WorldOrderingTable[2];                 // ordering table handlers
GsOT_TAG  OrderingTable[2][1<<OT_LENGTH];        // ordering tables
PACKET    GPUOutputPacket[2][PACKETMAX2];        // GPU Packet work area

GsSPRITE MainSprite;                             // Sprite Handler

int InitGraphics(void);                          // Init the graphics
int InitSprite (void);                           // init the sprites
void RenderView(void);                           // render the view 

/////////////////////////////////////////////////////////////////
// Main
/////////////////////////////////////////////////////////////////
int main(void)
{
   u_long  PADstatus=0;                  // pad status

   PadInit();                            // initialise the joypad

   if (InitGraphics() == 0)              // Init the PSX and graphx mode
   {
      printf("initgraphics failed");
      return 0;
   }

   if (InitSprite() == 0)                // init the sprite structure
   {
      printf("initsprite failed");
      return 0;
   }

   for (;;)                              // loop till end
   {        
      PADstatus=PadRead();               // read the joypad

      if (PADstatus & Pad1Select)        // check controller for Select
         break;                          // button. 
      RenderView();                      // render the view
   }
   ResetGraph(3);                        // set the video mode back
   return 0;
}

//////////////////////////////////////////////////////////////////////
// Inits the PSX Video mode and frame buffer
//////////////////////////////////////////////////////////////////////
int InitGraphics(void)
{
   SetVideoMode(MODE_NTSC);      // Set the video mode to NTSC

   // Set the graphics mode resolutions
   GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 1, 0);

   // Set the Top Left Coordinates Of The Two Buffers in video memory
   GsDefDispBuff(0, 0, 0, SCREEN_HEIGHT);

   // init the ordering tables
   WorldOrderingTable[0].length = OT_LENGTH;
   WorldOrderingTable[1].length = OT_LENGTH;
   WorldOrderingTable[0].org = OrderingTable[0];
   WorldOrderingTable[1].org = OrderingTable[1];
   GsClearOt(0,0,&WorldOrderingTable[0]);
   GsClearOt(0,0,&WorldOrderingTable[1]);

   return 1;
}

//////////////////////////////////////////////////////////////////////
// Inits the sprite
//////////////////////////////////////////////////////////////////////
int InitSprite (void)
{
   RECT            rect;                           // RECT Structure
   GsIMAGE         tim_data;                       // Holds Tim Graphic info
   	
   // Put data from tim file into rect         
   GsGetTimInfo ((u_long *)(TIM_SRCPSX_ADDR+4),&tim_data);

   // Load the image into the frame buffer
   rect.x = tim_data.px;                           // Tim start X Coord
   rect.y = tim_data.py;                           // Tim start Y Coord
   rect.w = tim_data.pw;                           // Data width
   rect.h = tim_data.ph;                           // Data height
   // Load the tim data into the frame buffer
   LoadImage(&rect, tim_data.pixel);       

   // Load the CLUT into the frame buffer
   rect.x = tim_data.cx;                           // x pos in frame buffer
   rect.y = tim_data.cy;                           // y pos in frame buffer
   rect.w = tim_data.cw;                           // width of CLUT
   rect.h = tim_data.ch;                           // height of CLUT
   // load data into frame buffer
   LoadImage(&rect, tim_data.clut);                

   // initialise sprite
   MainSprite.attribute = 0x01000000;              // 8 bit CLUT, all options off
   MainSprite.x = 32;                              // Draw at x coord 32
   MainSprite.y = 0;                               // Draw at y coord 0
   MainSprite.w = (tim_data.pw*2);                 // width of sprite, 2* since 8 bit
   MainSprite.h = tim_data.ph;                     // height of sprite
   // 8bit clut, transparency, texture x, texture y
   MainSprite.tpage = GetTPage(1,0, tim_data.px, tim_data.py); 
   MainSprite.u = 0;                               // position within timfile for sprite
   MainSprite.v = 0;
   MainSprite.cx = tim_data.cx;                    // CLUT Location x coord
   MainSprite.cy = tim_data.cy;                    // CLUT Location y coord
   MainSprite.r = 128;                             // RGB Data
   MainSprite.g = 128;
   MainSprite.b = 128;
   MainSprite.mx = 0;                              // rotation x coord
   MainSprite.my = 0;                              // rotation y coord
   MainSprite.scalex = ONE;                        // Scale x coord - ONE = 100%
   MainSprite.scaley = ONE;                        // Scale y coord - ONE = 100%
   MainSprite.rotate = 0;                          // degrees to rotate

   // Wait for all drawing to finish
   DrawSync(0);

   return 1;
}

void RenderView(void)
{
   int CurrentBuffer;                   // Double Buffer Holder

   CurrentBuffer=GsGetActiveBuff();     //get the current buffer

   // Setup the packet workbase
   GsSetWorkBase((PACKET*)GPUOutputPacket[CurrentBuffer]);

   // clear the ordering table
   GsClearOt(0,0,&WorldOrderingTable[CurrentBuffer]);

   // Insert sprites into the Ordering Table
   GsSortFastSprite(&MainSprite, &WorldOrderingTable[CurrentBuffer], 0);

   // Wait for all drawing to finish
   DrawSync(0);

   // wait for V_BLANK interrupt
   VSync(0);

   // flip double buffers
   GsSwapDispBuff();

   // Clear the Ordering Table with a background color
   GsSortClear(0,0,0,&WorldOrderingTable[CurrentBuffer]);

   // Draw the ordering table for the CurrentBuffer
   GsDrawOt(&WorldOrderingTable[CurrentBuffer]);
}
