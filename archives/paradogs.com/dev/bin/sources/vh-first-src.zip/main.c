//--------------------
// Includes blabla...
//--------------------
#include	<sys/types.h>
#include	<libgte.h>
#include	<libgpu.h>
#include	<libetc.h>
#include	<libgs.h>
#include	<pad.h>
#include	<hitmod.h>
#include	"scrlsin.c"
#include	"splinus.c"
//-----------------------------------
// hier kommen die Gfx und der Sound
//-----------------------------------
extern char	module[];	// HIT-Mod Format
//---------------------------------
// die ueblichen DEFINES und so...
//---------------------------------
#define OT_LENGTH	10
#define PACKETMAX	2000
#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT	240
//-------------------------
// Variablen fuer's System
//-------------------------
GsOT myOT[2];
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];

PACKET GPUPacketArea[2][PACKETMAX*24];

u_long	pad, oldPad;

//-------------------------
// Font-Sprites & Textures
//-------------------------
extern char font[];	//  32x32 8bit Sprite
#define		MAXCHAR	44
GsSPRITE	scroll[MAXCHAR];
GsSPRITE	fontspr[48];
GsIMAGE		fontimg;
//-------------
// Kuh-Sprites
//-------------
extern char milka[];	//  32x32 8bit Sprite
#define		MAXSPR	1500
GsSPRITE	chibbyspr[MAXSPR];
GsIMAGE		chibbyimg;
//-----------------
// Hintergrundbild
//-----------------
extern char	smoon1[];	// 160x240 8bit Gfx
extern char smoon2[];	// 160x240 8bit Gfx
GsSPRITE	bground[2];
GsIMAGE		bgpart1;
GsIMAGE		bgpart2;
//-----------
// "Splinus"
//-----------
#define		MAXLINE	256
GsLINE		spline[MAXLINE];
//------------
// Prototypes
//------------
void	setup_System(void);
void	init_Sprite(GsIMAGE*, GsSPRITE*);
void	spr_setHell(GsSPRITE*, unsigned char);
void	spr_setXY(GsSPRITE*, short, short);
void	spr_rotate(GsSPRITE*, long);
void	DisplayAll(int);
void	main(void);

void	init_Font(void);

void	do_Info(void);
void	do_Splinus(void);
void	do_ShowBackground(void);
void	set_ModePAL(void);
void	set_ModeNTSC(void);

// fuer's Gfx-System
int		actBuffer=0,dmode=MODE_PAL;
int		anzspr=0,sinspeed=2,scrollspeed=0;
//
//
//
//
//
void main()
{
	int		i=0,j=0,delay=0;
	int		step=0,scrpos=0,sincount=0,sincount2=0;
	int		speeds[]={0,1,2,4,8,16};
	long	modify[MAXSPR*2];
	long	tempa[]={ 2, 1,-3, 3,-1, 1,-2, 2, 1,-3,-2, 2,-3, 1, 1, 2,-1,-2, 3};
	char	fontabc[]="0123456789%:!(). abcdefghijklmnopqrstuvwxyz=-+*/";
	char	scrolltext[]="                          "\
"hurra!!! dieser scheiss scheint zu funktionieren... "\
"van helsing is pleased to present this little piece of cake... it is called "\
"mangatro... press select to see how many chibby moons are on screen... press "\
"start to pause the scroller... press r1/l1 to increase/decrease amount of chibbys... "\
"press r2/l2 to switch between ntsc or pal mode... greetings to jihad - silpheed - barog "\
"- loser - blitter - copper - paula - agnus :-)"\
"                          @";
	//--------------------------------------------
	// Videomode setzen und Grafik initialisieren
	//--------------------------------------------
	setup_System();
	//----------------------
	// div. Vorberechnungen
	//----------------------
	j=0;
	for(i=0;i<MAXSPR;i++)
	{
		modify[i*2+0]=tempa[j++];if(j==(sizeof(tempa)/4))	j=0;
		modify[i*2+1]=tempa[j++];if(j==(sizeof(tempa)/4))	j=0;
	}
	//-------------------------------
	// Chippy-Sprites initialisieren
	//-------------------------------
	anzspr=10;
	srand();
	GsGetTimInfo((u_long *)(milka+4), &chibbyimg);
	for(i=0;i<MAXSPR;i++)
	{
		init_Sprite(&chibbyimg, &chibbyspr[i]);
		chibbyspr[i].x=(rand()*(320-66))/(32767+1)+1;
		chibbyspr[i].y=(rand()*(240-66))/(32767+1)+1;
	}
	//-------------------
	// Scrollerfont init
	//-------------------
	scrollspeed=2;
	init_Font();
	//-------------------------
	// Init Background Sprites
	//-------------------------
	GsGetTimInfo((u_long *)(smoon1+4), &bgpart1);	// init Background Sprite 1
	init_Sprite(&bgpart1, &bground[0]);
	GsGetTimInfo((u_long *)(smoon2+4), &bgpart2);	// init Background Sprite 2
	init_Sprite(&bgpart2, &bground[1]);
	bground[0].x=0;		bground[0].y=0;
	bground[1].x=160;	bground[1].y=0;
	//--------------------
	// Music init & start
	//--------------------
	MOD_Init();
	MOD_Load((unsigned char*)module);
	MOD_Start();
	//---------------
	// Hauptschleife
	//---------------
	for(;;)
	{
		delay++;
		if(delay==10)
			delay=0;

		pad=PadRead(0);
		actBuffer=GsGetActiveBuff();						// get the current buffer
		GsSetWorkBase((PACKET*)GPUPacketArea[actBuffer]);	// Setup the packet workbase
		GsClearOt(0,0,&myOT[actBuffer]);					// clear the ordering table
		//---------------------------------------------------
		// Status- und Infoanzeige wenn START gedrueckt ist
		//---------------------------------------------------
		if(pad&Pad1Select)
			do_Info();
		//-------------------------------
		// umschalten PAL/NTSC mit L2/R2
		//-------------------------------
		if(pad&Pad1L2)
			set_ModePAL();
		if(pad&Pad1R2)
			set_ModeNTSC();
		//----------
		// Scroller 
		//----------
		if(!(pad&Pad1x))
		{
			if(!(pad&Pad1Start))	// wenn START gedrueckt, dann Pause
			{
				for(i=0;i<22;i++)
					for(j=0;j<48;j++)
						if(scrolltext[scrpos+i]!='@')
						{
							if(scrolltext[scrpos+i]==fontabc[j])
							{
								scroll[i]=fontspr[j];
								scroll[i].x=((16*i)-step);
							}
						}
						else
						{
							scrpos=0;
						}
				//----------------------------------------------------------
				// Zeichen bei naechster Darstellung nach links verschieben
				//----------------------------------------------------------
				step+=speeds[scrollspeed];
				if(step==16)
				{
					scrpos++;
					step=0;
				}
				//----------------------------------------------------------------------
				// *NUR* wenn step==0 darf auch die Geschwindigkeit geaendert werden!!!
				//----------------------------------------------------------------------
				if(step==0)
				{
					if(pad&Pad1Right)
						if(scrollspeed>0)
							scrollspeed--;
					if(pad&Pad1Left)
						if(scrollspeed<5)
							scrollspeed++;
				}
			}
			//-------------------------------------
			// Scrollersprites in den OT eintragen
			//-------------------------------------
			for(i=0;i<MAXCHAR;i++)
			{
				j=((SinTab1[sincount]+SinTab2[sincount2])/2);
				scroll[i].y=(112+j);					// ergibt huebschen SinusEffekt...
				GsSortFastSprite(&scroll[i], &myOT[actBuffer], 0);
			}
			//-------------------------------------------
			// naechsten Eintrag aus Sinus-Tabelle holen
			//-------------------------------------------
			sincount+=speeds[sinspeed];
			if(sincount>=400)
				sincount=0;
			sincount2+=speeds[sinspeed];
			if(sincount2>=200)
				sincount2=0;
			if(delay==0)
			{
				if(pad&Pad1Up)
					if(sinspeed>1)
						sinspeed--;
				if(pad&Pad1Down)
					if(sinspeed<4)
						sinspeed++;
			}
		}
		//---------------------
		// mach mir die Kuh!!!
		//---------------------
		if(!(pad&Pad1crc))
		{
			if(pad&Pad1L1)			anzspr--;
			if(pad&Pad1R1)			anzspr++;
			if(anzspr<0)			anzspr=0;
			if(anzspr>MAXSPR)		anzspr=MAXSPR;
			for(i=0;i<MAXSPR;i++)
			{
				chibbyspr[i].x+=modify[i*2+0];
				chibbyspr[i].y+=modify[i*2+1];
				//----------
				// Clipping
				//----------
				if(chibbyspr[i].x>320-32)
					modify[i*2+0]=(modify[i*2+0]*-1);
				if(chibbyspr[i].x<0)
					modify[i*2+0]=(modify[i*2+0]*-1);
				if(chibbyspr[i].y>240-32)
					modify[i*2+1]=(modify[i*2+1]*-1);
				if(chibbyspr[i].y<0)
					modify[i*2+1]=(modify[i*2+1]*-1);
			}
			if(anzspr!=0)
				for(i=0;i<anzspr;i++)
					GsSortFastSprite(&chibbyspr[i], &myOT[actBuffer], 0);
		}
		//------------------------
		// der Mega-Coole SPLINUS
		//------------------------
		if(!(pad&Pad1sqr))
			do_Splinus();
		//------------------------------
		// Hintergrundsprite darstellen
		//------------------------------
		if(!(pad&Pad1tri))
			do_ShowBackground();
		//----------------------------
		// und jetzt alles darstellen
		//----------------------------
		DisplayAll(actBuffer);
	}
}
//
//=====================
// Systeminfo ausgeben
//=====================
//
void do_Info()
{
	FntPrint("Chibbys on screen: %d\n",anzspr);
	FntPrint("Scrollspeed......: %d\n",scrollspeed);
	FntPrint("Sinusspeed.......: %d\n\n",sinspeed);
	FntPrint("Credits..........: Code  - Van Helsing\n");
	FntPrint("                   Musik - Razor 1911\n");
	FntPrint("                   Gfx   - ???\n");
	FntPrint("                   Font  - ???\n\n");
	FntPrint("           contact me at\n\n");
	FntPrint("      vampy2000@geocities.com\n\n");
	FntPrint("    http://listen.to/the-master");
}
//
//======================
// Der "Splinus" Effekt
//======================
//
void do_Splinus()
{
	static int	splinecount1,splinecount2;
	static char	fadestart;
	char	fade;
	int	i,j;
	fade=fadestart;
	for(i=0;i<MAXLINE;i++)
	{
		j=i+1;
		spline[i].x0=160+((SplineTab1[i+0]+SplineTab3[splinecount1+i])/2);
		spline[i].x1=160+((SplineTab1[j+0]+SplineTab3[splinecount2+j])/2);
		spline[i].y0=120+((SplineTab2[i+1]+SplineTab4[splinecount1+i])/2);
		spline[i].y1=120+((SplineTab2[j+1]+SplineTab4[splinecount2+j])/2);
		spline[i].r=spline[i].g=fade;
		spline[i].b=255;
		GsSortLine(&spline[i],&myOT[actBuffer],0);
		//----------------
		// Farbe wechseln
		//----------------
		fade++;
		if(fade++>=255)
			fade=0;
	}
	fadestart++;
	if(fadestart>=255)
		fadestart=0;
	//-------------------------
	// Sinuspointer 1 erhoehen
	//-------------------------
	splinecount1+=1;
	if(splinecount1>=255)
		splinecount1=0;
	//-------------------------
	// Sinuspointer 2 erhoehen
	//-------------------------
	splinecount2+=2;
	if(splinecount2>=255)
		splinecount2=0;
}
//
//==========================
// Hintergrundbild anzeigen
//==========================
//
void do_ShowBackground()
{
	static char fade;
	spr_setHell(&bground[0],fade);
	spr_setHell(&bground[1],fade);
	GsSortFastSprite(&bground[0], &myOT[actBuffer], 0);
	GsSortFastSprite(&bground[1], &myOT[actBuffer], 0);
	//-----------------
	// Bild einblenden
	//-----------------
	if(fade<128)
		fade++;
}
//
//======================
// PAL Modus aktivieren
//======================
//
void set_ModePAL()
{
	if(dmode!=MODE_PAL)
	{
		DrawSync(0);
		VSync(0);
		SetVideoMode(MODE_PAL);
		ResetGraph(0);
		GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 0,0);
		GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
		dmode=MODE_PAL;
		printf("...displaymode changed to PAL...\n");
	}
}
//
//=======================
// NTSC Modus aktivieren
//=======================
//
void set_ModeNTSC()
{
	if(dmode!=MODE_NTSC)
	{
		DrawSync(0);
		VSync(0);
		SetVideoMode(MODE_NTSC);
		ResetGraph(0);
		GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 0,0);
		GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
		dmode=MODE_NTSC;
		printf("...displaymode changed to NTSC...\n");
	}
}
//
//=============================
// Font-Sprites initialisieren
//=============================
//
void init_Font()
{
	int	i=0,j=0;
	unsigned char fontxy[]={  0, 32, 16, 32, 32, 32, 48, 32, 64, 32, 80, 32, 96, 32,112, 32,
							  0, 48, 16, 48, 32, 48, 48, 48, 64, 48, 80, 48, 96, 48,112, 48,
							  0, 64, 16, 64, 32, 64, 48, 64, 64, 64, 80, 64, 96, 64,112, 64,
							  0, 80, 16, 80, 32, 80, 48, 80, 64, 80, 80, 80, 96, 80,112, 80,
							  0, 96, 16, 96, 32, 96, 48, 96, 64, 96, 80, 96, 96, 96,112, 96,
							  0,112, 16,112, 32,112, 48,112, 64,112, 80,112, 96,112,112,112};
	GsGetTimInfo((u_long *)(font+4), &fontimg);
	init_Sprite(&fontimg, &fontspr[0]);
	fontspr[0].w=16;
	fontspr[0].h=16;
	fontspr[0].u=fontxy[j++];
	fontspr[0].v=fontxy[j++];
	for(i=1;i<48;i++)
	{
		fontspr[i]=fontspr[0];
		fontspr[i].u=fontxy[j++];
		fontspr[i].v=fontxy[j++];
	}
}
//
//=============================
// Grafiksystem initialisieren
//=============================
//
void setup_System()
{
	SetVideoMode(MODE_PAL);
	ResetGraph(0);
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 0,0);
	GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
	myOT[0].length=OT_LENGTH;
	myOT[1].length=OT_LENGTH;
	myOT[0].org=myOT_TAG[0];
	myOT[1].org=myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]);
	GsClearOt(0,0,&myOT[1]);
	FntLoad(960, 256);
	FntOpen(10,10,SCREEN_WIDTH-10,SCREEN_HEIGHT-20,0,512);
	SetDispMask(1);
	PadInit(0);
}
//
//============================================
// Display aktualisieren und alles darstellen
//============================================
//
void DisplayAll(int mybuffer)
{
	FntFlush(-1);
	DrawSync(0);									// Wait for all drawing to finish
	VSync(0);										// wait for V_BLANK interrupt
	GsSwapDispBuff();								// flip double buffers
	GsSortClear(0,0,0,&myOT[mybuffer]);				// Clear the Ordering Table with a background color
	GsDrawOt(&myOT[mybuffer]);						// Draw the ordering table for the actBuffer
}
//
//=================================
// Sprite & Texture initialisieren
//=================================
//
void init_Sprite(GsIMAGE *im, GsSPRITE *sp)
{
	int bits;
	int widthCompression;
	RECT myRect;
		
	bits=im->pmode&0x03;
	if (bits==0) widthCompression=4;
	else if (bits==1) widthCompression=2;
	else if (bits==2) widthCompression=1;
	else if (bits==3) { printf("\nunsupported file format (24bit tim)!\n"); exit(-1);}
	
	myRect.x = im->px;
	myRect.y = im->py;
	myRect.w = im->pw;
	myRect.h = im->ph;
	LoadImage( &myRect, im->pixel );		//loads image data to frame buffer

	sp->attribute = (bits<<24);
	sp->x = SCREEN_WIDTH/2-((im->pw*widthCompression)/2);	//center sprite's x value
	sp->y = SCREEN_HEIGHT/2-im->ph/2;			//center sprite's y value
	sp->w = im->pw*widthCompression;
	sp->h = im->ph;
	sp->tpage=GetTPage(bits, 0, im->px, im->py);
	sp->u=0;
	sp->v=0;
	if (bits==0||bits==1) {
		//checks if image is 4 or 8 bit
		myRect.x = im->cx;
		myRect.y = im->cy;
		myRect.w = im->cw;
		myRect.h = im->ch;
		LoadImage( &myRect, im->clut );		//loads clut to frame buffer if needed
		sp->cx=im->cx;
		sp->cy=im->cy;
	}
	sp->r=128;
	sp->g=128;
	sp->b=128;
	sp->mx=(im->pw*widthCompression)/2;
	sp->my=im->ph/2;
	sp->scalex=ONE;
	sp->scaley=ONE;
	sp->rotate=0*ONE;
}

void spr_setHell(GsSPRITE *sp, unsigned char hell)
{
	sp->r=hell;
	sp->g=hell;
	sp->b=hell;
}

void spr_setXY(GsSPRITE *sp, short x, short y)
{
	sp->x=x;
	sp->y=y;
}

void spr_rotate(GsSPRITE *sp, long grade)
{
	sp->rotate=ONE*grade;
}


