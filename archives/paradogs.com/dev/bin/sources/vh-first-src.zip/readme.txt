

Hiho!!!


This is the source to Van Helsing's very first
PSX intro...

I know, it's lame, ugly looking, has no style,
bla bla bla....

I don't care... 'coz you're right...

Also the source looks very scrappy... Don't blame
me for this, it was just hacked together within 2
nights... :-)

Maybe it will help some beginner to understand
PSX coding and how to use sprites... :-)


bye bye...
...vAn hElsing...
http://listen.to/the-master

