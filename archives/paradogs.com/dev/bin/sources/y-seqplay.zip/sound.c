#include <libps.h>
#include <pad.h>

#define VH_ADDR		0x80090000
#define VB_ADDR		0x800a0000
#define SEQ_ADDR	0x80110000
#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT	240
#define RESET		2304

#define OT_LENGTH	10
GsOT myOT[2];
GsOT_TAG myOT_TAG[2][1<<OT_LENGTH];

#define PACKETMAX	300
PACKET GPUPacketArea[2][PACKETMAX*24];

short vab, seq;
u_long pad, oldPad;
/*********** prototypes ************/
int main(void);
void InitSound();		/* Sound data on memory playback */
void PlaySound();		/*  Sound playback start */
void StopSound();		/*  Sound playback termination */
void InitAll(void);
void DisplayAll(int);

/************* methods *************/
int main(void) {
	int activeBuffer;
	
	InitAll();
	SetVideoMode(MODE_PAL);
	InitSound();
	printf("\npress X to play seq file\n");
	printf("\npress start+select to quit\n");
	PlaySound();
	while(pad!=RESET) {
		pad=PadRead();
		if ((pad&Pad1x)&&(pad!=oldPad)) PlaySound();
		
		activeBuffer=GsGetActiveBuff();
		GsSetWorkBase((PACKET*)GPUPacketArea[activeBuffer]);
		GsClearOt(0, 0, &myOT[activeBuffer]);
		FntPrint("vab=%d,   seq=%d",vab,seq);
		DisplayAll(activeBuffer);
		oldPad=pad;
	}
	StopSound();
	return(0);
}

void InitSound() {
	/* VAB opening and transmission to sound buffer */
	vab = SsVabTransfer( (u_char *)VH_ADDR, (u_char *)VB_ADDR, -1, 1);
	if (vab < 0) {
		printf("SsVabTransfer failed (%d)\n", vab);
		return;
	}

	/* SEQ opening */
	seq = SsSeqOpen((u_long *)SEQ_ADDR, vab);
	if (seq < 0)
		printf("SsSeqOpen failed (%d)\n", seq);
}

/* Sound playback start */
void PlaySound() {
	SsSetMVol(100, 100);			/* Main volume setting*/
	SsSeqSetVol(seq, 127, 127);		/* Volume setting for each SEQ */
	SsSeqPlay(seq, SSPLAY_PLAY, SSPLAY_INFINITY);/* Playback switch ON */
}

/* Sound playback termination */
void StopSound() {
	SsSeqStop(seq);			/* Playback switch OFF */
	VSync(0);
	VSync(0);
	SsSeqClose(seq);			/* SEQ close */
	SsVabClose(vab);			/* VAB close */
}

void DisplayAll(int currentBuffer) {
	DrawSync(0);
	VSync(0);
	GsSwapDispBuff();
	GsSortClear(0,0,0,&myOT[currentBuffer]);
	GsDrawOt(&myOT[currentBuffer]);
	FntFlush(-1);
}

void InitAll(void) {
	SetVideoMode(MODE_PAL);
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsINTER|GsOFSGPU, 0,0);
	GsDefDispBuff(0,0,0,SCREEN_HEIGHT);
	myOT[0].length=OT_LENGTH;
	myOT[1].length=OT_LENGTH;
	myOT[0].org=myOT_TAG[0];
	myOT[1].org=myOT_TAG[1];
	GsClearOt(0,0,&myOT[0]);
	GsClearOt(0,0,&myOT[1]);
	
	PadInit(0);

	FntLoad(960, 256);
	FntOpen(10,10,SCREEN_WIDTH-10,SCREEN_HEIGHT-20,0,512);
	SetDispMask(1);  /* start display */
}