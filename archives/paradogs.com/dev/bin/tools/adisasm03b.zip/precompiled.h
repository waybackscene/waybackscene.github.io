#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#pragma warning (disable : 4786)
#include <map>
#include <string>
