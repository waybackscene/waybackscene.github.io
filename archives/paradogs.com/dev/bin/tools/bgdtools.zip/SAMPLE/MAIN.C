#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <stdio.h>

#define BGD_ADDR	0x80100000
#define CEL_ADDR 	0x80140000
#define TEX_ADDR	0x80180000

#define	OT_LENGTH 4
GsOT WorldOT[2];
GsOT_TAG OTTags[2][1<<OT_LENGTH];

#define BGWSIZE (((320/32+1)*(240/32+1+1)*6+4)*2+2)
unsigned long BgPacketArea[BGWSIZE];

void main()
{
        RECT rc;
	GsIMAGE Image;
        GsCELL Cell;
	GsBG Bg;
	GsMAP Map;
	unsigned char *ucPtr1, *ucPtr2;
	int activeBuff;
	int x, y;
        unsigned short map_array[10*8];

	PadInit(0);

	GsInitGraph(320,240,0,0,0);
	GsDefDispBuff(0,0,0,240);

	WorldOT[0].length=OT_LENGTH;
	WorldOT[0].org=OTTags[0];
	WorldOT[1].length=OT_LENGTH;
	WorldOT[1].org=OTTags[1];

	GsGetTimInfo((unsigned long*)TEX_ADDR+1, &Image);
	setRECT(&rc, Image.px, Image.py, Image.pw, Image.ph);
	LoadImage(&rc, Image.pixel);
	setRECT(&rc, Image.cx, Image.cy, Image.cw, Image.ch);
	LoadImage(&rc, Image.clut);

        ucPtr1 = (unsigned char*)BGD_ADDR+4;    // Advance 4bytes(skips header)
        ucPtr2 = (unsigned char*)CEL_ADDR+8;    // Advance 8bytes(skips header/ncell)

        Map.ncellw = *ucPtr1++;                 // Rips ncellw from BG file
        Map.ncellh = *ucPtr1++;                 // Rips ncellh from BG file
        Map.cellw = *ucPtr1++;                  // Rips cellw from BG file
        Map.cellh = *ucPtr1++;                  // Rips cellh from BG file
        Map.index = (unsigned short*)ucPtr1;    // Points to map array in BG file
        Map.base = (GsCELL *)ucPtr2;            // Points to CELL data

        GsInitFixBg32(&Bg, (unsigned long*)BgPacketArea);

        Bg.attribute = 0;
	Bg.scrollx = 0;
	Bg.scrolly = 0;
        Bg.r = 0x80;
        Bg.g = 0x80;
        Bg.b = 0x80;
	Bg.map = &Map;

	do
	{
                Bg.scrollx += 4;

		activeBuff = GsGetActiveBuff();
		GsClearOt(0, 0, &WorldOT[activeBuff]);
		
                GsSortFixBg32(&Bg, (unsigned long*)BgPacketArea, &WorldOT[activeBuff], 1);
		
		VSync(0);		
		GsSwapDispBuff();
		GsSortClear(0, 0, 0, &WorldOT[activeBuff]);
		GsDrawOt(&WorldOT[activeBuff]);
	}while(!(PadRead(0) & PADselect));

	ResetGraph(0);
	PadStop();
}

