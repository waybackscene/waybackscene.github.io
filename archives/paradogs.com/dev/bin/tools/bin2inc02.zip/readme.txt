For all the coders and hackers amongst you, here you have a new
version of my ultra-l33t bin2inc tool.

Usage: BIN2INC.EXE <infile> <outfile> <arrayname> [C|ASM|DSM]

new is only the switch to choose the output fileformat:

C   - produces an "unsigned char" C/C++ array (v0.1 produced "char")
ASM - produces an "db" include file for most ASM's out there
DSM - produces an VU1 ASM include for PS2 usage ... :-)

default is C/C++ if no other format is chosen.

switch is not case sensitive ("asm" and "ASM" give same result)

if you have any ideas or suggestions, let us know at: psxdev@themail.com

if you don't know what this tool is good for, please leave us alone ... :)

stay tuned for more tools to come from us!

sincerely yours,
[TRiNiTY]