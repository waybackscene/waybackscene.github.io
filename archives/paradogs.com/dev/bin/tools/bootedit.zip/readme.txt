bootedit beta

this is a quick readme!

please dont ask me how to make a tmd, i will explain once the
finished version is released which will contain a help file.

i have included 3 sample tmds for you to see that this program
does indeed work and isnt a scam. and i will have some better
ones available for the final release hopefully.

if there are any bugs please email me and let me know.
if this program fuks up your cds or anything else that is your
problem. this program cant be used to bypass copy protection.

loser
loser-psx@iname.com