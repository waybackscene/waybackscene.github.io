This file will build an iso9660 file for the psx - with psx boot sector & ecc generated!!!

-Cat!

cat-house@usa.net
www.bigfoot.com/~cat-house
