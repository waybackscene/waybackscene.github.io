DirectPad Pro
Version 4.0
(c) 1998 Earle F. Philhower, III
December 19, 1998
http://www.ziplabel.com

Introduction
  Do you have a joystick or gamepad that you just love, but isn't available
  for your PC?  Are the awful PC-compatible gamepads making you long for the days
  of the Atari 2600 and your beloved Wico-stick?  Do you miss your "superergo" Jaguar
  joypad?  If so, the DirectPad Pro '98 is for you!

  DirectPad Pro is a combination hardware/software interface that allows Windows 95
  to utilize Sega, Atari, Jaguar, SNES, and other console joysticks and keypads on
  their PCs.  All of the interfaces require minimal wiring and operate through a free
  parallel port.  Any Windows DirectX compatible game can use these interfaces
  automatically!

What's New
  * Spiffy new control panel interface, no applications to run!
  * PlayStation controller support 
  * Dual-Button Atari/Sega Master System support 
  * Functional Saturn interface 
  * Slower NES/SNES scanner for compatibilty on fast machines 

Disclaimer
  DirectPad Pro is free software, and may be used without payment for any
  non-commercial purpose.  However, both the software and hardware are for
  USE AT YOUR OWN RISK.

  Finally, I would like to make it clear that I am not affiliated with any
  video game related company.  Atari, Jaguar, SNES, Sega, Genesis, and all other
  company and product names may be (c), (tm), or (r) their respective companies.

Requirements
  * Windows 95/98, with DirectX 5.0/6.0
  * Printer Port
  * Homebuilt Interface

Construction
  DirectPad Pro requires the construction of a parallel port interface to talk
  to your gamepads.  If you are careful and clip component leads you will be able
  to fit the entire pad interface into a DB-25 shell.  IF YOU DON'T KNOW WHICH
  END OF A SOLDERING IRON TO HOLD, PLEASE GET SOMEONE ELSE TO BUILD THESE INTERFACES
  FOR YOU.

  The required schematics are included in the .ZIP file under "name.GIF".
  For the TurboGraFX interface, please see the web page listed in the TGFX section.
  Print the schematics out and cross off the connections as you make them.

  NOTE:  The Genesis interface has been known to not function with some
  newer parallel port chipsets.  These newer chipsets don't allow the computer
  to read a pin that's being used as aninput by DirectPad Pro, and there's
  no known workaround.  Your only option is to get an older parallel port card.
  The same goes for the "Pause" button on the Jaguar interface, but this is not
  as catastrophic as the Genesis problem.

  Construction is very straightforward.  Just make sure to double-check the
  orientation of any diodes in the circuits.  Before plugging in your interface
  do a final check, to make sure that all wires are connected properly, and that
  no bare leads or wires are touching anything.  I strongly recommend using
  a cheap, plastic hood for these interfaces, so there's even less chance of
  short-circuiting things.

  See the file "IFACE.GIF" to see how I have my interface hood set up, using a
  slightly modified plastic DB-25 hood.

  I recommend not cutting up your joystick cables to make these interfaces.
  Instead, use the appropriate female or male connector so that you can connect
  any compatible joystick to the one interface.

  It is very easy to find the HD-15 and DB-9 connectors necessary for the
  Jaguar and Atari interfaces, but finding SNES connectors are probably
  impossible.  For the SNES interface I recommend purchasing a SNES joypad
  extension cable and cutting off one end to wire directly to the schematic.

PlayStation Controllers
  To hook up the second controller duplicate all connections except DB25-10
  and DB25-12. For pad 2, replace the DB25-10 connection with a connection
  to DB25-11, and the DB25-12 with DB25-13.  Note that the parallel port
  may not be able to supply enough power to run a second controller, and
  you may only be able to run one at a time without using an external power
  supply.

  This interface has been built and tested by different folks on several
  analog, digital, Sony(tm) and clone pads. Be aware that it is different
  from SnesKey's interface, and that I will not be supporting SnesKey's
  version since I cannot get it running reliably on my system.

TurboGrafx Controllers
  Up to 5 TurboGrapFX controllers are now supported by DirectPad Pro,
  thanks to help from Steffen Schwenke.  Check his web page out at:
           http://www2.burg-halle.de/~schwenke/parport.html
  for the PCB you need to build to use these controllers.

SNES/NES Multiple Controllers
  This release has support for multiple SNES or NES pads, using the
  same interface as SNESKEY.  For pads 2..5 hook them up the same as
  pad 1, but don't make the DB25-10 connection.  Instead, make the
  connection according to the following table:
              (S)NES PAD      DB25 PIN
                    2            12
                    3            13
                    4            15
                    5            11

Software Installation
  Once you've got the interface built, it's time to install the drivers so
  that Windows can communicate with it.  Go to the "Control Panels" window,
  and select the "Game Controllers" icon.

  Select "DirectPad Pro Controller" from the list (this version does not
  have individual drivers for each joystick type). You will then be returned
  to the "Add Game Controller" dialog. For the second time, select the
  "DirectPad Pro Controller" and you're almost done.

  Finally, double-click on the newly installed joystick. Use the dialogs
  to configure to the proper interface, parallel port, and controller
  ID (when using multiple controllers).

  If you're using multiple pads you need to repeat this exercise for as
  many pads as you have connected.

Source Code
  I'm making the joystick scanning routine source code (see "JOYSRC.C")
  available.  However, the acutal driver code is not public domain,
  and will not be made available. 

Special Thanks
  Thanks to Juan Berrocal <http://gran-berro.webjump.com> for the original
  PlayStation interface.

  Thanks to Sam Hu <sam_h@163.net> for the Saturn multi-controller interface.

  Thanks in general to all the FAQ keepers for the various arcade systems.  Without
  their work I'd not have been able to design these interfaces.  Also, thanks to
  Benji York, who helped debug the SNES driver.  He has a similiar program and
  interface for DOS, Windows 3.x, and Win95, SNESKey.  Check out:
                  http://www.csc.tntech.edu/~jbyork/

Comments
  If you've had a good or bad experience with DirectPad Pro, I'd like to hear
  about it.  Mail me at earle@ziplabel.com.

