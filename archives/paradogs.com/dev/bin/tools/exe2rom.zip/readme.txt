exe2rom Converter v0.1 by Van Helsing
=====================================

Greetings stranger,

with this small tool you can make your production runable from within your
beloved AR/GR/GS!!! It simply converts the EXE file into a flashable ROM-
replacement.

It's mainly based on Barog's RunRom tool. I use his miniROM in this version
of exe2rom. Many thanks to you for your permission to use it.

Simply start it with: exe2rom <infile> <outfile>
where infile is your PS-X EXE file (max size 127k) and outfile is your ROM-
replacement.

When it is finished, simply use psupdate, ez flash or any similar tool to
flash your production into your AR/GB/GS rom...

It is reflashable so don't worry :)

Then simply pop the AR onto any PSX (making sure a bootable CD is in) and
your production will run after the Sony logo's and everything. (An option
to make your production run before the logo next version also).

Next version will hopefully include an EXE-packer, so you can store bigger
intros too...

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
DISCLAIMER: USE THIS TOOL AT YOUR OWN RISK!!! IF YOU FUCK UP YOUR AR/GB/GS
OR BLOW YOUR PSX AWAY IT'S NOT MY PROBLEM!!! I'VE TESTED THIS TOOL FOR TWO
DAYS ON 5 DIFFERENT CARTRIDGES WITH 4 DIFFERENT INTROS AND IT WORKED FINE!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

with best regards...

vAn hElsing...vampy2000@geocities.com...http://listen.to/the-master


