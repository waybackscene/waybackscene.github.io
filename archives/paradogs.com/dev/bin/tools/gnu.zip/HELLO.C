#include        "include\syscall.h"

int temp;

int main(int argc,char **argv)
{
        temp++;
        printf("%u",temp);
	printf("Hello,world\n");
	return 0;
}
