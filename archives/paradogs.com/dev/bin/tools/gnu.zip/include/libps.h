/*
	libps.h for libps.exe

	first written by BERO  based on LGPL

	I think using own import library and header files is legal because
	cygwin32 and mingw32 use their own import library and header files
	for Win32 DLL. but I'm not lawyer,so please use at your own risk.
*/

#ifndef _LIBPS_H_
#define	_LIBPS_H_

#ifdef __cplusplus
extern "C" {
#endif

/* ------- generic C functions ----- */

#ifndef	NULL
#define	NULL	((void*)0)
#endif

#ifndef	TRUE
#define	TRUE	1
#define	FALSE	0
#endif

typedef	unsigned int	size_t;

/* stdio.h functions */
extern	char getc(int fd);
extern	putc(int fd, char ch);
extern	char getchar(void);
extern	void putchar(char c);
extern	char *gets(char *s);
extern	void puts(const char *s);
extern	int printf(const char *fmt , ...);
extern	int sprintf(char *s, const char *fmt, ...);

/* string.h functions */
extern	char  *strcat(char *dst , const char *src);
extern	char  *strncat(char *dst , const char *src , size_t n);
extern	int    strcmp(const char *dst , const char *src);
extern	int    strncmp(const char *dst , const char *src , size_t n);
extern	char  *strcpy(char *dst , const char *src);
extern	char  *strncpy(char *dst , const char *src , size_t n);
extern	size_t strlen(const char *s);
extern	char  *strchr(const char *s , int c);
extern	char  *strrchr(const char *s , int c);
extern	char  *strpbrk(const char *dst , const char *src);
extern	size_t strspn(const char *s , const char *set);
extern	size_t strcspn(const char *s , const char *set);
extern	char  *strtok(char *s , const char *set);
extern	char  *strstr(const char *s , const char *set);
 /* non-ansi */
extern int index(const char *s , int c);
extern int rindex(const char *s , int c);

/* ctype.h function */
extern	int tolower(int c);
extern	int toupper(int c);

/* memory.h functions */
extern	void *memcpy(void *dst , const void *src , size_t n);
extern	void *memset(void *dst , char c , size_t n);
extern	void *memmove(void *dst , const void *src , size_t n);
extern	int   memcmp(const void *dst , const void *src , size_t n);
extern	void *memchr(const void *s , int c , size_t n);
 /* non-ansi */
extern	void bcopy(const void *src , void *dst , size_t len);
extern	void bzero(void *ptr , size_t len);
extern	int  bcmp(const void *ptr1 , const void *ptr2 , int len);

/* malloc.h functions */
extern	void *malloc(size_t size);
extern	void free(void *buf);
extern	void *calloc(size_t size , size_t n);
extern	void *realloc(void *buf , size_t n);

/* stdlib.h functions */
extern	int   abs(int i);
extern	long  labs(long i);
extern	double atof(const char *s);
extern	int   atoi(const char *s);
extern	long  atol(const char *s);
extern	int   rand(void);
extern	void  srand(unsigned _seed);
extern	void *bsearch(const void *key, const void *base, size_t nelem,
		size_t size, int (*cmp)(const void *ck, const void *ce));
extern	void  qsort(void *base, size_t nelem, size_t size,
	      int (*_cmp)(const void *_e1, const void *_e2));
extern	double strtod(const char *s , char **endptr);
extern	long   strtol(const char *s , char **endptr , int base);
extern	unsigned long strtoul(const char *s , char **endptr , int base);

/* setjmp.h */
typedef int jmp_buf[12];
extern int setjmp(jmp_buf *ctx);
extern void longjmp(jmp_buf *ctx , int value);

/* sys/file.h or unistd.h functions */
#define	O_RDONLY	1
#define	O_WRONLY	2
#define	O_RDWR		3
#define	O_CREAT		0x200

#define	SEEK_SET	0
#define	SEEK_CUR	1
#define	SEEK_END	2

extern	int   open(const char *filename, int flag);
extern	int   close(int fd);
extern	long  ioctl(int fd, long com, long arg);
extern	int   lseek(int fd, int offset, int flag);
extern	int   read(int fd, void *buf, int nbyte);
extern	int   write(int fd, void *buf, int nbyte);
extern	int   delete(const char *filename);
extern	int   format(const char *devname);
extern	int   rename(const char *srcname, char *destname);

/* sys/errno.h */
extern	long _get_errno(void);
#define	errno	_get_errno()

/* math.h functions */
extern	int	math_errno;
#define	fabs(x)	(((x)>0)?(x):-(x))

extern	double	pow(double x, double y);
extern	double	exp(double x);
extern	double	log(double y);
extern	double	log10(double x);
extern	double	floor(double x);
extern	double	ceil(double x);
extern	double	fmod(double x, double y);
extern	double	modf(double x, double *y);
extern	double	sin(double x);
extern	double	cos(double x);
extern	double	tan(double x);
extern	double	asin(double x);
extern	double	acos(double x);
extern	double	atan(double x);
extern	double	atan2(double x, double y);
extern	double	sinh(double x);
extern	double	cosh(double x);
extern	double	tanh(double x);
extern	double	sqrt(double x);
extern	double	hypot(double x, double y);
extern	double	ldexp(double x, long n);
extern	double	frexp(double x, int *n);

extern	int printf2(const char *fmt, ...);
extern	int sprintf2(char *s, const char *fmt, ...);

/* ----------------------------- psx specific --------------------------- */

typedef	unsigned char	u_char;
typedef	unsigned short	u_short;
typedef	unsigned long	u_long;
typedef	unsigned int	u_int;

/* matrix/vector functions */
typedef	struct {
	short	m[3][3];
	long	t[3];
} MATRIX;

typedef	struct {
	long	vx, vy, vz, pad;
} VECTOR;

typedef	struct {
	short	vx, vy, vz, pad;
} SVECTOR;

typedef	struct {
	u_char	r, g, b, cd;
} CVECTOR;

extern	MATRIX *MulMatrix0(MATRIX *m0,MATRIX *m1,MATRIX *m2);
extern	VECTOR *ApplyMatrix(MATRIX *m,SVECTOR *v0,VECTOR *v1);
extern	VECTOR *ApplyMatrixSV(MATRIX *m,SVECTOR *v0,SVECTOR *v1);
extern	VECTOR *ApplyMatrixLV(MATRIX *m,VECTOR *v0,VECTOR *v1);
extern	MATRIX *RotMatrix(SVECTOR *r,MATRIX *m);
extern	MATRIX *RotMatrixX(long r,MATRIX *m);
extern	MATRIX *RotMatrixY(long r,MATRIX *m);
extern	MATRIX *RotMatrixZ(long r,MATRIX *m);
extern	MATRIX *TransMatrix(MATRIX *m,VECTOR *v);
extern	MATRIX *ScaleMatrix(MATRIX *m,VECTOR *v);
extern	MATRIX *ScaleMatrixL(MATRIX *m,VECTOR *v);
extern	MATRIX *TransposeMatrix(MATRIX *m0,MATRIX *m1);
extern	MATRIX *CompMatrix(MATRIX *m0,MATRIX *m1,MATRIX *m2);
extern	void	PushMatrix(void);
extern	void	PopMatrix(void);
extern	void	gteMIMefunc(SVECTOR *otp, SVECTOR *dfp, long n, long p);

/* graphic functions */
/* graphic struct */
typedef struct {
	short	x, y;
	short	w, h;
} RECT;

typedef struct {
	long dmy[16]; /* unknown .. sizeof(DRAWENV) - member = 64 byte */
} DR_ENV;

typedef	struct {
	RECT	clip;
	short	ofs[2];
	RECT	tw;
	u_short	tpage;
	u_char	dtd;
	u_char	dfe;
	u_char	isbg;
	u_char	r0, g0, b0;
	DR_ENV	dr_env;
} DRAWENV;

typedef	struct {
	RECT	disp;
	RECT	screen;
	u_char	isinter;
	u_char	isrgb24;
	u_char	pad0, pad1;
} DISPENV;

#define	MODE_NTSC	0
#define	MODE_PAL	1

/* graphic prototype */
extern	long  GetVideoMode(void);
extern	long  SetVideoMode(long mode);
extern	int   ResetGraph(int mode);
extern	void  SetDispMask(int mask);
extern	DRAWENV *PutDrawEnv(DRAWENV *env);
extern	DISPENV *PutDispEnv(DISPENV *env);
extern	int   DrawSync(int mode);
extern	int   VSync(int mode);
extern	int   VSyncCallback(void (*func)());
extern	int   ClearImage(RECT *rect, u_char r, u_char g, u_char b);
extern	int   LoadImage(RECT *rect, u_long *p);
extern	int   MoveImage(RECT *rect, int x, int y);
extern	int   StoreImage(RECT *rect, u_long *p);
extern	u_short GetClut(int x, int y);
extern	u_short GetTPage(int tp, int abr, int x, int y);
extern	void  FntLoad(int tx, int ty);
extern	int   FntOpen(int x, int y, int w, int h, int isbg, int n);
extern	int   FntPrint();
extern	u_long *FntFlush(int id);
extern	int   KanjiFntOpen(int x, int y, int w, int h, int dx, int dy, int cx, int cy, int isbg, int n);
extern	void  KanjiFntClose(void);
extern	int   KanjiFntPrint();
extern	u_long *KanjiFntFlush(int id);
extern	int   Krom2Tim(const u_char *sjis, u_long *taddr, int dx, int dy, int cdx, int cdy, u_int fg, u_int bg);
extern	int   Krom2Tim2(const u_char *sjis, u_long *taddr, int dx, int dy, int cdx, int cdy, u_int fg, u_int bg);

/* Gs functions */

#define	GsINTER	1
#define	GsOFSGPU	4

/* Gs struct */

#define	ONE	4096
#define	WORLD	0

typedef	struct {
	unsigned	p:24;
	unsigned char	num:8;
} GsOT_TAG;

typedef	struct {
	u_long	length;	/* librefw bug */
	GsOT_TAG	*org;
	u_long	offset; /* bug  */
	u_long	point; /* bug */
	GsOT_TAG	*tag;
} GsOT;

typedef struct _GsCOORD2PARAM GsCOORD2PARAM; /*unknown*/;

typedef	struct _GsCOORDINATE2 {
	u_long	flg;
	MATRIX	coord;
	MATRIX	workm;
	GsCOORD2PARAM	*param;
	struct _GsCOORDINATE2	*super;
	struct _GsCOORDINATE2	*sub;
} GsCOORDINATE2;

typedef	struct {
	u_long	attribute;
	GsCOORDINATE2	*coord2;
	u_long	*tmd;
	u_long	id;
} GsDOBJ2;

typedef	struct {
	MATRIX	view;
	GsCOORDINATE2	*super;
} GsVIEW2;

typedef	struct {
	long	vpx, vpy, vpz;
	long	vrx, vry, vrz;
	long	rz;
	GsCOORDINATE2	*super;
} GsRVIEW2;

typedef	struct {
	long	vx, vy, vz;
	u_char	r, g, b;
} GsF_LIGHT;

typedef	struct {
	short	dqa;
	long	dqb;
	u_char	rfc, gfc, bfc;
} GsFOGPARAM;

typedef	struct {
	u_long	pmode;	/* librefw bug */
	short	px, py;
	u_short	pw, ph;
	u_long	*pixel;
	short	cx, cy;
	u_short	cw, ch;
	u_long	*clut;
} GsIMAGE;

typedef	struct {
	u_long	attribute;
	short	x, y;
	u_short	w, h;
	u_short	tpage;
	u_char	u, v;
	short	cx, cy;
	u_char	r, g, b;
	short	mx, my;
	short	scalex, scaley;
	long	rotate;
} GsSPRITE;

typedef struct {
	u_char	u, v;
	u_short	cba;
	u_short	flag;
	u_short	tpage;
} GsCELL;

typedef struct {
	u_char	cellw, cellh;
	u_short	ncellw, ncellh;
	GsCELL	*base;
	u_short	*index;
} GsMAP;

typedef struct {
	u_long	attribute;
	short	x, y;
	short	w, h;
	short	scrollx, scrolly;
	u_char	r, g, b;
	GsMAP 	*map;
	short	mx, my;
	short	scalex, scaley;
	long	rotate;
} GsBG;

typedef struct {
	u_long	attribute;
	short	x0, y0;
	short	x1, y1;
	u_char	r, g, b;
} GsLINE;

typedef struct {
	u_long	attribute;
	short	x0, y0;
	short	x1, y1;
	u_char	r0, g0, b0;
	u_char	r1, g1, b1;
} GsGLINE;

typedef struct {
	u_long	attribute;
	short	x, y;
	u_short	w, h;
	u_char	r, g, b;
} GsBOXF;

typedef struct {
	short	x,y;	/* unknown -- 4 byte */
} _GsPOSITION;

typedef unsigned char PACKET;

/* Gs globals */
extern	u_short	PSDOFSX[2];
extern	u_short	PSDOFSY[2];
extern	u_short	PSDIDX;
extern	u_long	PSDCNT;
extern	_GsPOSITION	POSITION;
extern	RECT	CLIP2;
extern	DRAWENV	GsDRAWENV;
extern	DISPENV	GsDISPENV;
extern	MATRIX	GsLSMATRIX;
extern	MATRIX	GsWSMATRIX;
extern	int	GsLIGHT_MODE;
extern	MATRIX	GsLIGHTWSMATRIX;
extern	MATRIX	GsIDMATRIX;
extern	MATRIX	GsIDMATRIX2;
extern	PACKET	*GsOUT_PACKET_P;
extern	u_long	GsLMODE;
extern	u_long	GsLIGNR;
extern	u_long	GsLIOFF;
extern	u_long	GsNDIV;
extern	u_long	GsTON;
extern	u_long	GsDISPON;

/* Gs prototype */
extern	void  GsInitGraph(int x_res, int y_res, int intl, int dither,int vram);
extern	void  GsInit3D(void);
extern	void  GsDefDispBuff(int x0, int y0, int x1, int y1);
extern	void  GsSwapDispBuff(void);
extern	int   GsGetActiveBuff(void);
extern	void  GsSetDrawBuffOffset(void);
extern	void  GsSetOffset(int x, int y);
extern	void  GsSetDrawBuffClip(void);
extern	void  GsSetClip(RECT *clip);
extern	void  GsSetOrign(int x, int y);
extern	void  GsSetClip2D(RECT *rectp);
extern	void  GsGetTimInfo(unsigned long *im, GsIMAGE *tim);
extern	void  GsMapModelingData(unsigned long *p);
extern	void  GsLinkObject4(unsigned long *tmd, GsDOBJ2 *objp, unsigned long n);
extern	int   GsSetRefView2(GsRVIEW2 *pv);
extern	int   GsSetView2(GsVIEW2 *pv);
extern	void  GsSetProjection(unsigned short h);
extern	int   GsSetFlatLight(unsigned short id, GsF_LIGHT *lt);
extern	void  GsSetLightMode(unsigned short mode);
extern	void  GsSetFogParam(GsFOGPARAM *fogparm);
extern	void  GsSetAmbient(unsigned short r, unsigned short g, unsigned short b);
extern	void  GsInitCoordinate2(GsCOORDINATE2 *super, GsCOORDINATE2 *base);
extern	void  GsGetLw(GsCOORDINATE2 *coord, MATRIX *m);
extern	void  GsGetLs(GsCOORDINATE2 *coord, MATRIX *m);
extern	void  GsGetLws(GsCOORDINATE2 *coord, MATRIX *lw, MATRIX *ls);
extern	void  GsScaleScreen(SVECTOR *scale);
extern	void  GsSetLsMatrix(MATRIX *mp);
extern	void  GsSetLightMatrix(MATRIX *mp);
extern	void  GsSetWorkBase(PACKET *base_addr);
extern	PACKET *GsGetWorkBase(void);
extern	void  GsClearOt(unsigned short offset, unsigned short point, GsOT *ot);
extern	void  GsDrawOt(GsOT *ot);
extern	void  GsSortObject4(GsDOBJ2 *objp, GsOT *ot, int shift, u_long *scratch);
extern	void  GsSortSprite(GsSPRITE *sp, GsOT *ot, unsigned short pri);
extern	void  GsSortFastSprite(GsSPRITE *sp, GsOT *ot, unsigned short pri);
extern	void  GsInitFixBg16(GsBG *bg, unsigned long *work);
extern	void  GsSortFixBg16(GsBG *bg, unsigned long *work, GsOT *ot, unsigned short pri);
extern	void  GsSortLine(GsLINE *lp, GsOT *ot, unsigned short pri);
extern	void  GsSortGLine(GsGLINE *lp, GsOT *ot, unsigned short pri);
extern	void  GsSortBoxFill(GsBOXF *bp, GsOT *ot, unsigned short pri);
extern	GsOT *GsSortOt(GsOT *ot_src, GsOT *ot_dest);
extern	void  GsSortClear(unsigned char r, unsigned char g , unsigned char b, GsOT *ot);

/* sound functions */
typedef struct {
	u_short	left,right;
} SndVolume;

extern	short SsVabTransfer(unsigned char *vh_addr, unsigned char *vb_addr, short vab_id, short i_flag);
extern	void  SsVabClose(short vab_id);
extern	short SsSeqOpen(unsigned long *addr, short vab_id); 
extern	void  SsSeqClose(short seq_id);
extern	void  SsSeqPlay(short seq_id, char play_mode, short l_count);
extern	void  SsSeqPause(short seq_id);
extern	void  SsSeqReplay(short seq_id);
extern	void  SsSeqStop(short seq_id);
extern	void  SsSeqSetVol(short seq_id, short voll, short volr);
extern	void  SsSeqGetVol(short seq_id, short seq_num, short *voll, short *volr);
extern	void  SsSeqSetNext(short seq_id1, short seq_id2);
extern	void  SsSeqSetRitardando(short seq_id, long tempo, long v_time);
extern	void  SsSeqSetAccelerando(short seq_id, long tempo, long v_time);
extern	void  SsPlayBack(short seq_id, short seq_num, short l_count);
extern	void  SsSetTempo(short seq_id, short seq_num, short tempo);
extern	short SsIsEos(short seq_id, short seq_num);
extern	void  SsSetMVol(short voll, short volr);
extern	void  SsGetMVol(SndVolume *m_vol);
extern	void  SsSetMute(char mode);
extern	char  SsGetMute(void);
extern	void  SsSetSerialAttr(char s_num, char attr, char mode); 
extern	char  SsGetSerialAttr(char s_num, char attr);
extern	void  SsSetSerialVol(char s_num, short voll, short volr);
extern	void  SsGetSerialVol(char s_num, SndVolume *s_vol); 
extern	short SsUtKeyOn(short vab_id, short prog, short tone, short note, short fine, short voll, short volr);
extern	short SsUtKeyOff(short voice, short vab_id, short prog, short tone, short note);
extern	short SsUtPitchBend(short voice, short vab_id, short prog, short note, short pbend);
extern	short SsUtChangePitch(short voice, short vab_id, short prog, short old_note, short old_fine, short new_note, short new_fine);
extern	short SsUtSetVVol(short voice, short voll, short volr);
extern	short SsUtGetVVol(short voice, short *voll, short *volr);
extern	void  SsUtReverbOn(void);
extern	void  SsUtReverbOff(void);
extern	short SsUtSetReverbType(short type);
extern	short SsUtGetReverbType(void);
extern	void  SsUtSetReverbDepth(short ldepth, short rdepth);
extern	void  SsUtSetReverbFeedback(short feedback);
extern	void  SsUtSetReverbDelay(short delay);
extern	void  SsUtAllKeyOff(short mode);

/* other functions */
struct	DIRENTRY {
	char	name[20];
	long	attr;
	long	size;
	struct	DIRENTRY	*next;
	long	head;
	char	system[8];
};

struct	EXEC {
	unsigned long	pc0;
	unsigned long	gp0;
	unsigned long	t_addr;
	unsigned long	t_size;
	unsigned long	d_addr;
	unsigned long	d_size;
	unsigned long	b_addr;
	unsigned long	b_size;
	unsigned long	s_addr;
	unsigned long	s_size;
	unsigned long	sp,fp,gp,ret,base;
};

typedef	struct {
	unsigned char	minute,second,sector,track;
} CdlLOC;

typedef	struct {
	CdlLOC	pos;
	unsigned long	size;
	char	name[16];
} CdlFILE;

#define	GetScratchAddr(offset)	((u_long*)0x1f800000+(offset))

extern	struct DIRENTRY *firstfile(const char *filename, struct DIRENTRY *dir);
extern	struct DIRENTRY *nextfile(struct DIRENTRY *dir);
extern	long LoadTest(const char *filename, struct EXEC *exec);
extern	long Load(const char *filename, struct EXEC *exec);
extern	long Exec(struct EXEC *exec, long argc, char **argv);

extern	long GetRCnt(unsigned long spec);
extern	long ResetRCnt(unsigned long spec);
extern	long StartRCnt(unsigned long spec);
extern	void FlushCashe(void);
extern	void GetPadBuf(volatile unsigned char **buf1, volatile unsigned char **buf2);
extern	int  CdReadFile(const char *filename, u_long *addr, int nbyte);
extern	int  CdReadSync(int mode, u_char *result);
extern	CdlFILE *CdSearchFile(CdlFILE *fp, const char *filename);
extern	struct EXEC *CdReadExec(const char *filename);
extern	int  CdPlay(int mode, int *tracks, int offset);
extern	void EnterCriticalSection(void);
extern	void ExitCriticalSection(void);
extern	long TestCard(long chan);
extern	InitHeap(void *block , size_t size);

/* additional */
extern void *Krom2RawAdd(int code);
extern void *Krom2RawAdd2(int code);

#ifdef __cplusplus
}
#endif

#endif /* !_LIBPS_H_ */
