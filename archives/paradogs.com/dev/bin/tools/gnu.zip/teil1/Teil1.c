/*******************************************************************************
Programm : Hello World!
Compiler : MIPS GNU C (PSX)
Autor    : Bodo Hin�ber
*******************************************************************************/

// Zuerst werden die n�tigen Includes eingeladen

#include        <syscall.h>
#include        <psxtypes.h>
#include        <int.h>
#include        <gpu.h>
#include        "htsprint.h"

// danach werden einige globale Variablen deklariert

#define OT_LENGTH       5

GsOT_TAG zSortTable[1<<OT_LENGTH];
PACKET cmdBuffer[3000];

// hier startet das Programm 

int main()
{

// Jetzt wird die Hintergrundfarbe deklariert

        COLOR clr_color = {0, 0,0, 0};

// Ordering Table

        GsOT  worldOrderTable;
        GsOT  *ot;      

// Jetzt initialisiert man den Interrupt Handler 

        INT_SetUpHandler();                     

/* hier folgen die Grafikprozessorbefehle zur Darstellung
   des Textes:

   -GPU_Setpal sorgt d�r die Auswahl der Fernsehnorm (Pal/Ntsc)
    hier ist dies Pal.

   -GPU_Reset(0) f�hrt einen Reset des Grafikprozessors aus.

   -GPU_Init (320, 240, GsNONINTER, 0) definiert den Screenmode auf
    dem der Text dargestellt werden soll. Hier 320 mal 240.

   -GPU_DEFDispBuff(0,0,0,0) Intialisierung des Doublebuffering
*/

        GPU_SetPAL(1);                          // PAL mode
        GPU_Reset(0);                           
        GPU_Init(320, 240, GsNONINTER, 0);      // Init Grafikmodus
        GPU_DefDispBuff(0, 0, 0, 0);            // Init Buffer

// Definition der Orderingtable

	worldOrderTable.length = OT_LENGTH;
	worldOrderTable.org = zSortTable;

// nun erlauben wir es dem Grapfikprozesssor die Darstellung freizuschalten.

        GPU_EnableDisplay(1);                   

// Eine Routine die den Zeichensatz intialisiert

        SetupFont();                            

// Intialisierung der Ordering Table und des Doublebuffering Speichers

        ot = &worldOrderTable; 
        GPU_ClearOt(0, 0, ot);
        GPU_SetCmdWorkSpace(cmdBuffer);         
        GPU_SortClear(1, ot, &clr_color); // l�scht Bildschirm und setzt Hindergrundfarbe

// Ausgabe des Textes

        Print (ot,0,24,"----------------------------------------");
	Print (ot,0,34,"  World of PlayStation Programmierkurs  ");
	Print (ot,0,44,"               T E I L  1               ");
	Print (ot,0,54,"                                        ");
	Print (ot,0,64,"     Textausgabe auf dem Bildschirm     ");
	Print (ot,0,74,"                                        ");
	Print (ot,0,84,"          Autor: Bodo Hinueber          ");
	Print (ot,0,94,"----------------------------------------");

        GPU_DrawOt(ot);                         // zeichne OT
        GPU_DrawSync();                         // warte bis fertig gezeichnet
        GPU_FlipDisplay();                      // tausche double buffers
        for(;;);                                // Endlosschleife
}
