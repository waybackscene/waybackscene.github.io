-------------------------------------------------------------------
-- gRIDlOCK PSX-ISO License Tool                                 --
-- Written by Gadget of gRIDlOCK                                 --
-------------------------------------------------------------------
Adds the correct License and territorial information to a PSX ISO
image, allowing the CD to boot correctly on the Sony PlayStation.

Source Code Information
Included in this distribution are both versions of gridfix license
tool. The dos version is in the dos directory while the Win32 version
is to be found in the win directory. The dos version should be able
to be compiled on any ANSI C compiler, originially written with
Watcom C 10.6. The Win32 version was written with Microsoft Visual
C++ 5.0. The project files are all included. 

Sorry for the late release of the source.

Gadget is still active.



-------------------------------------------------------------------
Instructions For Use: (WiNdows VerSioN)
1. Press the Browse... button to select the ISO File to patch.

2. Type in the message to appear on the boot screen.

3. Press the License button.

Instruction For Use: (DoS VerSioN)
Syntax: GRIDFIX isofile message

isofile - name of the ISO File to Patch
message - Text to place on the boot screen under Licensed By gRIDlOCK.

-------------------------------------------------------------------
Note: This tool will not defeat the copy protection of the PlayStation!

Greets to the rest of the Crew at gRIDlOCK
Group Greets to BlackBag, Hitmen and Napalm
Personals to Nagra, Danz, Jihad, Uncle_Git, JackRippr, Silpheed,
Curlin, Barog, Madman, Brainwalk, Antiloop, and all I forgot in
#PSXDEV
