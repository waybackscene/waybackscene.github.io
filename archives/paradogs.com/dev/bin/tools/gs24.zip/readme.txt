GameShark 2.x
Backup tools

By The Technical Revolutionary

	Right now nothing is automated very much, but it does work.

First, boot from the GSBackup CD with codes turned on.  You will need to choose an arbitrary cheat code from the cheats menu to do this.  You will get a message saying Data Transfered, and the area of memory it was transfered to.

To backup the rom, use action.exe and choose edit memory.  Then hit F5 to download memory to a file.  Enter the filename, then choose the following start/end addresses:

start:
80040000

end:
80080000


Action.exe requires that you add 1 to the end address.

Then choose dump memory.

The resulting file is your rom.  Remember that you MUST use ez.exe from the ezoray tools to flash a 256k rom, since Action.exe and psupdate.exe only work for 128k roms right now.

Backing up cheats:

Backing up cheats uses the same techniqe as above, first boot from the GSBackup cd with codes enabled.  Then run action.exe.

Your starting address for codes is 80064000.  To find your ending address just hit f10, enter 80064000 as your destination address.  You will now see the beginning of your cheat codes.  Then just scroll down untill you start seeing alot of FF FF FF FF's...  Use the 2nd or 3rd FF as your end address..

So, after finding your end address just hit F5, and type the following start/end addresses:

start:
80064000

end:
the address you found

then choose dump memory.


The resulting file is your cheat codes.  You can use comppsx2 to convert this to a .txt file.

Then you can modify it, use comppsx2 to compile it back to a bin and use psupload to upload it to the Gameshark.

Included in this zip is a gs24 rom, and all the gs24 cheat codes in txt format.  I used this cd, and these techniques to create these files

Thats all I've got for now,
		The Technical Revolutionary