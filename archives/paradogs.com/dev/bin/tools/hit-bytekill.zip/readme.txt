 
              ByteKiller for Playstation by Silpheed of Hitmen

      Based on sources by SurfSmurf, original Amiga version by Lord Blitter


This is a version of the Amiga cruncher "ByteKiller" for the playstation.
Provided is a tool for crunching and decrunching files on PC, and asm decrunch
source code to run on the PSX. We all know it's lame to release your 
productions uncrunched, and now you have no excuse as I've done all the work
for you :) Now get crunching!

  TO USE:
          Just include 'decrunch.asm' in your code, and call BK_Decrunch
          with a0 containing the address of the crunched file, and a1
          containing the address you want to uncrunch it to. Simple!


 - Silpheed/HITMEN 


