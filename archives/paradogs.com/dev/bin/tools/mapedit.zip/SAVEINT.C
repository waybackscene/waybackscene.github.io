/*****************************************************************************/
/*																			*/
/*	Notice: This file contains proprietary and copyrighted materials		*/
/*	of Mobius Codeworks Lrd.  Please refer to your							*/
/*	non-disclosure agreement and/or license agreements(s) with				*/
/*	Mobius Codeworks Ltd for use of these materials.						*/
/*																			*/
/*	Copyright (c) 1998 Mobius Codeworks Ltd									*/
/*																			*/
/****************************************************************************/
/* saveint.c	Internal Save Format										*/
/* James Pitts, Gregory Read.												*/
/****************************************************************************/




// save internal format stuff
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include <windowsx.h>

#include "resource.h"
#include "mapedit.h"
#include "pick.h"

#include "skin.h"

int FileVersion = 1;
extern long MapX, MapY, MapZ;
extern double zoom, CamX, CamY, CamZ;
extern float movespeed;
extern long NextTexId;
extern HWND hwndMain;
extern int NumEntities;
extern ENTITYSTRUCT EntityList[1024];
extern char szTimPath[256];

extern poly_t RealSides[2][MAXPOLY];


HWND hWndLoad = NULL;

#define WM_UPDATELOADPROG WM_USER + 1

// Just to be flash.. normally wouldn't bother
BOOL CALLBACK LoadDlgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{ 
	LRESULT i;
	RECT rcp, rcp1, rcc;

	switch(msg)
	{
		case WM_INITDIALOG:
			GetClientRect(hwndMain, &rcp);
			GetWindowRect(hWnd, &rcc);
			GetWindowRect(hWnd, &rcp1);
			PostMessage(hWnd, WM_USER, 0, 0);
			MoveWindow(hWnd, 
				rcp1.left + ((rcp.right - rcp.left) - (rcc.right - rcc.left)) / 2,
				rcp1.top + ((rcp.bottom - rcp.top) - (rcc.bottom - rcc.top)) / 2,
				rcc.right - rcc.left,
				rcc.bottom - rcc.top,
				TRUE);
			return 1;

		case WM_USER:
			i = SendMessage(GetDlgItem(hWnd, IDC_PROGRESS1), PBM_SETRANGE, 0, MAKELPARAM(0, 100));
			SendMessage(GetDlgItem(hWnd, IDC_PROGRESS1), PBM_SETSTEP, 1, 0);
			return 1;

		case WM_UPDATELOADPROG:
			{
				char *thetext;
				i = SendMessage(GetDlgItem(hWnd, IDC_PROGRESS1), PBM_DELTAPOS, wParam, 0);
				thetext = (char *)lParam;
				if (thetext)
					SetWindowText(GetDlgItem(hWnd, IDC_PROGTEXT), thetext);
			}
			return 1;
	}

	return 0;
}

// Save off in internal format
int SaveInternalMapFmt(char *filename)
{
	HANDLE hFile;
	SECURITY_ATTRIBUTES secattrib;
	DWORD dw;
	int i;
	
	memset(&secattrib, 0, sizeof(SECURITY_ATTRIBUTES));
	secattrib.nLength = sizeof(SECURITY_ATTRIBUTES);
	secattrib.lpSecurityDescriptor = NULL;
	secattrib.bInheritHandle = TRUE;
	
	hFile = CreateFile(filename,
				GENERIC_WRITE,
				0,
				&secattrib,
				CREATE_ALWAYS,
				FILE_ATTRIBUTE_ARCHIVE | 
				FILE_ATTRIBUTE_NORMAL | 
				FILE_FLAG_SEQUENTIAL_SCAN,
				NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return 0;	
	}

	// Write out the data starting with file version
	WriteFile(hFile, &FileVersion, sizeof(int), &dw, NULL);
	WriteFile(hFile, &WorkPlane, sizeof(vertex_t), &dw, NULL);
	WriteFile(hFile, &MapX, sizeof(long), &dw, NULL);
	WriteFile(hFile, &MapY, sizeof(long), &dw, NULL);
	WriteFile(hFile, &MapZ, sizeof(long), &dw, NULL);
	WriteFile(hFile, &zoom, sizeof(double), &dw, NULL);
	WriteFile(hFile, &CamX, sizeof(double), &dw, NULL);
	WriteFile(hFile, &CamY, sizeof(double), &dw, NULL);
	WriteFile(hFile, &CamZ, sizeof(double), &dw, NULL);
	WriteFile(hFile, &tx, sizeof(double), &dw, NULL);
	WriteFile(hFile, &ty, sizeof(double), &dw, NULL);
	WriteFile(hFile, &tz, sizeof(double), &dw, NULL);
	WriteFile(hFile, &NumVerts, sizeof(unsigned long), &dw, NULL);
	WriteFile(hFile, &Verts, sizeof(vertex_t) * NumVerts, &dw, NULL);
	WriteFile(hFile, &NumPolys, sizeof(unsigned long), &dw, NULL);
	WriteFile(hFile, &Polys, sizeof(poly_t) * NumPolys, &dw, NULL);
	WriteFile(hFile, &NumSideVerts, sizeof(unsigned long), &dw, NULL);
	WriteFile(hFile, SideVerts, sizeof(vertex_t) * NumSideVerts, &dw, NULL);
	WriteFile(hFile, &NumSides, sizeof(unsigned long), &dw, NULL);
	WriteFile(hFile, Sides, sizeof(poly_t) * NumSides, &dw, NULL);
	WriteFile(hFile, &Pos, sizeof(vertex_t), &dw, NULL);
	WriteFile(hFile, &PosClamped, sizeof(vertex_t), &dw, NULL);
	WriteFile(hFile, &PreviewPlotMode, sizeof(int), &dw, NULL);
	WriteFile(hFile, &movespeed, sizeof(float), &dw, NULL);
	WriteFile(hFile, &Face, sizeof(double), &dw, NULL);
	WriteFile(hFile, &NumEntities, sizeof(int), &dw, NULL);
	if (NumEntities > 0)
		WriteFile(hFile, EntityList, sizeof(ENTITYSTRUCT) * NumEntities, &dw, NULL);

	// Now save of poly/texture bank name - needed becuase
	// order of reload cannot be assured
	// kinda hacky but it'll work
	for (i = 0; i < NumPolys; i++)
	{
		int len;
		len = strlen(tim[Polys[i].TexId].filename);
		WriteFile(hFile, &len, sizeof(int), &dw, NULL);
		WriteFile(hFile, &(tim[Polys[i].TexId].filename), len, &dw, NULL); 
	}
	for (i = 0; i < NumSides; i++)
	{
		int len;
		len = strlen(tim[Sides[i].TexId].filename);
		WriteFile(hFile, &len, sizeof(int), &dw, NULL);
		WriteFile(hFile, &(tim[Sides[i].TexId].filename), len, &dw, NULL); 
	}

	CloseHandle(hFile);
	
	return 1;
}

int LoadInternalMapFmt(char *filename)
{
	HANDLE hFile;
	SECURITY_ATTRIBUTES secattrib;
	DWORD dw;
	int i;
	HWND hWndLoad;
	unsigned long len;

	memset(&secattrib, 0, sizeof(SECURITY_ATTRIBUTES));
	secattrib.nLength = sizeof(SECURITY_ATTRIBUTES);
	secattrib.lpSecurityDescriptor = NULL;
	secattrib.bInheritHandle = TRUE;
	
	hFile = CreateFile(filename,
				GENERIC_READ,
				0,
				&secattrib,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_ARCHIVE | 
				FILE_ATTRIBUTE_NORMAL | 
				FILE_FLAG_SEQUENTIAL_SCAN,
				NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return 0;	
	}
	
	hWndLoad = CreateDialog(ghInstance, 
				MAKEINTRESOURCE(IDD_PROGLOAD),
				hwndMain,
				LoadDlgProc);

	ShowWindow(hWndLoad, SW_SHOWNORMAL);
	UpdateWindow(hWndLoad);

	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Version");

	// Read the data starting with file version
	ReadFile(hFile, &FileVersion, sizeof(int), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading WorkPlane details");
	ReadFile(hFile, &WorkPlane, sizeof(vertex_t), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Camera Location");
	ReadFile(hFile, &MapX, sizeof(long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &MapY, sizeof(long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &MapZ, sizeof(long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &zoom, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &CamX, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &CamY, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &CamZ, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &tx, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &ty, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &tz, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Vertices");
	ReadFile(hFile, &NumVerts, sizeof(unsigned long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &Verts, sizeof(vertex_t) * NumVerts, &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Polygons");
	ReadFile(hFile, &NumPolys, sizeof(unsigned long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &Polys, sizeof(poly_t) * NumPolys, &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Side Vertices");
	ReadFile(hFile, &NumSideVerts, sizeof(unsigned long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, SideVerts, sizeof(vertex_t) * NumSideVerts, &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Walls");
	ReadFile(hFile, &NumSides, sizeof(unsigned long), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, Sides, sizeof(poly_t) * NumSides, &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Misc");
	ReadFile(hFile, &Pos, sizeof(vertex_t), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &PosClamped, sizeof(vertex_t), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, "Reading Preview settings");
	ReadFile(hFile, &PreviewPlotMode, sizeof(int), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &movespeed, sizeof(float), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 1, 0);
	ReadFile(hFile, &Face, sizeof(double), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 10, "Reading Entity Data");
	ReadFile(hFile, &NumEntities, sizeof(int), &dw, NULL);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 0, 0);
	len = sizeof(ENTITYSTRUCT) * NumEntities;
	memset(EntityList, 0, 1024 * sizeof(ENTITYSTRUCT));
	if (NumEntities > 0)
	{
		ReadFile(hFile, EntityList, len, &dw, NULL);
	}

	// Now restore poly/texture bank 
	// kinda hacky but it'll work
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 10, "ReInitialising Texture Memory");
	len = 128 * sizeof(tim_t);
	//memset(tim, 0, len);		// dont memset 33 meg.. silly..
	NextTim = tim;
	NextTexId = 0;

	// reload all textures
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 20, "Loading Textures");
	LoadAllTims (szTimPath);
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 15, "Re-Assigning Textures To Floors");
	
	for (i = 0; i < NumPolys; i++)
	{
		int len;
		char fname[256];
		memset(fname, 0, 256);
		
		ReadFile(hFile, &len, sizeof(int), &dw, NULL);
		ReadFile(hFile, &fname, len, &dw, NULL);

		// Now reload this texture if it hasn't already been loaded
		Polys[i].TexId = FindTim(fname);
		if (Polys[i].TexId == -1)
			Polys[i].TexId = LoadTim(fname);
	}
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 10, "Re-Assigning Textures To Floors");

	for (i = 0; i < NumSides; i++)
	{
		int len;
		char fname[256];

		memset(fname, 0, 256);
		
		ReadFile(hFile, &len, sizeof(int), &dw, NULL);
		ReadFile(hFile, &fname, len, &dw, NULL);

		// Now reload this texture if it hasn't already been loaded
		Sides[i].TexId = FindTim(fname);
		if (Sides[i].TexId == -1)
			Sides[i].TexId = LoadTim(fname);
	}
	SendMessage(hWndLoad, WM_UPDATELOADPROG, 10, "Load Complete.  Regenerating Map");

	memcpy(RealSides[0], Sides, sizeof(poly_t) * MAXPOLY);
	memcpy(RealSides[1], Sides, sizeof(poly_t) * MAXPOLY);

	CloseHandle(hFile);
	DestroyWindow(hWndLoad);
	NumSelectedPolys = 0;
}

int GetMapFileName(HWND hWnd, char *Title, char *thename, int Mode){
	char Filter[] = {"Map files\0*.map\0All Files\0*.*\0\0"};
	char CustomFilter[80] = ""; 
	int nFilterIndex = 0;
	char FileName[256] = "";
	OPENFILENAME ofn;

	memset (&ofn, 0, sizeof (ofn));

	ofn.lStructSize = sizeof (ofn);
	ofn.hwndOwner = hWnd;
	ofn.hInstance = ghInstance;
	ofn.lpstrFilter = Filter;
	ofn.lpstrCustomFilter = CustomFilter;
	ofn.nMaxCustFilter = 80;
	ofn.nFilterIndex = nFilterIndex;
	ofn.lpstrFile = FileName;
	ofn.nMaxFile =     256;
    ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
	ofn.lpstrTitle = Title;
    ofn.Flags = OFN_HIDEREADONLY | 
					OFN_LONGNAMES | OFN_NONETWORKBUTTON;
	ofn.lpstrDefExt = "map";

    if (Mode == 1)
	{
		if (!GetSaveFileName(&ofn)){ 
			return 0;
		}
	}
	else if (Mode == 2)
	{
		if (!GetOpenFileName(&ofn)){ 
			return 0;
		}
	}

	strcpy(thename, FileName);
	
	return strlen(thename);
}

