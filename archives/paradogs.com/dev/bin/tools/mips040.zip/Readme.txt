MIPSiCE v0.40�

Sorry but no time to make a blabla
So use it by yourself...

Fennec
http://www.multimania.com/fennec/mipsice

Special greeting to k-communication for Caetla :)


