Use:

LB sample\mipsice.tim 80140000
LE sample\mipsice.psx 
F9 (F10 for trace mode)

Thanks to Hitmen for sources :)

