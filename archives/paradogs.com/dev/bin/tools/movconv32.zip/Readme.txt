= Movie Converter version 3.4   (6-Apr-99)

<< Movie Converter, mc32, ver. 3.4 >>
This module is available only under the Windows 95, 98 and Windows NT.
It doesn't operate under the Windows 3.1.

<< Contents of this package >>

	mc32.exe      Movie Converter version 3.4
	mc32.scr      Sample Script for Movie Converter
	readme_e.txt  this file

<< Installation >>
Please replace the previous versions of mc32.exe, mc32.scr 
with the new ones included in this package.  


<< Changes in version 3.4 >>
- Interleaving of the data file for the Multi Channel window and the 
 script file was not supported.
 This malfunction has been fixed.
- The expanded wav format such as including cbSize was not supported.
 This malfunction has been fixed.
- The file was not recognized correctly when a capital letter was 
 used for its extension in the file dialogue box..
 This malfunction has been fixed.
 

