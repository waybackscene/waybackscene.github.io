=== Movie Tools (09/05/97) ===

[ Contents of this package ]

    mc32.exe      movie converter version 3.0
    mc32.scr      sample script for movie converter 3.0
    readme_e.txt   this file

[ Installation ]

Please copy mc32.exe to the directory where other movie 
converters exist.

If you do not plan to use the following two features that have been
removed in the mc32 3.0, you can simply replace the MovConv with
mc32 3.0.

+ Q matrix setting capability
+ Vversion 1.98 leap sector capability 

[ Changes from MovConv 2.1 to mc32 3.0 ]

+ Encoding speed is about 4 to 5 times faster than the 
  previous versions.
+ Frame rate 12fps was added.
+ The following script functions were added.

    Rgb2bsC
    Rgb2bsV
    Rgb2bsAV
    Yuv2bsC
    Yuv2bsV
    Yuv2bsAV
    Tim2bsC
    Tim2bsV
    Tim2bsAV
    Yuv2avi
    Rgb2avi

+  Width and height of RGB/YUV image data came to be memorized.
+  Bs data size came not to be adjusted to sector boundaries.
+  Bs format was added as input data file format.
+  The user interface was changed.
+  Command line execution capability was added.

    Movie conveter can be run from command line without opening
    window.(Some of warning windows still open with this version.)
    For instance, movie converter script can be run in the
    following way.

    > mc32 -s script_file

    You can execute movie converter from your batch file using this
    capablity.

+ Drag and Drop can be used to open files.
+ Q matrix setting capability has been removed.
+ Vversion 1.98 leap sector capability has been removed.
+ Default value of Leap Sector check box has been changed from 'on' to 'off'.
+ Movie converter 3.0 can be run on Window 95/NT but on Windows 3.1.

[ Limitations of mc32 3.0 ]

+ Movie converter 3.0 can be run on Windows 95/NT but NOT on Windows 3.1.
+ Input AVI must be uncompressed AVI.
+ Sample length of sound must be 16 bits.


