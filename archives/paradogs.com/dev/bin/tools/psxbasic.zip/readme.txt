PSX Chipmunk BASIC 0.1.03B
http://perso.club-internet.fr/psxdev/
Xavier CANY, STDRAGUT (cany@brasil.brainstorm.fr)
Original Pascal source code by David Gillespie


   WHAT'S NEW IN 0.1.03B
       
       3D debbuged (not totally finished), now handles up to 256 objects
       plane, textured and semitransparent almost cleanly.
       (INIT3D, LOADTMD, SETOBJECT, COPYOBJECT, LINKOBJECT)
    
       Data access to CD-ROM and Memorycard, you can now load any kind of data
       from CD-ROM and access to the Memorycard file directory.
       (INITCARD, INITCD, FILES (see CONVENTIONS))
       
       Sprite attributes editing, manage transparency level.
       (SPRITEATTRIBUTE)
       
       Second PAD handling, not so much to say, it works fine now.
       (PAD1, PAD2)
       
       Stand alone capability, Yes you can combine your PSX BASIC sources, models,
       pictures, sound in a stand alone EXE. You can spread it and burn it on
       CD-ROM.
       (LOAD, LOADTIM, LOADTMD, LOADVAG (see MISC))

       Speed acceleration, Up to twice as fast on some commands, I gained 7
       seconds in bench.bas.
       

   PSX BASIC TEST PROGRAM

      Please report me any bugs, misfonction to
      cany@brasil.brainstorm.fr, please add [PSX BASIC] to your
      mail subject and give me a full description of the commands, or
      suit of commands that you enter.

      Feel free to give me any suggestion on commands, tools or fonctionality
      to add to this code.
      
      I will auto send you any new version of PSX BASIC by attached files, if
      you don't wish recieve futher version please tell me so in your mail.
      
      
      
   GETTING STARTED

      PSX BASIC is been developped under Pro Action Replay & Comms Link using
      Caetla ROMs.

      If you are using Caetla tools, just run : psexe psxbasic.exe
      
      Try >run "menu.bas" for testing purpose.
      
      If you succeed in using PSX BASIC with other AR ROM replacement or PSX
      configuration (Yaroze/SN System), please report this to me.

      NTSC users, if you don't see a thing, type >SETVIDEOMODE 0


   PSX BASIC COMMANDS

      LIST line(s)

         List the specified program lines.  For example,

               LIST 10, 100-200

         lists line 10, and lines 100 through 200, inclusive.


      RUN [line]

         Begin execution of the program at the first line, or at the
         specified line.  All variables are cleared.


      RUN file[,line]

         Load and run a program.  For example,

               RUN "FOO.BAS", 30

         loads a program from the file FOO.BAS and begins execution at
         line 30.


      NEW

         Erase the program in memory.


      LOAD file

         Load a program into memory.  The program previously in memory is
         erased.  The file name should be in quotes; Files contain ASCII listings 
         of the programs.
         All lines in the file must begin with a line number, but line
         numbers do not need to be in increasing order.

         -> Tips under windows, you can edit your basic source file under a window
            text editor then in a command window just type >load to reload last file.


      MERGE file

         Load a program into memory.  The previous program remains in
         memory; if a line exists in both programs, the newly loaded
         line is kept.


      SAVE file

         Save the program in memory to a file.


      FILES [wilcards]

         Display file directories


      BYE

         Return to the operating system.


      DEL line(s)

         Delete the specified program lines.  Line numbers may be
         separated by commas and dashes as in LIST.  If used inside
         a program, DEL will terminate execution only if it deletes
         the line on which it appears.


      RENUM [start[,inc]]

         Renumber program lines.  By default, the new sequence is 10,20,30,...
         The first argument is a new initial line number; the second argument
         is the increment between line numbers.


   STATEMENTS

      REM comment

         A remark; ignored.  Comments may contain any characters except
         that REM can not be immediately followed by an alphanumeric
         character.


      [LET] var = expr

         Assign a value to a variable.  Variable names contain up to 20
         significant characters, consisting of upper- and lower-case
         letters, digits, underscores, and dollar signs.  Variable names
         are case-sensitive.  Variables hold real numbers normally, or
         strings of up to 255 characters if their names end with $.

         Examples:

               LET X=20
               X$="FOO"
               X$=X$+"BAR"


      DIM var(dimensions), ...

         Allocate memory for arrays.  Arrays may have up to 4 dimensions,
         ranging from 0 to the value specified in the DIM statement.
         The same name must not be used for both a simple variable and
         an array.

         If an array is used before it is dimensioned, each dimension
         is set to 10.

         Example:

               INPUT "How many elements? "; x
               DIM array(x,1)
               FOR i=1 TO x : INPUT array(i,0), array(i,1) : NEXT


      PRINT items

         Print the items on the screen.  Items may be either numeric
         or string expressions, and may be separated by commas, semicolons,
         or nothing.

         The line is terminated by a CR/LF, unless the item list ends 
         with a comma or semicolon.

         The word PRINT may be abbreviated as a question mark.

         Examples:

               PRINT "1+2=", 1+2
               PRINT X$ "=" Z$;
               ? x; y+z


      INPUT [prompt;] vars

         If a prompt string is given, it is printed.  Otherwise, a
         question mark is printed.  The computer then waits for values 
         for each variable to be entered.  If several variables are
         listed, their names must be separated by commas.

         If the variables are numeric, their values may be entered
         on separate lines, or combined with commas.  Any numeric expression
         is a valid response.

         If the variables are strings, each string is typed on a separate
         line.  The characters typed are copied verbatim into the string.

         String and numeric variables may be not mixed in a single
         INPUT statement.

         Examples:

            INPUT X$
            INPUT "Type 3 numbers: "; X, Y, Z


      GOTO line

         Begin executing statements at the specified line.  The line
         number may be any numeric expression.

         The word GO TO may be used instead of GOTO if preferable.


      IF condition THEN line/statements ELSE line/statements

         If the condition is true (i.e., the numeric expression has a
         non-zero value), the statements following the word THEN are
         executed.  Otherwise, the statements following ELSE are
         executed.  If there is no ELSE clause, execution proceeds
         to the next line in the program.

         A line number may be used after either THEN or ELSE, for an
         implied GOTO statement.


      END

         Terminate the program.  An END statement is not required.


      STOP

         Terminate the program with an identifying "Break" message.


      FOR var = first TO last [STEP inc]
      {statements}
      NEXT [var]

         Execute {statements} repeatedly while the variable counts from
         "first" to "last," incrementing by 1, or by the STEP value if
         given.  If the STEP value is negative, the variable counts
         downward.

         If "first" is greater than "last" (or less than if STEP is
         negative), execution proceeds directly to the NEXT statement,
         without executing the body of the loop at all.

         The variable name is optional on the NEXT statement.


      WHILE [condition]
      {statements}
      WEND [condition]

         Execute {statements} repeatedly until the WHILE condition (if
         given) becomes false, or until the WEND condition becomes true.
         This structure can emulate Pascal's WHILE-DO and REPEAT-UNTIL,
         or even both at once.  If no conditions are given, the loop will
         never terminate unless the Evil GOTO is used.


      GOSUB line
      RETURN

         Execute the statements beginning at the specified line, then
         when RETURN is reached, return to the statement following the 
         GOSUB.


      READ vars
      DATA values
      RESTORE line

         Read numeric or string values from the DATA statements.  Reading
         begins at the first DATA statement in the program and proceeds
         to the last.  Reading past the end the last DATA statement
         generates an error.

         The DATA values must be either numeric or string expressions,
         according to the type of variable being read.  Reading the wrong
         kind of expression produces a Syntax Error.

         The RESTORE statement causes the next READ to re-use the first
         DATA statement in the program, or the first DATA statement on
         or after a particular line.


      ON expr GOTO line, line, ...
      ON expr GOSUB line, line, ...

         If the expression's value, rounded to an integer, is N, go to
         the Nth line number in the list.  If N is less than one or is
         too large, execution continues at the next statement after
         the ON-GOTO or ON-GOSUB.


      POKE addr, data

         Store a byte at the specified address.
         

   NUMERIC EXPRESSIONS

      x AND y

         Logical AND of two integers.


      x OR y

         Logical OR of two integers.


      x XOR y

         Logical XOR of two integers.


      NOT x

         Logical complement of an integer.


      x+y, x-y, x*y, x/y, x^y, -x

         Typical floating-point arithmetic operations.


      x=y, x<y, x>y, x<=y, x>=y, x<>y

         Comparisons; result is 1 if true, 0 if false.


      x MOD y

         Modulo of two integers.


      SQR x

         Square of X.  Note that parentheses are not required if a function's
         argument is a single entitity; for example, SQR SIN X needs no
         parentheses, but SQR(1+X) does.


      SQRT x

         Square root of X.


      SIN x, COS x, TAN x, ARCTAN x

         Typical trig functions, in radians.


      LOG x, EXP x

         Natural logarithm, and e the power X.


      ABS x

         Absolute value of X.


      SGN x

         Sign of X:  1 if X is positive, 0 if zero, -1 if negative.


      VAL x$

         Value of the expression contained in the string X$.  For example,
         VAL "1+2" yields 3.  X$ may be a single string literal, variable,
         or function, or a string expression in parentheses.


      ASC x$

         ASCII code of the first character in X$, or 0 if X$ is null.


      LEN x$

         Number of characters in X$.


      INT x

         Returns the closer integer of X. ( Ex: ENT 7.6  = 8 )
         
      
      ENT x
      
         Returns the integer portion of a numeric expression. ( Ex: ENT 7.6  = 7 )
         

      RANDOM x
      
         Returns an integer random number between 0 (inclusive) and X (exclusive).
         Where 0 <= X <= 32676.
         

      RND

         Generates a random number between 0 (inclusive) and 1 (exclusive).


      RANDOMIZE x
      
         Seeds the random number generators for RND and RANDOM.
        
                  
      TIMER

        May be use as value, TIMER is add 1 every 1/50s.


      Precedence:      Parentheses
                        Functions  (incl. NOT and unary minus)
                            ^
                        *, /, MOD
                          +, -
                   =, <, >, <=, >=, <>
                           AND
                         OR, XOR


   STRING EXPRESSIONS

      "string" or 'string'

         String literal.  Single quotes are converted to double quotes
         internally.


      x$+y$

         Concatenation.  Result must be 255 characters or less.


      x$=y$, x$<y$, x$>y$, x$<=y$, x$>=y$, x$<>y$

         String comparisons; result is 1 if true, 0 if false.


      STR$(x)

         The number X expressed as a string of digits.  No leading or
         trailing spaces are included; scientific notation is used
         if the absolute values is greater than 1E12 or less than 1E-2.


      CHR$(x)

         The character whose ASCII code is X.


      MID$(x$, y)
      MID$(x$, y, z)

         (Parentheses required.)  The substring consisting of the first
         Z characters starting at position Y of string X$.  Position 1
         is the first character of the string.  If Z is omitted, 255
         is used, i.e., the entire right part of the string.



   CONVENTIONS

      Multiple statements may be written on a line, separated by colons:

            10 INPUT X : PRINT X : STOP


      There is actually no difference between commands and statements;
      both can be used in or out of programs at will.  Certain commands,
      such as NEW, will, of course, halt program execution.


      Line numbers may be any integer from 1 to MAXINT.


      To delete a line use DEL, or type its line number alone:

            10


      To leave PSX BASIC, use the BYE command.
      
      To break in a running program, press [Start]+[Select] on PAD1. 

      Keywords must be written in all upper- or all lower-case; they are
      always converted to upper-case internally.  Spaces are ignored in
      the input except between quotes.  Square brackets are converted to
      parentheses.  Missing closing quotes at the end of the line are
      added, as in the command:

            SAVE "PROGRAM.BAS

       
       Loading conventions are :
       
               |    PC    |  CD-ROM  |   Memorycard    | Memory
       --------------------------------------------------------
       Device  | "pcdrv:" | "cdrom:" | "bu00:"/"bu01:" | "mem:"
       Inits   |          |  INITCD  |    INITCARD     |
       LOAD    |  default |     *    |                 |   *
       RUN     |  default |     *    |                 |   *
       SAVE    |  default |          |                 |    
       MERGE   |  default |     *    |                 |   *
       FILES   |  default |     *    |        *        |   *
       LOADTIM |  default |     *    |                 |   *
       LOADTMD |  default |     *    |                 |   *
       LOADVAG |  default |     *    |                 |   *

         Examples:

            LOADTIM "cdrom:garden.tim"
            FILES "bu00:*.*"
            RUN "mem:80100000"

      If you pre-load data in memory, please use space between :
      80100000 and 801FFFF0 PSX BASIC will load at 80010000


   PSX SCREEN/MISC COMMANDS

      FNTPRINT items

         Print the items on the PSX screen.  Items may be either numeric
         or string expressions, and may be separated by commas, semicolons,
         or nothing.

         The line is terminated by a CR/LF, unless the item list ends 
         with a comma or semicolon.
         
         You can only print 1024 characters at PSX screen, that include
         space en CR/LF.
      
      
      CLS
      
         Clear Text on PSX screen.
      

      VSYNC
      
         Wait for VSYNC.
         

      PAD1/PAD2
      
         Use as value, read Joy PAD 1 or 2, test out for values.
         
         Examples:

               10 WHILE PAD1 <> 1
               20 VSYNC
               30 FNTPRINT PAD1
               40 WEND


      INITCD
      
         Inits the CD file system.
         Must be called before using "cdrom:" in loading functions.


      INITCARD
      
         Inits the Memorycard file system.
         Must be called befor using "bu00:" - "bu01:" in loading functions.


      LOADTIM file
      
         Load file in tim format to the psx video memory.
      
         Examples:

               LOADTIM "GARDEN.TIM"


      SETSPRITE nbr, width, height
      
         Init sprite NBR with width and height,
         with 0 >= NBR >= 255.

         Examples:

               SETSPRITE 5,100,100

               
      SPRITEMAP nbr, mappagex, mappagey, offsetx, offsety, clutx, cluty, mode

        Init sprite NBR with texture to mappagex, mappagey page index
        at offset offsetx, offsety
        using clut (colors) at clutx, cluty
        in mode (0 = 4bit mode, 1 = 8bit mode, 2 = 16bit mode).

         Examples:

               SPRITEMAP 5,576,0,30,20,576,480,1

      
      SPRITEXY nbr, x, y

         Set sprite NBR coords to X and Y.


      SPRITEZ nbr, z

         Set sprite NBR zoom index to Z
         with -70 > Z > 70.
      

      SPRITER nbr, angle
      
         Set sprite NBR angle to angle
         with 0 > angle >360.


      SPRITEATTRIBUTE nbr, bf, r, g, b, tf, tr, sf
      
         Set NBR sprite attributes.
         
         BF, Brightness adjustment
           0: OFF 
           1: ON 
         TF, Semi-transparency ON/OFF 
           0: Semi-transparency OFF 
           1: Semi-transparency ON Bit 
         TR, Semi-transparency rate 
           0: 50% x Back + 50% x Sprite 
           1: 100% x Back + 100% x Sprite 
           2: 100% x Back + 50% x Sprite 
           3: 100% x Back - 100% x Sprite 
         SF: Rotation, enlargement, and reduction functions
           0: ON 
           1: OFF 
         

      SHOWSPRITE nbr
      
         Show sprite NBR.
      
      
      HIDESPRITE nbr
      
         Hide sprite NBR.
          
      
      CLEARSPRITE
      
         Hide all sprites.
         
      
      COPYSPRITE nbr1, nbr2
      
         Copy coords, size, map and indexs of sprite NBR1 to sprite NBR2.
         
         
      MOVEIMAGE x, y, w, h, x2, y2
      
         Transfers data between two locations within the video memory.
         X, Y, W (width) and H (height) describe the source rectangular area.
         X2, Y2 are the destinations coords.
         
         
      CLEARIMAGE x, y, w, h[, r, v, b]
      
         Clears a rectangular area inside the video memory specified by
         X, Y, W (width) and H (height) at OPTIONAL RGB color values indicated by
         R, G, B (with 0 > R,V,B > 255).


      INIT3D
      
         Inits the 3D systems, X:0 Y:0 will be the center of the screen for now-on.
         If omited, there must be some side effect that I don't know yet.
         

      LOADTMD file
      
         Load a object model bank in tmd format.
         Models can be link to 3D object using SETOBJECT or LINKOBJECT.
      
         Examples:

               LOADTMD "TOR.TMD"

      SETOBJECT nbr, model
      
         Init 3D object NBR with model MODEL,
         with 0 >= NBR >= 255.

         Examples:

               SETOBJECT 5,0


      LINKOBJECT nbr, model
      
         Change 3D object NBR model with MODEL,

         Examples:

               LINKOBJECT 5,1

               
      OBJECTXY nbr, x, y

         Set 3D object NBR coords X and Y.


      OBJECTZ nbr, z

         Set 3D object NBR coord Z


      OBJECTR nbr, rx, ry, rz
      
         Set 3D object NBR angle of x, y and z position 
         with 0 > RX,RY,RZ >64.
      

      SHOWOBJECT nbr
      
         Show 3D object NBR.
      
      
      HIDEOBJECT nbr
      
          Hide 3D object NBR.
          
      
      CLEARSOBJECT
      
         Hide all 3D object.
         

      COPYOBJECT nbr1, nbr2
      
         Copy coords, size and model of object NBR1 to objet NBR2.

            
      VIEWXY x, y

         Set view point coords (in 3D world) X and Y.


      VIEWZ z

         Set view point coords (in 3D world) Z.
         
      
      SETFLATLIGHT nbr,x, y, z[, r, v, b]
      
         Set flat light NBR coords (in 3D world) X, Y and Z.
         
         OPTIONAL R, V, B for light color.
         (with 0 > R,V,B > 255).


      SETAMBIENT r, v, b

         Set ambient light on 3D objects with R, V, B colors.
         (with 0 > R,V,B > 255).


      SETVIDEOMODE x
      
         Declares the video signaling system indicated by mode to the libraries.
         With X=0 for NTSC and X=1 for PAL.
         
         
      INITGRAPH x, y[, intl, dither, vram]
       
         Initializes the graphics system.
         X for horizontal resolution (256/320/384/512/640), Y for vertical resolution (240/480)

         OPTIONAL intl for Interlace display flag (bit 0)
                             0: Non-interlace GsNONINTER
                             1: Interlace GSINTER
                           Double buffer offset mode (bit 2)
                             0: GTE offset GsOFSGTE
                             1: GPU offset GsOFSGPU
                           GPU Initialize Parameter (bit 4-5)
                             0: ResetGraph(0) GsRESET0
                             3: ResetGraph(3) GsRESET3
                  dither Dithering processing flag where 0 is OFF, 1 is ON
                  vram VRAM mode where 0 is 16-bit and 1 is 24-bit
      
         If this is kligon to you, stik to X and Y parameters.
         
         
      DEFDISPBUFF x0, y0, x1, y1

         This function defines the display areas used for double-buffering.
         with X0, Y0 Buffer 0 origin point (top left point)
         and X1, Y1 Buffer 1 origin point (top left point)


      LOADVAG file, address

         Load file in vag format to specific address in audio memory.
      
         Examples:

               LOADVAG "OVERTURE.VAG",1000


      SETVOICE channel, address, speed, volume
      
         Start playing data at in sound channel at specific address,
         speed (4096 = 44100hz) and volume (max volume is 16383).
               (2048 = 22khz)
               (1536 = 16khz)
               (1024 = 11khz)
               ( 768 =  8khz etc...)

         Specific speed and volume control may be added in a near future.
         

   MISC
    
      Starting video mode is PAL (368x240).
      If you get tired of changing the video mode, use N!K's mode changer :
      http://napalm.intelinet.com/files/npm-mode.zip
      
      If you pre-load data in memory, please use space between :
                          0x80100000
                              ...
                              ...
                          0x801FFFF0
                          
      PSX BASIC will load from 0x8001000 and use allocation space
                            to 0x800E000
      

      Making Autorun/Stand-alone Program
      With a HEXA-code editor searh and edit the line:
      
                          ....REM AUTORUN 
                          You can edit thi
                          s line*.PSX Chip
      
      You can replace the command, starting from REM to the '*' with
      an autostart basic command such as:
      
                          ....RUN "MYPROG. 
                          BAS"............   <- End it all with 0x00
                          ......*.PSX Chip
      
      For CD-ROM Autorun, use :
                          
                          ....RUN "cdrom:M   
                          YBROG.BAS"......   Don't forget to load all 
                          ......*.........   your stuff from the CD   
                          
      For Stand-alone EXE, use :
      
                          ....RUN "mem:801 
                          00000"..........   0x80100000 would be your
                          ......*.PSX Chip   preloaded memory adresse
                          
                   See CONVENTIONS for memory loads of bas, tim, vag
                   and tdm files. Then combine all your stuff using
                   Combine v2.20 by Barubary, you can find it at:
                   http://napalm.intelinet.com/files/combine.zip


                          
      Greets goes to Danzig, Silpheed, Sigmund, Napalm, Hitmen
      Thanks goes to Silpheed, Djamm, Dines, Z, Off, Mike Bee
      Hellos goes to Charly, P@l@, PHD, XavierM, RolandB, Zarathushtra
      
      More Thanks for support to MAD, AxelM, JMoya, Barog, AnthonyB,
      Dmtry, ArnaudH, PaulC, Bliep, Brith, Rengen, Ronni, ThomasM,
      PaulI/mclane, kovax and Street TuFF.

      Cool URLs
      http://www.error-404.com/
      http://www.neverland.com/powerup/
      http://napalm.intelinet.com/
      http://www.geocities.com/SiliconValley/Lab/6332/
      http://www.hitmen-psx.ml.org/
      
      You want to learn MIPS, use SPIM
      ftp://ftp.cs.wisc.edu/pub/spim/
      
      Been working hard on that code, hope you'll like it...
      Ciao...

---
09/28/1998