/*
    This source code contains a simple patching routine that will
    take the Country Code Lockout patches from ICE_PSX.LZH
    archive and apply them to PSX ISO images to bypass the Country
    Authentication check.
    
    This utility will allow legimate PSX owners users with CDRs
    to modify PSX ISO images with the correct Country Code Lockout,
    so they can play foriegn CDs.

    *BorlandC 3.1 was used to compile this successfully.

    It is a crime to redistribute these routines in a commercial
    venture of any kind without permission or licensing agreement.

    (C)opyright 1995 Damaged Cybernetics

    If you have any questions or comments, please contact the
    following ppl via the Internet:

    Donald Moore   (MindRape)  mindrape@goodnet.com
    Donald Staheli (Royce)      staheli@goodnet.com

    Web Page: www.goodnet.com/~staheli

 */

#include <stdio.h>
#include <stdlib.h>


/* prototypes */
char PSXPatch(char *szFileName,char *szCountryPatch,unsigned long ulSkipBytes);
void help();

/* general definitions */
#define BUFFER_SIZE 4096

#define TRUE  1
#define FALSE 0

/*
   char PSXPatch(char *szFilename,char *szCountryPatch,unsigned long ulSkipBytes)
   ENT: char *szFileName          - ISO Image filename to patch
        char *szCountryPatch      - Country Code Lockout Patch
        unsigned long ulSkipBytes - Bytes to skip in case of ISO Header

   RET: TRUE  - Patching was successful
        FALSE - Patching was unsuccessful

   Read szCountryPatch and patch the first 5 sectors (0-4) of the ISO Image.
   Skip ulSkipBytes to bypass any possible headers, but normally this is
   0.

 */
char PSXPatch(char *szFilename,char *szCountryPatch,unsigned long ulSkipBytes)
{ FILE *dest;                          /* our destination file                       */
  FILE *patch;                         /* our country code lockout patch             */
  unsigned char acBuffer[BUFFER_SIZE]; /* buffer to hold our patch                   */
  unsigned int uiFileSize;             /* keep track of the bytes we copy from patch */


  /* open our destination file and our patch file */
  if ((dest = fopen(szFilename,"r+b")) == NULL)
    {
       printf("Cannot open input file: %s\n",szFilename);
       return(FALSE);
    }

  if ((patch = fopen(szCountryPatch,"rb")) == NULL)
    {
      printf("Cannot open input file: %s\n",szCountryPatch);
      return(FALSE);
    }

  /* now skip ulSkipBytes, users will need to skip any ISO image
     headers that may exist.
   */
  fseek(dest,ulSkipBytes,SEEK_SET);
  
  /* now copy the patch over the first 5 sectors of the REAL PSX image */
  while (!feof(patch))
    {
       uiFileSize = fread(acBuffer,1,BUFFER_SIZE,patch);
       fwrite(acBuffer,1,uiFileSize,dest);
    }

  fcloseall();   /* close everything down */

  return(TRUE);
}

void help(void)
{
  printf("PSX Immigrator was designed to patch PSX ISO Images with the correct\n"
         "Country Code Lock patch.  It does not recognize Win'95 Long File Names.\n\n"
         "Usage: PSXISO <source.iso> <patch.raw> <starting offset>\n\n"
         "source.iso      - PSX ISO Image\n"
         "patch.raw       - Country Code Lockout\n"
         "starting offset - Start Location of the REAL PSX ISO images."
        );
}


void main(int argc,char *argv[])
{
   puts("PSX Immigrator Version 1.0\n(C) 1995 Damaged Cybernetics (www.goodnet.com/~staheli)\n");

   if (argc < 4)
     {
        help();
        exit(1);
     }
  
  printf("Patching %s.\n"
         "Using %s as a Country Code Lockout patch.\n"
         "Skipping %u bytes...\n",argv[1],argv[2],atol(argv[3])
        );

  if (PSXPatch(argv[1],argv[2],atol(argv[3])))
    puts("Successful Patch.");
  else
    puts("Unsuccessful patch.");
}



