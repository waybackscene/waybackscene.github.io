
Roller Coaster v1.1 Docs
------------------------

Web Site: HTTP://WWW.ANTHROX.COM

E-mail: paninaro@tnp.com

Roller Coaster is a program that allows you to generate sine data tables and random numbers.

Roller Coaster requires Windows 95 or Windows NT 4.0+ 
It was written by -Pan- of Anthrox, with thanks to Adam (NiN) for the help and the unknowing
encouragement which is a story in itself! With out his need for a dos tool this would never
have been done (I told ya the math was right!).

Visit the Anthrox web site at http://www.anthrox.com

By the way, if i haven't mentioned it. I MADE THIS TOOL. IT'S MINE! DON'T GET ANY FUNNY
BUSINESS OF DISTRIBUTING IT WITHOUT MY KNOWLEDGE! Other than that, you can use it without
payment. And if you are using it to make a demo or java applet or even a professional or
non-professional game, please e-mail at paninaro@tnp.com .  I would LOVE to hear that you
have used this tool. I didn't make it for my health or wealth you know! :)





Creating A Sine Wave
--------------------
You enter the starting angle, the ending angle, the number of values you want to create,
the lowest value number and the highest value number. It will create a sine wave when
you press SINE.  You can do this on the A column and the B column.
Data displayed in the graphics area may contain a baseline. This is to tell you where
line 0 is located. This way you can tell how much of a sine wave is negative or positive.
It is especially usefull when blending two sine waves (see below).



Blending Sine Waves
-------------------
Create two different sine waves, one in column A, the other in column B. Make sure the
number of values is EQUAL for both A and B or it won't work!
Now select a mathematical function to perform on the sine tables.
You can select A+B, A+B/2, A-B, B-A, or MIX in the C column.

Really Messing Around With Sine Waves
-------------------------------------
After creating a blended sine wave move the new sine wave to another column with the 
<-A  or B-> buttons. Now select a mathematical function on the sine tables again. 
You can select different ones to see the outcome. Pick the one you like and move it to
another column again and restart the whole process until you come up with a really interesting
sine wave!

Beware The Min and Max Values!
------------------------------
Watch the NEW Min and Max values in column C that are created after doing a mathematical
function to them. The may not be the same, but could be within the range you want.


Creating Random Numbers
-----------------------
Set the number of values, and the min and max value. Press RND. It will generate random
numbers for you.

Creating TRUE RANDOM numbers
----------------------------
Set the number of values, and make sure the min val and the max value range DO NOT GO BELOW
the number of values. For instance, if you set the number of values to 256, the min val to
1 and the max val to 64 the program CAN NOT create totally unique Integers. You can set
the range of values higher than number of values. Press True RND.

Note: since it may be probable that a unique number can not be created due the laws of 
probability, I have set a limit of five tries. If it can not create a unique number within five
tries it will fail and an X will appear in the graphics window. Simply press the True RND button
again. If the numbers of values is LARGE you may not have a good chance of creating a table. 
But try again if you want to.


Saving The Sine Data Table
--------------------------
You can only save the data that is in column C. If you made a sine wave or random data in
column A or B, please move the data to column C by using the A or B button in column C.
To copy data from A to C, press A. To copy from B to C, press B.

Select the data type you want. You can select Integer, Rounded Number, Floating Point, 
and Short Floating Point.

An Integer will simply truncate the numbers to the right of the decimal point.

A Rounded Number will round off the decimal data to a whole number. This makes a better
looking wave if you don't intend on using decimals!

A Floating Point number contains long decimal numbers.

A Short Floating Point reduces it to just 4 decimal places.


Now select the data type you will put in the sine table list for use in your source
code.   I'm used to seeing dc.b and dcb in assemblers, but I also included a custom
feature just in case you need to use a different one. To select a custom data type
just select Custom and put in what you want in front of the list.

Now select if you want to Save To File or Save To Clipboard. Saving to the Clipboard
will allow you to easily paste it into your source code.

The output may look like this:
DC.B  128,  131,  134,  137,  140,  143,  146,  149
DC.B  152,  155,  158,  161,  164,  167,  170,  173
DC.B  176,  179,  182,  185,  187,  190,  193,  196
DC.B  198,  201,  203,  206,  208,  211,  213,  215
DC.B  217,  220,  222,  224,  226,  228,  230,  232
DC.B  233,  235,  237,  238,  240,  241,  243,  244
DC.B  245,  246,  247,  248,  249,  250,  251,  252
DC.B  252,  253,  254,  254,  254,  255,  255,  255
DC.B  255,  255,  255,  255,  254,  254,  254,  253
DC.B  253,  252,  251,  251,  250,  249,  248,  247
DC.B  246,  244,  243,  242,  240,  239,  237,  236
DC.B  234,  232,  230,  228,  227,  225,  223,  220
DC.B  218,  216,  214,  211,  209,  207,  204,  202
DC.B  199,  196,  194,  191,  188,  186,  183,  180
DC.B  177,  174,  171,  168,  165,  162,  159,  156
DC.B  153,  150,  147,  144,  141,  138,  135,  132
DC.B  129,  125,  122,  119,  116,  113,  110,  107
DC.B  104,  101,  98,  95,  92,  89,  86,  83
DC.B  80,  77,  74,  71,  69,  66,  63,  60
DC.B  58,  55,  53,  50,  48,  45,  43,  41
DC.B  38,  36,  34,  32,  30,  28,  26,  24
DC.B  22,  21,  19,  17,  16,  14,  13,  12
DC.B  10,  9,  8,  7,  6,  5,  4,  3
DC.B  3,  2,  2,  1,  1,  0,  0,  0
DC.B  0,  0,  0,  0,  0,  1,  1,  2
DC.B  2,  3,  3,  4,  5,  6,  7,  8
DC.B  9,  10,  11,  13,  14,  16,  17,  19
DC.B  20,  22,  24,  26,  28,  30,  32,  34
DC.B  36,  38,  40,  43,  45,  47,  50,  52
DC.B  55,  58,  60,  63,  66,  68,  71,  74
DC.B  77,  80,  83,  86,  88,  91,  94,  97
DC.B  101,  104,  107,  110,  113,  116,  119,  122


