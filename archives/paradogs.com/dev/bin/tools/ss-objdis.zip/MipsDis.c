#include	<stdio.h>
#include	<stdlib.h>
#include	<stdarg.h>
#include	<string.h>

#include	"types.h"

int	iSymbolNumber=1000000;

void	Error( const char *s, ... )
{
	char	temp[256];
	va_list	list;

	list=va_start( list, s );
	vsprintf( temp, s, list );
	fprintf( stderr, "*ERROR* : %s\n", temp );
	va_end( list );
	exit( EXIT_FAILURE );
}

ULONG	fgetll( FILE *f )
{
	ULONG	r;

	r =fgetc(f);
	r|=fgetc(f)<<8;
	r|=fgetc(f)<<16;
	r|=fgetc(f)<<24;

	return( r );
}

UWORD	fgetlw( FILE *f )
{
	UWORD	r;

	r =fgetc(f);
	r|=fgetc(f)<<8;

	return( r );
}

typedef	enum
{
	OP_CONSTANT,
	OP_SECTBASE,
	OP_ADDROFSYMBOL,
	OP_ADD,
}	EOperator;

typedef	enum
{
	PATCH_LONG,
	PATCH_MIPSLO,
	PATCH_MIPSHI,
	PATCH_MIPSGP
}	EPatchType;

typedef	struct	_SExpression
{
	EOperator	Operator;

	SLONG	iValue;
	struct	_SExpression	*pLeft;
	struct	_SExpression	*pRight;
}	SExpression;

typedef	struct	_SPatch
{
	EPatchType	Type;
	SExpression	*pExpr;
	ULONG		iOffset;

	struct	_SPatch	*pNext;
}	SPatch;

typedef	enum
{
	SYM_XDEF,
	SYM_XREF,
	SYM_XBSS,
	SYM_LOCAL
}	ESymbolType;

typedef	struct	_SSymbol
{
	char		sName[256];
	ULONG		iOffset;
	ULONG		iNumber;
	ULONG		iSize;
	ESymbolType	Type;

	struct	_SSymbol	*pNext;
}	SSymbol;

typedef	struct	_SSection
{
	char	sName[256];
	ULONG	iAlign;
	UWORD	iGroup;
	ULONG	iNumber;

	UBYTE	*pData;
	ULONG	iSize;

	struct	_SSection	*pNext;
	SPatch				*pPatches;
	SSymbol				*pSymbols;
	int		oDumped;
}	SSection;

void	Disassemble( SSection *pSect );
void	ByteDump( SSection *pSect );
void	BSSDump( SSection *pSect );

SSymbol		*CreateSymbol( SSection *pSect, ESymbolType iType )
{
	SSymbol	*s;

	s=malloc( sizeof(SSymbol) );
	s->pNext=pSect->pSymbols;
	s->Type=iType;

	pSect->pSymbols=s;

	return s;
}

SPatch		*CreatePatch( SSection *pSect, EPatchType iType )
{
	SPatch	*p;

	p=malloc( sizeof(SPatch) );
	p->pNext=pSect->pPatches;
	p->pExpr=NULL;
	p->Type=iType;

	pSect->pPatches=p;

	return p;
}

SExpression	*Expr_Constant( SLONG iConst )
{
	SExpression	*expr;

	expr=malloc( sizeof(SExpression) );
	expr->pLeft=NULL;
	expr->pRight=NULL;
	expr->iValue=iConst;
	expr->Operator=OP_CONSTANT;

	return expr;
}

SExpression	*Expr_SectBase( UWORD iSect )
{
	SExpression	*expr;

	expr=malloc( sizeof(SExpression) );
	expr->pLeft=NULL;
	expr->pRight=NULL;
	expr->iValue=iSect;
	expr->Operator=OP_SECTBASE;

	return expr;
}

SExpression	*Expr_AddrOfSymbol( ULONG iSymbol )
{
	SExpression	*expr;

	expr=malloc( sizeof(SExpression) );
	expr->pLeft=NULL;
	expr->pRight=NULL;
	expr->iValue=iSymbol;
	expr->Operator=OP_ADDROFSYMBOL;

	return expr;
}

SExpression	*Expr_Add( SExpression *pLeft, SExpression *pRight )
{
	SExpression	*expr;

	expr=malloc( sizeof(SExpression) );
	expr->pLeft=pLeft;
	expr->pRight=pRight;
	expr->Operator=OP_ADD;

	return expr;
}

SExpression	*ReadExpression( FILE *f )
{
	int	op;

	op=fgetc( f );

	switch( op )
	{
		case	0x00:
			return Expr_Constant(fgetll(f));
			break;
		case	0x02:
			return Expr_AddrOfSymbol(fgetlw(f));
			break;
		case	0x04:
			return Expr_SectBase(fgetlw(f));
			break;
		case	0x2C:
			return Expr_Add(ReadExpression(f),ReadExpression(f));
			break;
		default:
			Error( "Unsupported op 0x%02X in patch at 0x%X", op, ftell( f ) );
			break;
	}

	//	args:
	//	0, constant(LONG)
	//	4, sectbase(WORD)

	return NULL;
}

SSection	*pSections=NULL;

SSection	*GetSection( ULONG iID )
{
	SSection	**ppSect=&pSections;

	while( *ppSect )
	{
		if( (*ppSect)->iNumber==iID )
		{
			return *ppSect;
		}
		ppSect=&((*ppSect)->pNext);
	}

	*ppSect=malloc(sizeof(SSection));
	(*ppSect)->pNext=NULL;
	(*ppSect)->iNumber=iID;
	(*ppSect)->pData=NULL;
	(*ppSect)->iSize=0;
	(*ppSect)->pPatches=NULL;
	(*ppSect)->pSymbols=NULL;
	(*ppSect)->oDumped=0;

	return *ppSect;
}

void	SectionDump( SSection *pSect )
{
	if( pSect->oDumped )
		return;

	if( pSect->iNumber==0 )
	{
		SSymbol	*pSym;

		pSym=pSect->pSymbols;
		while( pSym )
		{
			printf( "\tXREF\t%s\n", pSym->sName );
			pSym=pSym->pNext;
		}
		printf( "\n" );
	}
	else
	{
		if( (strcmp(pSect->sName,".text")==0)
		||	(strcmp(pSect->sName,".ctors")==0)
		||	(strcmp(pSect->sName,".dtors")==0) )
		{
			printf( "\tSECTION\t%s\n\n", pSect->sName );
			Disassemble( pSect );
			pSect->oDumped=1;
			printf( "\n\n\n\n" );
		}
		else if( (strcmp(pSect->sName,".data")==0)
		||		 (strcmp(pSect->sName,".rdata")==0)
		||		 (strcmp(pSect->sName,".sdata")==0) )
		{
			printf( "\tSECTION\t%s\n\n", pSect->sName );
			ByteDump( pSect );
			pSect->oDumped=1;
			printf( "\n\n\n\n" );
		}
		else if( (strcmp(pSect->sName,".sbss")==0)
		||		 (strcmp(pSect->sName,".bss")==0) )
		{
			printf( "\tSECTION\t%s\n\n", pSect->sName );
			BSSDump( pSect );
			pSect->oDumped=1;
			printf( "\n\n\n\n" );
		}
		else
		{
			printf( "\tSECTION\t%s\n\n", pSect->sName );
			printf( "; NOT IMPLEMENTED\n\n\n\n" );
		}
	}
}

char	*reg[32]=
{
	"zero", "at", "v0", "v1", "a0", "a1", "a2", "a3",
	"t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
	"s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
	"t8", "t9", "k0", "k1", "gp", "sp", "s8", "ra"
};

void	PrintUsage( void )
{
	printf( "ObjDis V1.1 by SurfSmurf . >(oo)<\n"
			"\n"
			"Usage: ObjDis file.obj\n" );
	exit( 0 );
}

void	FreeExpression( SExpression *pExpr )
{
	if( pExpr )
	{
		FreeExpression( pExpr->pLeft );
		FreeExpression( pExpr->pRight );
		free( pExpr );
	}
}

void	FixPatchesAndSymbols( void )
{
	SSection	*pSect;

	pSect=pSections;

	while( pSect )
	{
		SPatch	*pPatch;

		pPatch=pSect->pPatches;
		while( pPatch )
		{
			SExpression	*pExpr=pPatch->pExpr;

			if( pExpr->Operator==OP_ADD
			&&	(	(pExpr->pLeft->Operator==OP_SECTBASE
					&&	pExpr->pRight->Operator==OP_CONSTANT)
				||	(pExpr->pRight->Operator==OP_SECTBASE
					&&	pExpr->pLeft->Operator==OP_CONSTANT)))
			{
				SExpression	*pSectExpr;
				SExpression	*pConstExpr;
				SSymbol		*pSym;
				SSection	*pSymSect;

				pSectExpr=pExpr->pLeft;
				pConstExpr=pExpr->pRight;

				if( pSectExpr->Operator!=OP_SECTBASE )
				{
					SExpression	*t;

					t=pSectExpr;
					pSectExpr=pConstExpr;
					pConstExpr=t;
				}

				pSymSect=GetSection( pSectExpr->iValue );

				pSym=pSymSect->pSymbols;
				while( pSym )
				{
					if( pSym->iOffset==pConstExpr->iValue )
						break;
					pSym=pSym->pNext;
				}

				if( pSym==NULL )
				{
					pSym=CreateSymbol( pSymSect, SYM_LOCAL );
					pSym->iNumber=iSymbolNumber;
					pSym->iOffset=pConstExpr->iValue;
					sprintf( pSym->sName, "%s_%X", pSymSect->sName+1, pSym->iOffset );
					iSymbolNumber+=1;
				}
				FreeExpression( pExpr );
				pPatch->pExpr=Expr_AddrOfSymbol( pSym->iNumber );

			}

			pPatch=pPatch->pNext;
		}
		pSect=pSect->pNext;
	}
}

void	FixRelativeJumps( SSection *pSect );

int	main( int argc, char *argv[] )
{
	SSection	*pCurrentSection=NULL;
	FILE	*f;
	ULONG	id;
	int		ok=1;
	int		totalsections=0;
	int		PatchOffset=0;

	if( argc==1 )
		PrintUsage();

	if( (f=fopen(argv[1],"rb"))==NULL )
		Error( "File \"%s\" not found", argv[1] );

	id=fgetll( f );
	if( id!=0x024B4E4C )
		Error( "Not an object-file" );

	while( ok )
	{
		int	chunk;

		chunk=fgetc( f );
		switch( chunk )
		{
			case	0:
			{
				ok=0;
				break;
			}
			case	2:
			{
				//	Code
				int	len;

				len=fgetlw( f );
				pCurrentSection->pData=realloc( pCurrentSection->pData, pCurrentSection->iSize+len );
				fread( pCurrentSection->pData+pCurrentSection->iSize, 1, len, f );
				pCurrentSection->iSize+=len;
				break;
			}
			case	6:
			{
				//	Switch to section
				int	id;

				id=fgetlw( f );
				pCurrentSection=GetSection( id );
				PatchOffset=pCurrentSection->iSize;
				break;
			}
			case	8:
			{
				//	Uninitialised data
				int	size;

				size=fgetll( f );

				pCurrentSection->iSize+=size;
				break;
			}
			case	10:
			{
				//	Patch
				int			type;
				int			offset;
				EPatchType	ntype;
				SPatch	*p;

				type=fgetc( f );
				offset=fgetlw( f );

				switch( type )
				{
					case	16:
						ntype=PATCH_LONG;
						break;
					case	74:
						ntype=PATCH_LONG;
						break;
					case	82:
						ntype=PATCH_MIPSHI;
						break;
					case	84:
						ntype=PATCH_MIPSLO;
						break;
					case	100:
						ntype=PATCH_MIPSGP;
						break;
					default:
						Error( "Patch type %d at 0x%X unsupported", type, ftell(f) );
				}
				p=CreatePatch( pCurrentSection, ntype );
				p->iOffset=offset+PatchOffset;
				p->pExpr=ReadExpression( f );

				break;
			}
			case	12:
			{
				//	XDEF symbol
				int		number;
				int		section;
				int		len;
				ULONG	offset;
				SSymbol	*pSym;

				number=fgetlw( f );
				section=fgetlw( f );
				offset=fgetll( f );

				pSym=CreateSymbol(GetSection(section),SYM_XDEF);
				pSym->iOffset=offset;
				pSym->iNumber=number;
				len=fgetc(f);
				fread( pSym->sName, 1, len, f );
				pSym->sName[len]=0;
				break;
			}
			case	14:
			{
				//	XREF symbol
				int		number;
				int		len;

				SSymbol	*pSym;

				number=fgetlw( f );

				pSym=CreateSymbol(GetSection(0),SYM_XREF);
				pSym->iNumber=number;
				len=fgetc(f);
				fread( pSym->sName, 1, len, f );
				pSym->sName[len]=0;
				break;
			}
			case	16:
			{
				//	Create section
				SSection	*pSect;
				int			len;
				int			id;

				pSect=GetSection( id=fgetlw(f) );
				pSect->iGroup=fgetc( f );	//	GROUP
				pSect->iAlign=fgetlw( f );	//	ALIGNMENT

				len=fgetc( f );
				fread( pSect->sName, 1, len, f );
				pSect->sName[len]=0;

				if( id>totalsections )
				{
					totalsections=id;
				}
				break;
			}
			case	18:
			{
				//	LOCAL symbol
				int		section;
				int		len;
				ULONG	offset;
				SSymbol	*pSym;

				section=fgetlw( f );
				offset=fgetll( f );

				pSym=CreateSymbol(GetSection(section),SYM_LOCAL);
				pSym->iOffset=offset;
				pSym->iNumber=iSymbolNumber++;
				len=fgetc(f);
				fread( pSym->sName, 1, len, f );
				pSym->sName[len]=0;
				break;
			}
			case	28:
			{
				//	File number and name
				int	number;
				int	len;

				number=fgetlw( f );
				len=fgetc( f );
				fseek( f, len, SEEK_CUR );

				break;
			}
			case	46:
			{
				//	CPU type

				int	cpu;
				cpu=fgetc( f );
				if( cpu!=7 )
					Error( "CPU type %d not supported", cpu );
				break;
			}
			case	48:
			{
				//	XBSS symbol
				int		number;
				int		section;
				int		len;
				ULONG	size;
				SSymbol	*pSym;
				SSection	*pSect;

				number=fgetlw( f );
				section=fgetlw( f );
				size=fgetll( f );

				pSect=GetSection(section);

				pSym=CreateSymbol(pSect,SYM_XBSS);
				pSym->iOffset=pSect->iSize;
				pSym->iSize=size;
				pSect->iSize+=size;
				pSym->iNumber=number;
				len=fgetc(f);
				fread( pSym->sName, 1, len, f );
				pSym->sName[len]=0;
				break;

			}
			default:
				Error( "Chunk %d at 0x%X not supported", chunk, ftell(f) );
		}
	}

	printf( "\tOPT\tc+,at-,m-\n"
			"\n"
			"\txref\t__SN_GP_BASE\n"
			"\n" );

	FixPatchesAndSymbols();
	SectionDump( GetSection(0) );
	pCurrentSection=pSections;
	while( pCurrentSection )
	{
		if( strcmp(pCurrentSection->sName,".text")==0 )
		{
			FixRelativeJumps( pCurrentSection );
		}
		pCurrentSection=pCurrentSection->pNext;
	}

	pCurrentSection=pSections;
	while( pCurrentSection )
	{
		if( (pCurrentSection->iNumber!=0)
		&&	(	(strcmp(pCurrentSection->sName,".sbss")==0)
			||	(strcmp(pCurrentSection->sName,".sdata")==0)) )
		{
			SectionDump( pCurrentSection );
		}
		pCurrentSection=pCurrentSection->pNext;
	}

	printf(	"\tASSUME\tgp:__SN_GP_BASE,.sdata,.sbss\n"
			"\n" );
	pCurrentSection=pSections;
	while( pCurrentSection )
	{
		if( pCurrentSection->iNumber!=0 )
		{
			SectionDump( pCurrentSection );
		}
		pCurrentSection=pCurrentSection->pNext;
	}

//	getchar();

	fclose( f );

	return EXIT_SUCCESS;
}

void	DumpLong( ULONG data )
{
	printf( "DW\t$%08X", data );
}

SSymbol	*GetSymbol( ULONG iID )
{
	SSection	*pSect;

	pSect=pSections;
	while( pSect )
	{
		SSymbol	*pSym;

		pSym=pSect->pSymbols;
		while( pSym )
		{
			if( pSym->iNumber==iID )
			{
				return pSym;
			}
			pSym=pSym->pNext;
		}
		pSect=pSect->pNext;
	}

	return NULL;
}

char	*GetSymbolName( SSection *pSect, ULONG iOffset, SLONG iRel )
{
	static	char	temp[256];
	SSymbol	*pSym;

	iOffset+=iRel;

	pSym=pSect->pSymbols;
	while( pSym )
	{
		if( pSym->iOffset==iOffset )
		{
			sprintf( temp, "%s", pSym->sName );
			return temp;
		}
		pSym=pSym->pNext;
	}

	sprintf( temp, "*%+d", iRel );
	return temp;
}

char	*FormatExpr( SExpression *pExpr, char *pBuf )
{
	switch( pExpr->Operator )
	{
		case	OP_CONSTANT:
			sprintf( pBuf, "$%X", pExpr->iValue );
			break;
		case	OP_SECTBASE:
			sprintf( pBuf, "sectbase(%s)", GetSection(pExpr->iValue)->sName );
			break;
		case	OP_ADDROFSYMBOL:
			sprintf( pBuf, "%s", GetSymbol(pExpr->iValue)->sName );
			break;
		case	OP_ADD:
			pBuf=FormatExpr( pExpr->pLeft, pBuf );
			sprintf( pBuf, "+" );
			pBuf+=1;
			pBuf=FormatExpr( pExpr->pRight, pBuf );
			break;
	}

	return pBuf+strlen(pBuf);
}

char	*WordPatch( SPatch *pPatch, const char *fmt, ULONG data )
{
	static	char	temp[256];

	if( pPatch )
	{
		char	*s=temp;

		if( pPatch->Type==PATCH_MIPSLO )
		{
			strcpy( s, "_lo(" );
			s+=strlen(s);
			s=FormatExpr( pPatch->pExpr, s );	
			strcpy( s, ")" );
		}
		else if( pPatch->Type==PATCH_MIPSHI )
		{
			strcpy( s, "_hi(" );
			s+=strlen(s);
			s=FormatExpr( pPatch->pExpr, s );	
			strcpy( s, ")" );
		}
		else if( pPatch->Type==PATCH_MIPSGP )
		{
			//strcpy( s, "_gp(" );
			//s+=strlen(s);
			s=FormatExpr( pPatch->pExpr, s );
			//strcpy( s, ")" );
			strcpy( s, "\t;" );
		}
		else
		{
			s=FormatExpr( pPatch->pExpr, s );	
		}
	}
	else
	{
		sprintf( temp, fmt, data );
	}

	return temp;
}

void	Disassemble( SSection *pSect )
{
	ULONG	index=0;
	ULONG	size;
	ULONG	PC=0;
	SSymbol	*pSym;

	pSym=pSect->pSymbols;
	while( pSym )
	{
		if( pSym->Type==SYM_XDEF )
		{
			printf( "\tXDEF\t%s\n", pSym->sName );
		}
		pSym=pSym->pNext;
	}

	size=pSect->iSize;

	while( size )
	{
		ULONG	data;
		ULONG	code1,
				code2;
		SPatch	*pPatch;

		pSym=pSect->pSymbols;
		while( pSym )
		{
			if( pSym->iOffset==index )
			{
				if( pSym->Type==SYM_XDEF )
				{
					printf( "\n" );
				}
				printf( "%s:\n", pSym->sName );
				break;
			}
			pSym=pSym->pNext;
		}

		pPatch=pSect->pPatches;
		while( pPatch )
		{
			if( (pPatch->iOffset>=index) && (pPatch->iOffset<=index+3) )
			{
				break;
			}
			pPatch=pPatch->pNext;
		}

		data =pSect->pData[index++];
		data|=pSect->pData[index++]<<8;
		data|=pSect->pData[index++]<<16;
		data|=pSect->pData[index++]<<24;
		size-=4;

		printf( "\t" );
		PC+=4;

		code1=(data>>29)&0x7;
		code2=(data>>26)&0x7;

		switch( code1 )
		{
			case 0:
				switch( code2 )
				{
					case 0:
						//	SPECIAL function
						{
							ULONG	code3,
									code4;

							code3=(data>>3)&0x7;
							code4=(data>>0)&0x7;

							switch( code3 )
							{
								case 0:
									switch( code4 )
									{
										case 0:
											if( data==0 )
												printf( "nop" );
											else
												printf( "sll\t%s,%s,%d", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], (data>>6)&0x1F );
											break;
										case 2:
											printf( "srl\t%s,%s,%d", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], (data>>6)&0x1F );
											break;
										case 3:
											printf( "sra\t%s,%s,%d", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], (data>>6)&0x1F );
											break;
										case 4:
											printf( "sllv\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], reg[(data>>21)&0x1F] );
											break;
										case 6:
											printf( "srlv\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], reg[(data>>21)&0x1F] );
											break;
										case 7:
											printf( "srav\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>16)&0x1F], reg[(data>>21)&0x1F] );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								case 1:
									switch( code4 )
									{
										case 0:
											printf( "jr\t%s", reg[(data>>21)&0x1F] );
											break;
										case 1:
											printf( "jalr\t%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F] );
											break;
										case 4:
											printf( "syscall\t$%X", (data>>6)&0xFFFFF );
											break;
										case 5:
											printf( "break\t$%X", (data>>6)&0xFFFFF );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								case 2:
									switch( code4 )
									{
										case 0:
											printf( "mfhi\t%s", reg[(data>>11)&0x1F] );
											break;
										case 1:
											printf( "mthi\t%s", reg[(data>>11)&0x1F] );
											break;
										case 2:
											printf( "mflo\t%s", reg[(data>>11)&0x1F] );
											break;
										case 3:
											printf( "mtlo\t%s", reg[(data>>11)&0x1F] );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								case 3:
									switch( code4 )
									{
										case 0:
											printf( "mult\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 1:
											printf( "multu\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 2:
											printf( "div\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 3:
											printf( "divu\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								case 4:
									switch( code4 )
									{
										case 0:
											printf( "add\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 1:
											if( ((data>>16)&0x1F)==0 )
												printf( "move\t%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F] );
											else
												printf( "addu\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 2:
											printf( "sub\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 3:
											printf( "subu\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 4:
											printf( "and\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 5:
											printf( "or\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 6:
											printf( "xor\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 7:
											printf( "nor\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
									}
									break;
								case 5:
									switch( code4 )
									{
										case 2:
											printf( "slt\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 3:
											printf( "sltu\t%s,%s,%s", reg[(data>>11)&0x1F], reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								case 6:
									switch( code4 )
									{
										case 0:
											printf( "tge\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 1:
											printf( "tgeu\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 2:
											printf( "tlt\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 3:
											printf( "tltu\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 4:
											printf( "teq\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										case 6:
											printf( "tne\t%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F] );
											break;
										default:
											DumpLong( data );
											break;
									}
									break;
								default:
									DumpLong( data );
									break;
							}
						}
						break;
					case 1:
					//	REGIMM function
					{
						ULONG	code3,
								code4;

						code3=(data>>19)&0x3;
						code4=(data>>16)&0x7;

						switch( code3 )
						{
							case 0:
								switch( code4 )
								{
									case 0:
										printf( "bltz\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
										break;
									case 1:
										printf( "bgez\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
										break;
									case 2:
										printf( "bltzl\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
										break;
									case 3:
										printf( "bgezl\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
										break;
									default:
										DumpLong( data );
										break;
								}
								break;
							default:
								DumpLong( data );
								break;
						}
						break;
					}
					case 2:
						printf( "j\t%s", WordPatch(pPatch,"$%07X", ((data&0x03FFFFFF)<<2)) );
						break;
					case 3:
						printf( "jal\t%s", WordPatch(pPatch,"$%07X", ((data&0x03FFFFFF)<<2)) );
						break;
					case 4:
						if( ((data>>16)&0x1F)==0 )
							printf( "beqz\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						else
							printf( "beq\t%s,%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 5:
						if( ((data>>16)&0x1F)==0 )
							printf( "bnez\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						else
							printf( "bne\t%s,%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 6:
						printf( "blez\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 7:
						printf( "bgtz\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
				}
				break;
			case 1:
				switch( code2 )
				{
					case 0:
						printf( "addi\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"%d",(SWORD)data) );
						break;
					case 1:
						if( ((data>>21)&0x1F)==0 )
							printf( "li\t%s,%s", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data) );
						else
							printf( "addiu\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"%d",(SWORD)data) );
						break;
					case 2:
						printf( "slti\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"%d",(SWORD)data) );
						break;
					case 3:
						printf( "sltiu\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"%d",(SWORD)data) );
						break;
					case 4:
						printf( "andi\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"$%04X",(UWORD)data) );
						break;
					case 5:
						printf( "ori\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"$%04X",(UWORD)data) );
						break;
					case 6:
						printf( "xori\t%s,%s,%s", reg[(data>>16)&0x1F], reg[(data>>21)&0x1F], WordPatch(pPatch,"$%04X",(UWORD)data) );
						break;
					case 7:
						printf( "lui\t%s,%s", reg[(data>>16)&0x1F], WordPatch(pPatch,"$%04X",(UWORD)data) );
						break;
				}
				break;
			case 2:
				switch( code2 )
				{
					case 4:
						printf( "beql\t%s,%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 5:
						printf( "bnel\t%s,%s,%s", reg[(data>>21)&0x1F], reg[(data>>16)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 6:
						printf( "blezl\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					case 7:
						printf( "bgtzl\t%s,%s", reg[(data>>21)&0x1F], GetSymbolName(pSect,index,((SWORD)data)<<2) );
						break;
					default:
						DumpLong( data );
						break;
				}
				break;
			case 4:
				switch( code2 )
				{
					case 0:
						printf( "lb\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 1:
						printf( "lh\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 2:
						printf( "lwl\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 3:
						printf( "lw\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 4:
						printf( "lbu\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 5:
						printf( "lhu\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 6:
						printf( "lwr\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					default:
						DumpLong( data );
						break;
				}
				break;
			case 5:
				switch( code2 )
				{
					case 0:
						printf( "sb\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 1:
						printf( "sh\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 2:
						printf( "swl\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 3:
						printf( "sw\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					case 6:
						printf( "swr\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					default:
						DumpLong( data );
						break;
				}
				break;
			case 6:
				switch( code2 )
				{
					case 0:
						printf( "ll\t%s,%s(%s)", reg[(data>>16)&0x1F], WordPatch(pPatch,"%d",(SWORD)data), reg[(data>>21)&0x1F] );
						break;
					default:
						DumpLong( data );
						break;
				}
				break;
			default:
				DumpLong( data );
				break;
		}
		printf( "\n" );
	}
}

void	BSSDump( SSection *pSect )
{
	SSymbol	**ppSym;
	SSymbol	*pSym;
	int	oSwapped=1;

	while( oSwapped )
	{

		ppSym=&pSect->pSymbols;
		oSwapped=0;
		while( (*ppSym) && (*ppSym)->pNext )
		{
			if( (*ppSym)->iOffset>(*ppSym)->pNext->iOffset )
			{
				SSymbol	*t;

				t=(*ppSym);
				*ppSym=t->pNext;
				t->pNext=t;

				oSwapped=1;
			}

			ppSym=&(*ppSym)->pNext;
		}
	}

	pSym=pSect->pSymbols;
	while( pSym )
	{
		int	size;

		if( pSym->pNext )
		{
			size=pSym->pNext->iOffset-pSym->iOffset;
		}
		else
		{
			size=pSect->iSize-pSym->iOffset;
		}
		printf( "%s:\tDSB\t%d\n", pSym->sName, size );
		pSym=pSym->pNext;
	}
}

void	ByteDump( SSection *pSect )
{
	ULONG	charpos=0;
	ULONG	datasize=0;
	ULONG	index=0;
	ULONG	size;
	ULONG	PC=0;
	SSymbol	*pSym;

	pSym=pSect->pSymbols;
	while( pSym )
	{
		if( pSym->Type==SYM_XDEF )
		{
			printf( "\tXDEF\t%s\n", pSym->sName );
		}
		pSym=pSym->pNext;
	}

	size=pSect->iSize;

	while( size )
	{
		SPatch	*pPatch;
		int		newdatasize;

		pSym=pSect->pSymbols;
		while( pSym )
		{
			if( pSym->iOffset==index )
			{
				if( pSym->Type==SYM_XDEF )
				{
					printf( "\n" );
				}
				printf( "\n%s:", pSym->sName );
				charpos=strlen(pSym->sName);
				datasize=0;
				break;
			}
			pSym=pSym->pNext;
		}

		pPatch=pSect->pPatches;
		while( pPatch )
		{
			if( (pPatch->iOffset>=index) && (pPatch->iOffset<=index+3) )
			{
				break;
			}
			pPatch=pPatch->pNext;
		}

		if( charpos>70 )
		{
			datasize=0;
		}

		switch( index&3 )
		{
			case	0:
				newdatasize=4;
				break;
			case	1:
			case	3:
				newdatasize=1;
				break;
			case	2:
				newdatasize=2;
				break;
		}

		if( size<newdatasize )
		{
			newdatasize=size;
			if( newdatasize==3 )
			{
				newdatasize=2;
			}
		}

		switch( newdatasize )
		{
			case	4:
			{
				ULONG	data;

				if( datasize!=4 )
				{
					printf( "\n\tDW\t" );
					charpos=16;
				}
				else
				{
					printf( "," );
					charpos+=1;
				}

				datasize=4;
				data =pSect->pData[index++];
				data|=pSect->pData[index++]<<8;
				data|=pSect->pData[index++]<<16;
				data|=pSect->pData[index++]<<24;
				printf( "$%08X", data );
				charpos+=9;
				size-=4;

				break;
			}
			case	1:
			{
				ULONG	data;

				if( datasize!=1 )
				{
					printf( "\n\tDB\t" );
					charpos=16;
				}
				else
				{
					printf( "," );
					charpos+=1;
				}

				datasize=1;
				data =pSect->pData[index++];
				printf( "$%02X", data );
				charpos+=3;
				size-=1;

				break;
			}
			case	2:
			{
				ULONG	data;

				if( datasize!=2 )
				{
					printf( "\n\tDH\t" );
					charpos=16;
				}
				else
				{
					printf( "," );
					charpos+=1;
				}

				datasize=2;
				data =pSect->pData[index++];
				data|=pSect->pData[index++]<<8;
				printf( "$%04X", data );
				charpos+=5;
				size-=2;
				break;
			}
		}
	}
}

void	FixRelativeJumps( SSection *pSect )
{
	ULONG	index=0;
	ULONG	size;

	if( pSect->pData==NULL )
		return;

	size=pSect->iSize;

	while( size )
	{
		ULONG	data;
		ULONG	code1,
				code2;
		int		found;

		found=0;

		data =pSect->pData[index++];
		data|=pSect->pData[index++]<<8;
		data|=pSect->pData[index++]<<16;
		data|=pSect->pData[index++]<<24;
		size-=4;

		code1=(data>>29)&0x7;
		code2=(data>>26)&0x7;

		switch( code1 )
		{
			case 0:
				switch( code2 )
				{
					case 1:
					//	REGIMM function
					{
						ULONG	code3,
								code4;

						code3=(data>>19)&0x3;
						code4=(data>>16)&0x7;

						switch( code3 )
						{
							case 0:
								switch( code4 )
								{
									case 0:
									case 1:
									case 2:
									case 3:
										found=1;
										break;
								}
								break;
						}
						break;
					}
					case 4:
					case 5:
					case 6:
					case 7:
						found=1;
						break;
				}
				break;
			case 2:
				switch( code2 )
				{
					case 4:
					case 5:
					case 6:
					case 7:
						found=1;
						break;
				}
				break;
		}

		if( found )
		{
			SSymbol	*pSym;
			int	offset=(SWORD)data;
			offset=(offset<<2)+index;

			pSym=pSect->pSymbols;
			while( pSym )
			{
				if( pSym->iOffset==offset )
					break;
				pSym=pSym->pNext;
			}

			if( pSym==NULL )
			{
				pSym=CreateSymbol( pSect, SYM_LOCAL );
				pSym->iNumber=iSymbolNumber;
				pSym->iOffset=offset;
				sprintf( pSym->sName, "%s_%X", pSect->sName+1, pSym->iOffset );
				iSymbolNumber+=1;
			}
		}
	}
}

