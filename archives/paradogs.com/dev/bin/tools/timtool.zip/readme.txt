TimTool 2.0a (5th September '97)


1.0c 
 - Fixed bug with importing 4-bit images.
 - Added some new STP features.

2.0a
-	Bug fix in autosort cluts fixed
-	4/8 bit Tins without cluts can be loaded now
-	Double buffers can be placed side by side

Timtool allows easy conversion and Manipulation of Tim files.  (Created by SCEE)

