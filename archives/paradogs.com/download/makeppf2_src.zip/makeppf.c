/*
 * MakePPF v2.0 Sourcecode by Icarus/Paradox
 * enter "gcc makeppf.c" on linux/unix to compile!
 *
 * Feel free to optimize speed or something!
 *
 */
#include <stdio.h>
#define null 0

FILE *originalbin;
FILE *patchedbin;
FILE *ppffile;
FILE *fileid;
char desc[52];
char block[1025];
char fileidbuf[3073];
char enc=1;
char obuf[512];
char pbuf[512];
char cbuf[512];
unsigned char anz; /* Hell YES! UNSIGNED CHAR! */
int i, z, a, x, y, osize, psize, fsize, seekpos=0, pos;


int main(int argc, char *argv[])
{
        printf("MakePPF v2.0 Linux/Unix by Icarus/Paradox\n");
        if(argc==1||argc<4){
        printf("Usage: MakePPF <Original Bin> <Patched Bin> <ppffile> [file_id.diz]\n");
        exit(0);
        }

	/* Open all neccessary files */
        originalbin=fopen(argv[1], "rb");
        if(originalbin==null){
        printf("File %s does not exist. (Original BIN)\n",argv[1]);
        exit(0);
        }
        patchedbin=fopen(argv[2], "rb");
        if(patchedbin==null){
        printf("File %s does not exist. (Patched BIN)\n",argv[2]);
        fclose(originalbin);
        exit(0);
        }
        fseek(originalbin, 0, SEEK_END);
        osize=ftell(originalbin);
        fseek(patchedbin, 0, SEEK_END);
        psize=ftell(patchedbin);
        if(osize!=psize){
        printf("Error: Filesize does not match - byebye..\n");
        fclose(originalbin);
        fclose(patchedbin);
        exit(0);
        }
        if(argc>=5){
        fileid=fopen(argv[4], "rb");
        if(fileid==null){
        printf("File %s does not exist. (File_id.diz)\n",argv[4]);
        fclose(patchedbin);
        fclose(originalbin);
        exit(0);
        }}
        ppffile=fopen(argv[3], "wb+");
        if(ppffile==null){
        printf("Could not create file %s\n",argv[3]);
        if(argc>=5) fclose(fileid);
        fclose(patchedbin);
        fclose(originalbin);
        exit(0);
        }

        printf("Enter PPF-Patch description (max. 50 chars):\n[---------1o--------2o--------3o--------4o---------]\n ");
        fgets(desc, 50, stdin);
        for(i=0;i<50;i++){
        if(desc[i]==0x00) desc[i]=0x20;
        }

	/* creating PPF2.0 header */
        printf("Creating PPF2.0 header data.. ");
        fwrite("PPF20", 5, 1, ppffile); /* Magic (PPF20) */
        fwrite(&enc, 1, 1, ppffile);	/* Enc.Method (0x01) */
        fwrite(desc, 50, 1, ppffile);	/* Description line */
        fwrite(&osize, 4, 1,ppffile);	/* BINfile size */
        fseek(originalbin, 0x9320, SEEK_SET);
        fread(block, 1024, 1, originalbin);
        fwrite(block, 1024, 1,ppffile);	/* 1024 byte block */
        printf("done!\n");

        printf("Writing patchdata, please wait.. ");
	fflush(stdout);
	
	/* Finding changes.. i know it slow.. so feel free to optimize */
        z=(osize/255);
        a=osize-(z*255);
        do{
           fseek(originalbin, seekpos, SEEK_SET);
           fseek(patchedbin, seekpos, SEEK_SET);
           fread(obuf, 255, 1,originalbin);
           fread(pbuf, 255, 1,patchedbin);
           x=0; pos=0;
           do{
              if(obuf[x]!=pbuf[x]){
                  pos=seekpos+x;
                  y=0;
                  anz=0;
                  do{
                     cbuf[y]=pbuf[x];
                     anz++; x++; y++;
                  }while(x!=255&&obuf[x]!=pbuf[x]);
                  fwrite(&pos, 4, 1, ppffile);
                  fwrite(&anz, 1, 1, ppffile);
                  fwrite(cbuf, anz, 1, ppffile);
              }else x++;

           }while(x!=255);

        seekpos+=255;
        z--;
        }
        while(z!=0);

        if(a!=0){
        fseek(originalbin, seekpos, SEEK_SET);
        fseek(patchedbin, seekpos, SEEK_SET);
        fread(obuf, 255, 1,originalbin);
        fread(pbuf, 255, 1,patchedbin);
        x=0; pos=0;
        do{
           if(obuf[x]!=pbuf[x]){
               pos=seekpos+x;
               y=0;
               anz=0;
               do{
                  cbuf[y]=pbuf[x];
                  anz++; x++; y++;
               }while(x!=a&&obuf[x]!=pbuf[x]);
               fwrite(&pos, 4, 1, ppffile);
               fwrite(&anz, 1, 1, ppffile);
               fwrite(cbuf, anz, 1, ppffile);
           }else x++;
         }while(x!=a);
        }
        printf("done!\n");

	/* was a file_id.diz argument present? */
        if(argc>=5){
        printf("Adding file_id.diz .. ");
        fseek(fileid, 0, SEEK_END);
        fsize=ftell(fileid);
        fseek(fileid, 0, SEEK_SET);
        if(fsize>3072) fsize=3072;	/* File id only up to 3072 bytes! */
        fread(fileidbuf, fsize, 1 ,fileid);
        fwrite("@BEGIN_FILE_ID.DIZ", 18, 1, ppffile); /* Write the shit! */
        fwrite(fileidbuf, fsize, 1, ppffile);
        fwrite("@END_FILE_ID.DIZ", 16, 1, ppffile);
        fwrite(&fsize, 4, 1, ppffile);
        printf("done!\n");
        }

        fclose(ppffile);	/* Thats it! */
        fclose(originalbin);
        fclose(patchedbin);
        return 0;
}

