
Included in this archive there is the AMIGA and the PC version of both,
APPLYPPF.EXE and MAKEPPF.EXE.

Furthermore there are the c-sources included for our Linux/unix users..

if you want to learn about the PPF-Filestructure check out the file PPF.txt

Feel free to develop any other utilities for PPF - Maybe a GUI or a 
Descritionlister etc.. anything you like.. or develop a better encodingmethod..
PPF is totally free.

Oh and btw.. thanks to Da_Freniz for compiling this one on AMIGA.. :o)

Ciao.


