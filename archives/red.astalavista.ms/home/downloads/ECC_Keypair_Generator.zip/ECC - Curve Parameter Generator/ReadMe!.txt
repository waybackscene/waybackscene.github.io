Note : All the parameters are in BASE10.
It generates 94 bit Keys (approx).

Greetz Flyout to All my Friends in RED CReW & in iNF & also UF :)

Enjoy it :)