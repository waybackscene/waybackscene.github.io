keygen et fichier dump data.bin qui sert � calculer la cl�. Voir tutorial pour explications sur le fichier data.bin.


note : quelques serials peuvent freezer le crackme. En entrant un nom contenant plus de 6 caract�res, il ne devrait pas y avoir de probl�mes.  Attention aux majuscules/minuscules si vous ne faites pas de copier/coller...