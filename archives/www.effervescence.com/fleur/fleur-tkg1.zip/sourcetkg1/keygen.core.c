#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include "global.h"
#include <miracl.h>

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	unsigned char bfBuffer[100] = "Thigo ufound ";
	unsigned char bfFileBuffer[30] = {0};
	unsigned char szName[100] = {0};
	long dtLength,hFile,i;
	big n,e,m,c;
	miracl *mip=mirsys(100,0);

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:
			dtLength=GetDlgItemText(hWnd, IDC_EDITNAME, &szName, 100);

			if (dtLength==0) {
				SetDlgItemText(hWnd, IDC_EDITSERIAL, "at least 1 character");
				break;
			}

			lstrcpy(&bfBuffer[13],&szName);

			dtLength+=13;

			mip->IOBASE=16;
			n=mirvar(0);
			e=mirvar(0);
			m=mirvar(0);
			c=mirvar(0);
			bytes_to_big(dtLength,&bfBuffer,m);
			cinstr(n,"B9B9BCDA766CC754AF5A3AA6A4302E0C62B455B6977488F9CDAD8F2F9479");
			cinstr(e,"78076BDC2928F59C2ABB141DE14F6F73B43D1EEADBAEC09D09E3F1A69E11");

			powmod(m,e,n,c);

			dtLength=big_to_bytes(0,c,&szName);

			for (i=0;i<30;i++) {
				bfFileBuffer[i]=0;
			}

			for (i=0;i<dtLength;i++){
				bfFileBuffer[i+30-dtLength]=szName[i];
			}

			hFile=CreateFileA("key.dat",GENERIC_WRITE,0,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
			WriteFile(hFile,&bfFileBuffer,30,&dtLength,0);
			CloseHandle(hFile);

			SetDlgItemText(hWnd, IDC_EDITSERIAL, "copy key.dat in the keygenme directory");

			mirkill(n);
			mirkill(e);
			mirkill(m);
			mirkill(c);
			mirexit();
			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "keygenerator for thigo' s keygenme 1\nprotection: rsa-240 and sha-1", "about", MB_OK);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
