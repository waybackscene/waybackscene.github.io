#include <stdio.h>
#include <windows.h>
#include "resource.h"
#include "global.h"
#include <miracl.h>
#include "blowfish.c"
#include "haval.c"

extern void sub_40A990(void);

HINSTANCE	hInst;

BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{	

	unsigned char szName[100] = {0};
	unsigned char szSerial[100] = {0};
	unsigned char szHash[33] = {0};
	long dt1,dt2;
	long dtLength;
	BLOWFISH_CTX blowfishctx;
	haval_state havalstate;
	big hash,modulo,tmgroxx;
	miracl *mip=mirsys(100,0);

	switch (message)
	{    
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{ 
		case IDC_GENERATE:
			dtLength=GetDlgItemText(hWnd, IDC_EDITNAME, szName, 55);

			__asm{
			lea	edi,szName
			mov	eax,dtLength
			inc	eax
			add	edi,eax
			mov	byte ptr [edi-1],080h

			xor	edx,edx

			mov	ebx,64
			div	ebx

			neg	edx
			add	edx,64

			cmp	edx,8
			jae	dopadding

			add	edx,64

dopadding:	mov	ecx,edx
			xor	al,al
			rep	stosb

			mov	eax,dtLength

			shl	eax,3

			mov	dword ptr [edi-8],eax

			mov	dword ptr [szHash],01324ad68h
			mov	dword ptr [szHash+4],098765478h
			mov	dword ptr [szHash+8],0fda85ec9h
			mov	dword ptr [szHash+12],09645687ah

			lea		esi,szName
			lea		edi,szHash
			push	esi
			push	edi
			call	sub_40A990

			mov		dt1,'Thig' xor 'Good'
			mov		dt2,'heya' xor ' luc'
			}

			Blowfish_Init(&blowfishctx, &szHash, 16);
			Blowfish_Encrypt(&blowfishctx, &dt1, &dt2);

			wsprintf(&szSerial,"%08X%08X", dt1, dt2);

			haval_start(&havalstate);
			haval_hash(&havalstate, &szName, dtLength);
			haval_end(&havalstate, &szHash);

			mip->IOBASE=16;
			hash=mirvar(0);
			modulo=mirvar(0);
			tmgroxx=mirvar(0);
			bytes_to_big(32,&szHash,hash);
			cinstr(modulo,"D84E28B5C2075FE923D9B1780878F84EDB86F1B746BDECE01A58D86F88DF1413");
			mip->IOBASE=60;
			cinstr(tmgroxx,"TMGRoxx");
			powmod(hash,tmgroxx,modulo,modulo);
			cotstr(modulo,&szSerial[16]);

			SetDlgItemText(hWnd, IDC_EDITSERIAL, &szSerial);

			mirkill(hash);
			mirkill(modulo);
			mirkill(tmgroxx);
			mirexit();

			break;
		case IDC_ABOUT:
			MessageBox(hWnd, "keygenerator for thigo' s keygenme 2\nprotection : modified md5, blowfish, sha-1 and haval-256", "about", MB_OK);
			break;
		}
		break;
	case WM_INITDIALOG:
		SendMessageA(hWnd,WM_SETICON,(WPARAM) 1,(LPARAM) LoadIconA(hInst,MAKEINTRESOURCE(IDI_ICON)));
		break;
	}
     return 0;
}
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}

