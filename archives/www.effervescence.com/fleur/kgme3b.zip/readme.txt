				--== Keygenme 3 Bis by Thigo ==--

This is a replacement for the buggy 3rd kgme :)
But you'll notice it's a kind of *special* crackme... as it's not only usual reversing shit
you'll have to be good in crypto I think :)
I hope you'll have fun with this one and that it'll resist a bit more than 3 hours :)
Oh, plz try to do the first part without bruteforce ;) It's more 'elegant' :)
Thigo