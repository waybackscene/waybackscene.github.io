/*
 * Auteur : Lionel d'Hauenens
 * bugs : http://www.labo-asso.com
 * le 31/03/2007
 */


#include <stdio.h> 
#include <stdlib.h> 
#include <windows.h> 

#define rol(a,b) (a<<(b % 32)) | (a>>(32-(b % 32)))

int main(int argc, char *argv[])
{                   
    UCHAR api_name[] = "WinExec";                                     
    ULONG crc = 0;
    ULONG i = 0;
    while (i< strlen(api_name))
    {
        crc = rol(crc,7);
        crc += ((ULONG)api_name[i] & 0xFF);
        i++;
    } 

    printf ("Le crc de la chaine \"%s\" est %08X.", api_name, crc);
    
    system("PAUSE");   

    return (0);
}
