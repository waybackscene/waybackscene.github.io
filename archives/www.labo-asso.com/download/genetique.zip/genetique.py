
from random import randint

# ******************************************************************************
class World:
  pop = {}     # La population
  elements = 0 # Le nombre d'�l�ments peuplant le monde


  def __init__(self,elements = 10):
    """ Le constructeur du monde. Restons modestes """
    self.elements = elements
    for i in range(elements):
      self.pop[i]=YoLaFourmi()


  def Fornicate(self):
    """ On fait une petite sauterie chez les gens de ce monde """
    self.count = self.count + 1
    print ("Un peu plus tard�")
    for i in range(self.elements/2):
      self.pop[i*2] = self.pop[i*2].ShagWith(self.pop[i*2+1])



  def Resolved(self):
    """ Retourne True si la condition de "fin du monde" est atteinte """
    for i in range(self.elements):
      if (self.pop[i].value**2 - self.pop[i].value) == 42:
        print ("**** On trouve %s en %s g�n�rations"
                % (self.pop[i].value, self.count))
        return True
    return False


# ******************************************************************************
class YoLaFourmi:
  value = 0

  def __init__(self, value = None):
    if value == None:
      self.value = randint(1,300)
    else:
      self.value = int(value)


  def Mutate(self):
    """ Mutations des individus """
    rand = randint(0,20)

    if rand == 1:
      self.value = self.value + 1
    elif rand == 4:
      self.value = self.value - 1
    elif rand == 12:
      self.value = randint(0,20)


  def ShagWith(self, partner):
    """ Rencontre chaleureuse entre deux individus """

    # On ajoute un brin de folie au cours de cette vie
   self.Mutate()
   partner.Mutate()

   try:
    fils = YoLaFourmi((self.value * partner.value) /
                      (self.value + partner.value))
  except:
    print("Oups...")
    fils = YoLaFourmi(0)   # G�n�ration spontan�e. Pop !
  return fils


# ******************************************************************************
# Ici commence l'histoire du monde
myworld = World()
while not myworld.Resolved():
  myworld.Fornicate()

------


# Fabrice "mimas" T.
