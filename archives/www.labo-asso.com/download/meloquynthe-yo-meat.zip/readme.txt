      _ .
     (
     _\_
 .: | | \ ELOQUYNTHE :.
         \_________________________.
          YoLeJedi & ++Meat

          _______________________________.
 ._______/ Presentation

 Salut !

 [ Hello !

 Merci d'avoir t�l�charg� le Meloquynthe.

 [ Thanks for downloading the Meloquynthe.

 Ce crackme est n� de la collaboration entre YoLeJedi et ++Meat, sur une id�e de YoLeJedi.
 Il a demand� plusieurs jours de travail acharn�, et nous esp�rons qu'il vous plaira.

 [ This crackme was done by YoLeJedi and ++Meat.
 [ We really hope you'll like it.

 ._______
  Regles \_________________________.

 A rendre un keygen avec tutoriel redig� au propre et sans rature.

 [ You must give us your keygen and tutorial.

 Patch strictement interdit sinon lapidation et amputation des 4 membres ;)

 [ Patch it and die slowly !

          _______________________________.
 ._______/ Greetz

 YoLeJedi :

 - ++Meat - Merci pour ton superbe travail l'artiste !
 - Neitsa
 - Kaine
 - Gbillou
 - kharneth
 - Pulsar
 - eedy31
 - Patrick M
 - BeatriX
 - LiLi

 ++Meat :

 - YoLeJedi pour avoir fourni un travail remarquable sur ce crackme :)
 - Les 1337s cit�es ci-dessus ;)
 - Les groupes NAS / FRET / NGEN / FFF
 - Les noobs qui ont la gniaque !
 - Les crackeuses et crackers composant la "scene". Keep it funky !

 ._______
  Infos  \_________________________.

 Code & protections : YoLeJedi
 Punk Code d'interface : ++Meat
 Programmation machine (clavier, batterie) & basse �lectrique fretless : YoLeJedi
 Vocals : LiLi & YoLeJedi
 Gfx : ++Meat

 [ MASM32 POWERED ]

          _______________________________.
 ._______/                        /
                          _ _____/
 :___________________________)

 Meloquynthe Crackme (c) 2006
 YoLeJedi & ++Meat^NAS^FRET

 YoLeJedi :

 yolejedi@free.fr
 http://yolejedi.free.fr/ 
 http://www.labo-asso.com/

 ++Meat

 meat89@hotmail.fr
 http://meat.new.fr
 http://newbiesaintshit.new.fr
 http://binary-reverser.org/
