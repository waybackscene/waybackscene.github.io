#ifndef _HL_CLEAN_TREE_H_
#define _HL_CLEAN_TREE_H_

#pragma once
extern "C"
{
	#include "libdis.h"
	#include "ia32_list.h"
}

class clean_tree
{
public:
	clean_tree(void);
	~clean_tree(void);
	void clean1(long start);
private:
};

#endif  /* _HL_CLEAN_TREE_H_ */ 
