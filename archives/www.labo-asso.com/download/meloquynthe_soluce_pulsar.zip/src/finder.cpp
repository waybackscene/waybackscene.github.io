#include "finder.h"
#include <iostream>

finder::finder(void)
{
}

finder::~finder(void)
{
}

void finder::do_it2(instruction *ins)
{
	if(ins->_new_offset == _off )
		std::cout << "[" << _off + 0x008C3000 << "] -> " <<  std::hex << ins->insn()->addr << std::endl;
}

void finder::do_it(x86_insn_t *insn)
{
	/*
	char line[4096];
	x86_format_insn(insn, line, 4096, intel_syntax);
	printf("[%X] %s",insn->addr,line);
	*/
}