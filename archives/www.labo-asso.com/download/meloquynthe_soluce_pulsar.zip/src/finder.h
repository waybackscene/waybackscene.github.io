#ifndef _HL_FINDER_H_
#define _HL_FINDER_H_

#pragma once
#include "print_tree.h" 


class finder:
	public print_tree
{
public:
	finder(void);
	~finder(void);
	void do_it2(instruction *ins);
	void init(long offset){_off=offset;_printed.clear();}
	void do_it(x86_insn_t *insn);
private:
	long _off;
};

#endif  /* _HL_FINDER_H_ */ 
