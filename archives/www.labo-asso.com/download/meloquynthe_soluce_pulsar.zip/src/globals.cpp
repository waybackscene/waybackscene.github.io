#include "globals.h"
#include <boost/pool/detail/singleton.hpp>

globals& globals::instance()
{
	return boost::details::pool::singleton_default<globals>::instance();
}

globals::globals(void)
{
	_map.clear();
	_call_list.clear();
	_done.clear();
}

globals::~globals(void)
{
}

