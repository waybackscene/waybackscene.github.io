#ifndef _HL_GLOBALS_H_
#define _HL_GLOBALS_H_

#pragma once
#include <hash_map>
#include <list>
#include "instruction.h"

class globals
{
public:
	globals(void);
	~globals(void);
	static globals& instance();

	stdext::hash_map<long,instruction *> _map;
	std::list<long> _call_list;
	std::list<long> _done;

};

#endif  /* _HL_GLOBALS_H_ */ 
