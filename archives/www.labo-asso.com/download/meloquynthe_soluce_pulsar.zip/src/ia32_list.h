#ifndef _IA32_LIST_H_
#define _IA32_LIST_H_

struct DISASMLIST {
	unsigned long rva;
	struct DISASMLIST *next;
} ;

extern struct DISASMLIST disasm_list_head;

extern int disasm_list_add( unsigned long rva );
extern int disasm_list_pop(void);

#endif