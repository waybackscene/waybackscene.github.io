#include "instruction.h"

instruction::instruction(void)
{
	_new_offset=0;
}

instruction::~instruction(void)
{
	_insn.type == insn_invalid;
}

instruction::instruction(x86_insn_t* in)
:_done(false)
{
	_insn=*in;
	next=_insn.offset+_insn.size;
	next_flow = 0;
	_new_offset=0;
	cleaned=false;
}

instruction::instruction(x86_insn_t* in,long next_f)
:_done(false)
{
	_insn=*in;
	next=_insn.offset+_insn.size;
	next_flow = next_f;
	cleaned=false;
	_new_offset=0;
}
