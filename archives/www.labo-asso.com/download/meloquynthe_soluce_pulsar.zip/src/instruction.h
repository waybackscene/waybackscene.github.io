#ifndef _HL_INSTRUCTION_H_
#define _HL_INSTRUCTION_H_

#pragma once

extern "C"
{
	#include "libdis.h"
	#include "ia32_list.h"
}

class instruction
{
public:
	instruction(void);
	~instruction(void);
	instruction(x86_insn_t* in);
	instruction::instruction(x86_insn_t* in,long next_f);
	x86_insn_t * insn(){return &_insn;}
	bool done(){return _done;}
	void done(bool b){_done=b;}

	long next;
	long next_flow;
	bool cleaned;
	long _new_offset;

private:
	x86_insn_t _insn;
	bool _done;
};

#endif  /* _HL_INSTRUCTION_H_ */ 
