#include ".\jmp_adder.h"
#include "globals.h"

jmp_adder::jmp_adder(void)
{
	_num=0x0900000; //far enough not to collide!
}

jmp_adder::~jmp_adder(void)
{
}

void jmp_adder::do_it(x86_insn_t *ins)
{

}

bool jmp_adder::rejected(instruction *ins,instruction *ins_old)
{
	x86_insn_t * insn;
	instruction *new_ins;
	insn=ins->insn();

	if(ins_old && _printed[insn->offset])
	{
		/*
			Vraiment � l'arrache ce test, j'en suis pas tres fier :)
		*/
		if(ins_old->insn()->type == insn_jcc)
		{
			char line[4096];
			x86_format_insn(ins_old->insn(), line, 4096, intel_syntax);
			printf("#######Reject JCC!######\n[%X] %s\n",ins_old->insn()->addr,line);
		}
		if (
			ins->_new_offset < ins_old->_new_offset &&
			!(ins_old->insn()->type == insn_return || ins_old->insn()->type == insn_jmp)
			)
		{
			insn = (x86_insn_t *) malloc(sizeof(x86_insn_t));
			insn->type = insn_jmp;
			insn->size = 5;
			insn->bytes[0]=0xE9;
			insn->offset=_num;
			new_ins = new instruction(insn);			
			
			new_ins->next = 0;
			new_ins->next_flow = ins_old->next;

			ins_old->next=_num;

			globals::instance()._map[_num]=new_ins;
			_num++;
			char line[4096];
			x86_format_insn(ins_old->insn(), line, 4096, intel_syntax);
			printf("#######Suspicious reject!######\n[%X] %s\nAddind jump at %X\n",ins_old->insn()->addr,line,ins_old->next);
			x86_format_insn(ins->insn(), line, 4096, intel_syntax);
			printf("%s\n",line);

			/*

				ajout de lignes...
			*/

		}
		return true;
	}
	return false;
}