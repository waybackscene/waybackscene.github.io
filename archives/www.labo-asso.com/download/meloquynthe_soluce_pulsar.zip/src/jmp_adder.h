#ifndef _HL_JMP_ADDER_H_
#define _HL_JMP_ADDER_H_

#pragma once
#include "print_tree.h" 


class jmp_adder:
	public print_tree
{
public:
	jmp_adder(void);
	~jmp_adder(void);
	bool rejected(instruction *ins,instruction *ins2);
	void do_it(x86_insn_t *ins);
private:
	long _num;
};

#endif  /* _HL_JMP_ADDER_H_ */ 
