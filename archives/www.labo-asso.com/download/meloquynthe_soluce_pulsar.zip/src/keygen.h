#ifndef _KEYG_H_
#define _KEYG_H_

void push_spec();

#endif