#ifndef _MEAT_H_
#define _MEAT_H_

	int __stdcall meat_sample(int pos,int *ptr);
	int __stdcall meat_good_button(int esi,int thread5);
	int __stdcall meat(int mButton,int thread5);

#endif