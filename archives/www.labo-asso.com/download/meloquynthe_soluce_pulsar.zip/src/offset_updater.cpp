#include "offset_updater.h"

offset_updater::offset_updater(void)
{
	_current_off=0;
}

offset_updater::~offset_updater(void)
{
}

void offset_updater::do_it(x86_insn_t *insn)
{
	//
}

void offset_updater::do_it2(instruction *ins)
{
	ins->_new_offset=_current_off;
	_current_off+=ins->insn()->size;
}