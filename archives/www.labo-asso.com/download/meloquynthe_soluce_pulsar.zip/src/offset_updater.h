#ifndef _HL_OFFSET_UPDATER_H_
#define _HL_OFFSET_UPDATER_H_

#pragma once
#include "print_tree.h" 


class offset_updater:
	public print_tree
{
public:
	offset_updater(void);
	~offset_updater(void);
	void do_it(x86_insn_t *ins);
    void do_it2(instruction *ins);
	void init(){_current_off=0;_printed.clear();}
private:
	long _current_off;
};

#endif  /* _HL_OFFSET_UPDATER_H_ */ 
