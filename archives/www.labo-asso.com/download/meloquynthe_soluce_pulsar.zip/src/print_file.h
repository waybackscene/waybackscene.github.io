#ifndef _HL_PRINT_FILE_H_
#define _HL_PRINT_FILE_H_

#pragma once
#include "print_tree.h" 


class print_file:
	public print_tree
{
public:
	print_file(void);
	~print_file(void);
	void do_it(x86_insn_t *ins);
	void do_it2(instruction *ins);
	void init(long starthere,long basep);
	void finish();
	//bool rejected(instruction *ins,instruction *ins2);
private:
	long _current;
	long _current_off;
	long _base;
};

#endif  /* _HL_PRINT_FILE_H_ */ 
