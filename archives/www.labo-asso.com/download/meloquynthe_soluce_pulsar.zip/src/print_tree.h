#ifndef _HL_PRINT_TREE_H_
#define _HL_PRINT_TREE_H_

#pragma once
extern "C"
{
	#include "libdis.h"
	#include "ia32_list.h"
}

#include <hash_map>
#include "instruction.h"

class print_tree
{
public:
	print_tree(void);
	~print_tree(void);
	void print(long offset);
	void print(long offset,instruction *ins_o);
	void init();
	virtual void do_it(x86_insn_t *ins);
	virtual void do_it2(instruction *ins);
	virtual bool rejected(instruction *ins,instruction *ins2);
protected:
	stdext::hash_map <long,bool> _printed;
};

#endif  /* _HL_PRINT_TREE_H_ */ 
