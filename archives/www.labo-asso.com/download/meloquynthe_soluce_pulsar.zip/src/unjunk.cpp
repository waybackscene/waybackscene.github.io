#include "unjunk.h"
#include <boost/bind.hpp>
#include <boost/bind/placeholders.hpp>
#include "windows.h"






unjunk::unjunk(void)
{
	_rva_list.clear();
	_current=0;
	
}

unjunk::~unjunk(void)
{
	
	_rva_list.clear();
}

void unjunk::init(long map_old,long map_new,long img_base)
{
	_map_old = map_old;
	_map_new = map_new;
	_img_base = img_base;
}




int unjunk::rva_list_add( unsigned long rva ) 
{
	std::list<long>::iterator iter;
	for(iter = _rva_list.begin();iter != _rva_list.end();++iter)
	{
		if((*iter)==rva)
			return 0;
	}
	_rva_list.push_back(rva);
}

