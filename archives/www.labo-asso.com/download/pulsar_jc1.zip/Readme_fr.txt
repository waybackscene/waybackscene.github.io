Salut tout le monde,

C'est un de mes premiers crackme donc soyez indulgents svp :)

Si vous voulez apprendre de nouvelles m�thodes de d�tecter softice / olly, de nouvelles mani�res pour effacer votre PE header, prot�ger votre IAT ... je pense que ce crackme n'est pas fait pour vous.

Par contre si vous voulez avoir la possibilit� d'apprendre (ne m'engueulez pas si vous n'apprenez rien) certaines fonctionnalit�s de vos outils pr�f�r�s (IDA me viens de t�te) ou de construire certains programmes qui vous aideront sans doute un jour ou l'autre dans votre carri�re de reverse, alors ces crackmes peuvent vous �tre utiles.

Ces crackmes, oui...en effet je vais en faire environ 5 avec un niveau de difficult� croissant. Si vous arrivez � les r�soudre tous, je vous offrirai un petit cadeau :)

Ce premier crackme est simple, vous vous apercevrez rapidement que je prends une info, je g�n�re des trucs et apr�s je dis si vous �tes un bon reverser ou pas...La routine de calcul elle m�me est courte, mais malheureusement "un peu" de junk code a infest� mes sources...Je pense que vous n'aurez aucune difficult� � trouver les mots magiques quand le code sera propre !

Pour r�ussir ce crackme vous devez trouver le bon code...
Si vous voulez le bruteforcer, pas de probl�me, mais vous n'apprendrez s�rement pas grand chose...�a ne vous aidera pas pour le prochain en tout cas :)

Info:
Je n'ai pas cod� tout le junk code moi m�me, c'est un outil maison qui s'en est occup�. Avec les �volutions de cet outil viendront des difficult�s sup�rieures pour les crackmes...

J'esp�re que vous apprendrez des choses int�ressantes...

Pulsar 2005
