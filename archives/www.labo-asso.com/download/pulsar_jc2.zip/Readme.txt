Hello guys & gals...
this is one of my first crackme, so please dont laugh too loud :)

If you want to learn new methods to detect softice / olly, new ways to trash your PE header
new ways to protect your IAT then you may not try this crackme, you probably won't learn anything
interesting for *you*.

In the case you wanna have a chance to learn new possibility (dont blame me if you dont ^^) offered by
some of the tools you may use (IDA maybe?) or make some proggy that will probably help you sooner or later
then you should have a look at thoose little crackmes.

Thoose? Yeah in fact there'll be like 5, with an increasing lvl.
If you manage to complete all of them i ll offer you a present.

Crackme 1:
This #1 crackme is simple, you ll soon see that i get some input, generate smthg then say if
you are a good guy or a nasty one. The computation routine itself is short but unluckily "some"
junk code managed to infest my source code. I guess you won't have any problems finding the 
magic words when all this code will be removed.

To pass this test, you have to find the good serial...If you want to brute force it, well go for it but you won't learn
anything new...It won't help you for later crackmes though ^^

Crackme 2:
Nothing really more difficult for this second one, well you ll say. Maybe removing the junk could be even more easier
than for the first one, maybe ^^

You ll have to make the proggy display "Good Boy" to succeed on this one.

Note:
No i didnt wrote all this junk code myself, a hand-made tool did it :/ As i ll  improve it
the level will rise.

I hope you ll learn something interesting.
Pulsar 2005
