
#define id_dialog                       101

#define edit_entrez_code                1001

#define static_entrez_code              1002
#define static_reponse                  1003

#define id_icon_YoLeJedi                102
#define id_icon_CouCou                  103

#define frame_fond                      102

#define image_fond                      101
#define bouton_ok                       103
#define bouton_sortir                   104
#define bouton_ok2                      102
#define bouton_sortir2                  105





